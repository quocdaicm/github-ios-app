# GitHub Mobile (iOS, SwiftUI) – phiên bản 1.2

App xem/sửa code và quản lý build GitHub Actions ngay trên điện thoại, gọi thẳng GitHub REST API.

## Tính năng
- Đăng nhập bằng Personal Access Token (lưu trong Keychain). Token sai/hết hạn (401) thì tự quay về màn đăng nhập kèm thông báo.
- Danh sách repo (có tìm kiếm), chọn nhánh. Thông báo rõ ràng khi hết lượt gọi API (rate limit) hoặc mất mạng.
- **Mã nguồn**: duyệt thư mục/file, **README hiển thị đẹp (Markdown)** ở thư mục gốc, file .md có chế độ Xem trước/Sửa.
- **Editor**: tô màu cú pháp (Swift, JS/TS, Python, YAML, JSON, Markdown, HTML/XML, shell...), thanh phím tắt trên bàn phím (Tab, ngoặc, undo/redo...), tự thụt lề khi Enter, **tìm/thay thế**, cảnh báo khi thoát mà chưa commit.
- **Tải lên**: nút **+** > "Tải file lên" / "Tải thư mục lên" (chọn từ app Tệp), xem trước danh sách rồi commit ngay hoặc thêm vào gói. File trùng đường dẫn sẽ bị ghi đè; bỏ qua file lớn hơn 90 MB, `.git`, `.DS_Store`, `__MACOSX`.
- **Tải zip lên và giải nén**: nút **+** > "Tải zip lên và giải nén". App tự giải nén ngay trên máy (zip thường, không mật khẩu, không Zip64), hiện danh sách file để xem trước. Nếu zip có đúng một thư mục gốc, công tắc "Giữ tên thư mục gốc" cho bạn chọn đưa nội dung thẳng vào vị trí hiện tại.
- **Gói commit**: gom nhiều thay đổi (sửa file, tải lên, xóa, đổi tên) rồi commit **một lần duy nhất** (tránh build nhiều lần). Biểu tượng khay kèm số thay đổi hiện ở góc trên khi gói không trống.
- **Đổi tên / di chuyển / xóa** file hoặc cả thư mục: vuốt trái hoặc nhấn giữ trên dòng file. Sửa đường dẫn đầy đủ để chuyển sang thư mục khác.
- Commit thẳng lên nhánh, tạo file mới, xóa file. Nếu file đã bị đổi trên GitHub, app hỏi: tải bản mới hay ghi đè.
- **Lịch sử**: danh sách commit (tải thêm), chi tiết commit, danh sách file đổi và **xem diff** có màu xanh/đỏ.
- **Actions**: danh sách lần chạy (tự làm mới khi đang chạy, **tải thêm** các lần cũ), chạy workflow (workflow_dispatch) **có form nhập inputs** nếu workflow khai báo, chạy lại / chạy lại job lỗi / hủy.
- Xem job, bước lỗi, **log** (lọc "chỉ lỗi", sao chép để gửi cho Claude).
- Tải artifact (ví dụ file .ipa) rồi chia sẻ/lưu vào Tệp.

## Tạo token
Vào https://github.com/settings/tokens/new , chọn quyền `repo` và `workflow` (token classic).
Token fine-grained: Contents, Actions, Metadata (đọc/ghi).

## Build bằng GitHub Actions
1. Tạo repo mới, tải lên toàn bộ nội dung thư mục này (project.yml, GitHubMobile/, ...).
2. Workflow nằm ở `.github/workflows/build.yml`. Thư mục bắt đầu bằng dấu chấm hay bị ẩn khi giải nén trên điện thoại,
   nếu thiếu thì tạo file `.github/workflows/build.yml` trên GitHub rồi dán nội dung file `build-workflow.yml` vào
   (file này là bản sao dự phòng, giữ nguyên).
3. Push lên nhánh `main` (hoặc vào Actions > Run workflow). Kết quả là artifact `GitHubMobile-ipa` (IPA **chưa ký**).
   Nếu build lỗi sẽ có thêm artifact `build-log`.
4. IPA chưa ký cần được ký lại bằng công cụ của bạn khi cài lên máy (Sideloadly, AltStore, TrollStore...).

Mã chưa được biên dịch thử trên Xcode. Nếu build lỗi, mở log trong chính app này (hoặc trên web), chọn "Sao chép" rồi gửi lại để sửa.

## Cấu trúc
- `project.yml` – cấu hình XcodeGen (iOS 16+, bundle id `com.example.githubmobile`, đổi nếu cần)
- `GitHubMobile/App.swift` – điểm vào, phiên đăng nhập, lưu token
- `GitHubMobile/API.swift` – client GitHub REST + mô hình dữ liệu
- `GitHubMobile/GitData.swift` – Git Data API: commit nhiều file/đổi tên/xóa thư mục trong một commit
- `GitHubMobile/Zip.swift` – đọc/giải nén file .zip
- `GitHubMobile/PackViews.swift` – gói commit, tải file/thư mục lên
- `GitHubMobile/CodeViews.swift` – đăng nhập, repo, duyệt file
- `GitHubMobile/EditorViews.swift` – xem/sửa file, commit, xử lý xung đột
- `GitHubMobile/CodeEditor.swift` – khung soạn code, tô màu cú pháp, phím tắt
- `GitHubMobile/Markdown.swift` – hiển thị Markdown/README
- `GitHubMobile/HistoryViews.swift` – lịch sử commit, diff
- `GitHubMobile/ActionsViews.swift` – Actions, chi tiết run, log
- `GitHubMobile/WorkflowInputs.swift` – đọc inputs của workflow_dispatch, form nhập

## Lịch sử phiên bản
- **1.2**: tải file/thư mục/zip (tự giải nén) lên repo, gói commit (nhiều thay đổi một commit), đổi tên/di chuyển/xóa file và thư mục. Lưu ý: xóa/đổi tên dùng cây thư mục của repo nên repo cực lớn (hàng chục nghìn file) sẽ báo lỗi.
- **1.1**: xử lý token hết hạn và rate limit, cảnh báo chưa commit + xử lý xung đột, lịch sử commit và diff, README Markdown, tải thêm lần chạy Actions, workflow inputs, tô màu cú pháp, phím tắt, tìm/thay thế.
- 1.0: bản đầu tiên.
