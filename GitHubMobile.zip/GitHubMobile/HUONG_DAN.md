# GitHub Mobile (iOS, SwiftUI) – phiên bản 2.12

App xem/sửa code và quản lý build GitHub Actions ngay trên điện thoại, gọi thẳng GitHub REST API.

## Tính năng
- Đăng nhập bằng Personal Access Token (lưu trong Keychain). Token sai/hết hạn (401) thì tự quay về màn đăng nhập kèm thông báo.
- Danh sách repo (có tìm kiếm), chọn nhánh. Thông báo rõ ràng khi hết lượt gọi API (rate limit) hoặc mất mạng.
- **Mã nguồn**: duyệt thư mục/file, **README hiển thị đẹp (Markdown)** ở thư mục gốc, file .md có chế độ Xem trước/Sửa.
- **Editor**: tô màu cú pháp (Swift, JS/TS, Python, YAML, JSON, Markdown, HTML/XML, shell...), thanh phím tắt trên bàn phím (Tab, ngoặc, undo/redo...), tự thụt lề khi Enter, **tìm/thay thế**, cảnh báo khi thoát mà chưa commit.
- **Tạo repo mới**: nút **+** ở màn hình danh sách repo (tên, mô tả, private/public, tạo sẵn README). Tùy chọn thêm workflow `build-from-zip.yml`: sau đó chỉ cần tải file .zip project vào repo là GitHub tự giải nén và build IPA chưa ký. Token cần quyền `repo` (và `workflow` để thêm workflow); token fine-grained cần thêm quyền Administration (đọc/ghi).
- **Tải lên**: nút **+** > "Tải file lên" / "Tải thư mục lên" (chọn từ app Tệp), xem trước danh sách rồi commit ngay hoặc thêm vào gói. File trùng đường dẫn sẽ bị ghi đè; bỏ qua file lớn hơn 90 MB, `.git`, `.DS_Store`, `__MACOSX`.
- **Tải zip lên và giải nén**: nút **+** > "Tải zip lên và giải nén". App tự giải nén ngay trên máy (zip thường, không mật khẩu, không Zip64), hiện danh sách file để xem trước. Nếu zip có đúng một thư mục gốc, công tắc "Giữ tên thư mục gốc" cho bạn chọn đưa nội dung thẳng vào vị trí hiện tại.
- **Gói commit**: gom nhiều thay đổi (sửa file, tải lên, xóa, đổi tên) rồi commit **một lần duy nhất** (tránh build nhiều lần). Biểu tượng khay kèm số thay đổi hiện ở góc trên khi gói không trống.
- **Đổi tên / di chuyển / xóa** file hoặc cả thư mục: vuốt trái hoặc nhấn giữ trên dòng file. Sửa đường dẫn đầy đủ để chuyển sang thư mục khác.
- Commit thẳng lên nhánh, tạo file mới, xóa file. Nếu file đã bị đổi trên GitHub, app hỏi: tải bản mới hay ghi đè.
- **Lịch sử**: danh sách commit (tải thêm), chi tiết commit, danh sách file đổi và **xem diff** có màu xanh/đỏ.
- **Actions**: danh sách lần chạy (tự làm mới khi đang chạy, **tải thêm** các lần cũ), chạy workflow (workflow_dispatch) **có form nhập inputs** nếu workflow khai báo, chạy lại / chạy lại job lỗi / hủy.
- Xem job, bước lỗi, **log** (lọc "chỉ lỗi", sao chép để gửi cho Claude).
- Tải artifact (ví dụ file .ipa) rồi chia sẻ/lưu vào Tệp.

## Tạo token
Vào https://github.com/settings/tokens/new , chọn quyền `repo` và `workflow` (token classic).
Token fine-grained: Contents, Actions, Metadata (đọc/ghi).

## Build bằng GitHub Actions
1. Tạo repo mới, tải lên toàn bộ nội dung thư mục này (project.yml, GitHubMobile/, ...).
2. Workflow nằm ở `.github/workflows/build.yml`. Thư mục bắt đầu bằng dấu chấm hay bị ẩn khi giải nén trên điện thoại,
   nếu thiếu thì tạo file `.github/workflows/build.yml` trên GitHub rồi dán nội dung file `build-workflow.yml` vào
   (file này là bản sao dự phòng, giữ nguyên).
3. Push lên nhánh `main` (hoặc vào Actions > Run workflow). Kết quả là artifact `GitHubMobile-ipa` (IPA **chưa ký**).
   Nếu build lỗi sẽ có thêm artifact `build-log`.
4. IPA chưa ký cần được ký lại bằng công cụ của bạn khi cài lên máy (Sideloadly, AltStore, TrollStore...).

Mã chưa được biên dịch thử trên Xcode. Nếu build lỗi, mở log trong chính app này (hoặc trên web), chọn "Sao chép" rồi gửi lại để sửa.

## Cấu trúc
- `project.yml` – cấu hình XcodeGen (iOS 16+, bundle id `com.example.githubmobile`, đổi nếu cần)
- `GitHubMobile/App.swift` – điểm vào, phiên đăng nhập, lưu token
- `GitHubMobile/API.swift` – client GitHub REST + mô hình dữ liệu
- `GitHubMobile/GitData.swift` – Git Data API: commit nhiều file/đổi tên/xóa thư mục trong một commit
- `GitHubMobile/Theme.swift` – màu, nền gradient, thẻ bo góc có viền; đổi màu chủ đạo ở `Theme.accent` / `Theme.accent2`
- `GitHubMobile/RepoCreate.swift` – tạo repo mới, mẫu workflow build từ zip
- `GitHubMobile/Zip.swift` – đọc/giải nén file .zip
- `GitHubMobile/PackViews.swift` – gói commit, tải file/thư mục lên
- `GitHubMobile/CodeViews.swift` – đăng nhập, repo, duyệt file
- `GitHubMobile/EditorViews.swift` – xem/sửa file, commit, xử lý xung đột
- `GitHubMobile/CodeEditor.swift` – khung soạn code, tô màu cú pháp, phím tắt
- `GitHubMobile/Markdown.swift` – hiển thị Markdown/README
- `GitHubMobile/RepoSearch.swift` – tìm file/nội dung trong repo
- `GitHubMobile/RepoManage.swift` – form sửa repo (tên, mô tả, riêng tư/công khai)
- `GitHubMobile/CodeComments.swift` – tách và dịch comment trong file code
- `GitHubMobile/Translate.swift` – dịch README/Markdown sang ngôn ngữ chọn (Việt, Anh, Trung, Nhật, Hàn...)
- `GitHubMobile/HistoryViews.swift` – lịch sử commit, diff
- `GitHubMobile/ActionsViews.swift` – Actions, chi tiết run, log
- `GitHubMobile/WorkflowInputs.swift` – đọc inputs của workflow_dispatch, form nhập

## Lịch sử phiên bản
- **2.12**: workflow mẫu khi tạo repo. (1) Cache SwiftPM (iOS), Gradle (Android), npm, NuGet, Flutter để build nhanh hơn; Homebrew tắt tự cập nhật. (2) Mẫu mới **Web**: build rồi đăng lên GitHub Pages (app tự thử bật Pages). (3) Mẫu mới **Chạy test Node / Python** mỗi lần push hoặc pull request. (4) Mẫu mới **iOS đã ký**: dùng 3 secret `BUILD_CERTIFICATE_BASE64`, `P12_PASSWORD`, `PROVISION_PROFILE_BASE64`; tự nhận loại profile (development, ad-hoc, enterprise, app-store) và dọn keychain sau khi build.
- **2.11**: nâng cấp editor. (1) Menu ⋯ trong file: "Danh sách hàm / lớp" (Swift, JS/TS, Python, Java/Kotlin/Go/Rust..., Markdown, YAML, shell), "Nhảy tới dòng", "Xem gấp code" (gấp/mở khối `{}`, khối thụt lề, mục Markdown; chỉ xem, chưa sửa được trong chế độ này). (2) Xem trước PDF và bảng CSV/TSV (mặc định mở bảng, chọn "Sửa" để sửa chữ). (3) "Cỡ chữ và giao diện": cỡ chữ 11-20 pt, giao diện editor sáng/tối/theo hệ thống.
- **2.10**: tab **Release**: xem danh sách release (kèm ghi chú, có nút dịch), tải file đính kèm rồi lưu vào Tệp hoặc chia sẻ, tạo release mới (thẻ, tiêu đề, ghi chú, bản thử) và xóa release. Token cần quyền `repo` (fine-grained: Contents đọc/ghi).
- **2.9.1**: (1) Chi tiết pull request có danh sách file thay đổi và xem diff từng file. (2) Menu nhánh có "Tạo nhánh mới từ nhánh đang chọn" và "Xóa nhánh" (không xóa được nhánh mặc định).
- **2.9**: (1) Tab **PR/Issue** trong repo của bạn: xem danh sách pull request và issue (đang mở/đã đóng), xem chi tiết kèm bình luận, viết bình luận, đóng/mở lại, gộp pull request (merge, squash, rebase), tạo issue mới. Token cần quyền `repo` (fine-grained: Pull requests và Issues đọc/ghi). (2) Dịch: lần đầu dùng có hộp thoại báo nội dung sẽ gửi tới Google Translate; chưa đồng ý thì không tự động dịch.
- **2.8.2**: (1) Gói commit được lưu ra đĩa, không mất khi iOS tắt app (mở lại app là còn). (2) Commit nhiều file tải lên song song (tối đa 5 file cùng lúc), nhanh hơn rõ khi có nhiều file. (3) Danh sách nhánh lấy đủ tới 500 nhánh (trước đây 100). (4) Xóa file kiểm tra có mã phiên bản trước khi gửi. (5) Workflow mẫu thêm `permissions: contents: read`, giới hạn thời gian chạy và hủy lần chạy trùng.
- **2.8**: (1) Fork có tùy chọn: đặt tên khác cho bản fork, chỉ lấy nhánh mặc định. (2) Tìm trong repo: nút 🔍 ở thư mục gốc, tìm theo tên file và nội dung (chỉ nhánh mặc định; repo mới hoặc bản fork có thể chưa được GitHub lập chỉ mục; giới hạn tìm của GitHub khoảng 10 lần/phút). (3) Gắn sao: nút ⭐ trên thanh thông tin repo người khác, và tab "Gắn sao" ở danh sách repo. (4) Thông báo build: khi tạo repo mới có thể nhập tên kênh ntfy.sh, workflow tự gửi thông báo đẩy khi build xong hoặc lỗi; cài app ntfy trên iPhone và đăng ký đúng tên kênh để nhận.
- **2.7**: siết chặt lưu token: Keychain chỉ giữ trên máy này (không vào bản sao lưu), và nếu token đang nằm ở chỗ lưu dự phòng (UserDefaults) thì tự chuyển vào Keychain khi mở app.
- **2.6**: nút tải repo về dạng .zip (biểu tượng mũi tên xuống cạnh menu nhánh) ở cả repo của người khác lẫn repo của bạn. Tải đúng nhánh đang chọn, rồi chọn "Lưu vào Tệp" hoặc chia sẻ sang app khác. Không cần fork.
- **2.5**: dịch thêm mô tả repo (danh sách, kết quả tìm), tin nhắn commit (danh sách và chi tiết) và comment trong file code. Bật "Dịch mô tả repo & commit" ở menu avatar hoặc bấm nút 💬 trên thanh công cụ màn hình lịch sử; dịch comment bằng menu ⋯ trong file ("Dịch comment sang ...", chỉ comment được dịch, code giữ nguyên, hỗ trợ file kiểu C/Swift/JS, Python, shell, YAML, HTML/XML). Ngôn ngữ đích dùng chung với dịch README.
- **2.4**: sửa và xóa repo của tôi: vuốt trái hoặc nhấn giữ một repo trong danh sách để chọn "Sửa" (đổi tên, mô tả, riêng tư/công khai) hoặc "Xóa" (phải gõ đúng tên repo để xác nhận). Xóa repo cần token có quyền `delete_repo` (token classic: tick `delete_repo`; fine-grained: Administration đọc/ghi). Chỉ hiện với repo do chính bạn làm chủ.
- **2.3**: bấm avatar rồi bấm tên đăng nhập để quay về danh sách "Repo của tôi" (thoát chế độ tìm GitHub, xóa từ khóa, tải lại danh sách).
- **2.2**: dịch README và file Markdown: nút "Dịch sang ..." phía trên README (cả khi xem repo người khác lẫn repo của bạn/bản fork), menu chọn ngôn ngữ đích (Tiếng Việt, English, 中文, 日本語, 한국어...), nút "Xem bản gốc" và tuỳ chọn "Tự động dịch README". Khối code, link và `code` trong dòng được giữ nguyên. Cần có mạng.
- **2.1**: tìm repo trên GitHub ở màn hình danh sách: chọn "GitHub" dưới ô tìm kiếm, gõ từ khóa hoặc dán link github.com/chủ/repo. Xem repo của người khác ở chế độ chỉ xem (mã nguồn, lịch sử) và nút "Thêm vào repo của tôi (Fork)", tự bật Actions cho bản fork.
- **2.0**: bàn phím tự ẩn khi vuốt danh sách/biểu mẫu, có nút "Xong" trên bàn phím ở mọi màn hình; nút "Tạo repo" và "Đăng nhập" căn giữa.
- **1.9**: hiện tiến trình build: thanh tiến độ và "Bước x/y" trên job đang chạy, danh sách từng bước (kèm đồng hồ chạy) cho job đang chạy hoặc lỗi, log tự cập nhật và tự cuộn khi job còn chạy.
- **1.8**: tải file / thư mục / zip dùng bộ chọn file gốc của iOS (UIKit) thay cho SwiftUI fileImporter để sửa lỗi nút "Mở" không phản hồi.
- **1.7**: dọn dẹp Actions: nút "Dọn dẹp lần chạy" (xóa hàng loạt lần chạy thành công / lỗi / đã hủy / tất cả đã xong), vuốt trái để xóa từng lần chạy hoặc từng artifact, menu "Xóa lần chạy này" trong chi tiết. Token cần quyền Actions: ghi (token classic: `repo`).
- **1.6**: màn hình log có nút lưu / chia sẻ log (.txt, toàn bộ hoặc chỉ dòng lỗi); workflow Android và Windows tự đính kèm artifact `build-log` khi build lỗi.
- **1.5**: tạo repo mới có thể chọn thêm workflow tự build iOS (IPA), Android (APK) và Windows (EXE) từ file zip. Chọn một nền tảng thì nhận zip ở thư mục gốc; chọn nhiều thì mỗi nền tảng có thư mục riêng (`inbox/`, `android/`, `windows/`). Sửa lỗi nút "Mở" không phản hồi khi tải file lên.
- **1.4**: giao diện mới: nền gradient (tự đổi sáng/tối), danh sách dạng thẻ bo góc có viền và bóng nhẹ, huy hiệu trạng thái build, màn hình đăng nhập có logo, khung code và editor đồng bộ màu.
- **1.3**: tạo repo mới ngay trong app (kèm workflow build từ zip), hiện rõ lý do lỗi chi tiết từ GitHub.
- **1.2**: tải file/thư mục/zip (tự giải nén) lên repo, gói commit (nhiều thay đổi một commit), đổi tên/di chuyển/xóa file và thư mục. Lưu ý: xóa/đổi tên dùng cây thư mục của repo nên repo cực lớn (hàng chục nghìn file) sẽ báo lỗi.
- **1.1**: xử lý token hết hạn và rate limit, cảnh báo chưa commit + xử lý xung đột, lịch sử commit và diff, README Markdown, tải thêm lần chạy Actions, workflow inputs, tô màu cú pháp, phím tắt, tìm/thay thế.
- 1.0: bản đầu tiên.
