import SwiftUI

// MARK: - Mẫu workflow (build IPA từ file zip tải lên repo)

enum WorkflowTemplates {
    static let buildFromZip = #"""
name: Build từ file zip

# Tải nguyên file .zip (project iOS) vào thư mục gốc hoặc thư mục inbox/ của repo.
# GitHub tự giải nén, tạo project (XcodeGen nếu có project.yml), build và xuất IPA chưa ký.
on:
  push:
    paths:
      - 'inbox/*.zip'
      - '*.zip'
  workflow_dispatch:

jobs:
  build:
    runs-on: macos-15
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 2

      - name: Giải nén zip
        run: |
          set -e
          ZIP=$(git diff --name-only --diff-filter=AM HEAD~1 HEAD 2>/dev/null | grep -E '^(inbox/)?[^/]+\.zip$' | head -1 || true)
          if [ -z "$ZIP" ]; then
            ZIP=$(ls -t inbox/*.zip *.zip 2>/dev/null | head -1 || true)
          fi
          if [ -z "$ZIP" ]; then
            echo "Không thấy file .zip nào ở thư mục gốc hoặc inbox/"
            exit 1
          fi
          echo "Dùng file: $ZIP"
          rm -rf _src && mkdir _src
          unzip -q "$ZIP" -x '__MACOSX/*' '*.DS_Store' -d _src
          # Nếu zip chỉ có đúng một thư mục gốc thì đi vào trong
          SRC=_src
          while [ "$(ls -A "$SRC" | wc -l | tr -d ' ')" = "1" ] && [ -d "$SRC/$(ls -A "$SRC")" ]; do
            SRC="$SRC/$(ls -A "$SRC")"
          done
          echo "Thư mục project: $SRC"
          echo "SRC=$SRC" >> "$GITHUB_ENV"

      - name: Cài XcodeGen
        run: brew install xcodegen

      - name: Build (không ký)
        run: |
          set -eo pipefail
          mkdir -p "$GITHUB_WORKSPACE/out"
          cd "$SRC"
          if [ -f project.yml ]; then xcodegen generate; fi
          PROJ=$(ls -d *.xcodeproj 2>/dev/null | head -1 || true)
          if [ -z "$PROJ" ]; then
            echo "Không thấy .xcodeproj hoặc project.yml trong zip"
            exit 1
          fi
          SCHEME=$(xcodebuild -list -project "$PROJ" -json | python3 -c "import sys,json; print(json.load(sys.stdin)['project']['schemes'][0])")
          echo "Scheme: $SCHEME"
          xcodebuild \
            -project "$PROJ" \
            -scheme "$SCHEME" \
            -configuration Release \
            -sdk iphoneos \
            -destination 'generic/platform=iOS' \
            -derivedDataPath build \
            CODE_SIGNING_ALLOWED=NO \
            CODE_SIGNING_REQUIRED=NO \
            CODE_SIGN_IDENTITY="" \
            build 2>&1 | tee "$GITHUB_WORKSPACE/out/build.log"
          APP=$(find build/Build/Products/Release-iphoneos -maxdepth 1 -name '*.app' | head -1)
          mkdir -p Payload
          cp -R "$APP" Payload/
          zip -qr "$GITHUB_WORKSPACE/out/$SCHEME.ipa" Payload

      - uses: actions/upload-artifact@v4
        with:
          name: ipa
          path: out/*.ipa

      - uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: build-log
          path: out/build.log
"""#
}

// MARK: - Tạo repo mới

struct NewRepoView: View {
    /// Gọi khi tạo xong; tham số thứ hai là ghi chú (ví dụ lỗi khi thêm workflow)
    var onCreated: (Repo, String?) -> Void

    @EnvironmentObject var session: Session
    @Environment(\.dismiss) private var dismiss

    @State private var name = ""
    @State private var desc = ""
    @State private var isPrivate = true
    @State private var autoInit = true
    @State private var addWorkflow = true
    @State private var busy = false
    @State private var status = ""
    @State private var error: String?

    private var cleanName: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: " ", with: "-")
    }

    private var valid: Bool {
        !cleanName.isEmpty
            && cleanName != "."
            && cleanName != ".."
            && cleanName.range(of: "^[A-Za-z0-9._-]+$", options: .regularExpression) != nil
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("ten-repo", text: $name)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                } header: {
                    Text("Tên repo")
                } footer: {
                    if !name.isEmpty && !valid {
                        Text("Chỉ dùng chữ không dấu, số, dấu - _ . (khoảng trắng sẽ đổi thành -).")
                            .foregroundStyle(.red)
                    }
                }

                Section("Mô tả (không bắt buộc)") {
                    TextField("Ví dụ: app iOS làng quê 3D", text: $desc)
                }

                Section {
                    Toggle("Riêng tư (private)", isOn: $isPrivate)
                    Toggle("Tạo sẵn README", isOn: $autoInit)
                    Toggle("Thêm workflow tự build file zip", isOn: $addWorkflow)
                } footer: {
                    Text("Nên bật README để repo có sẵn nhánh chính, dùng được ngay. Workflow cho phép tải file .zip project vào repo là GitHub tự giải nén và build IPA chưa ký.")
                }

                if let error = error {
                    Section { Text(error).foregroundStyle(.red) }
                }

                Section {
                    Button {
                        Task { await create() }
                    } label: {
                        if busy {
                            HStack(spacing: 8) {
                                ProgressView()
                                Text(status).font(.footnote)
                            }
                        } else {
                            Text("Tạo repo")
                        }
                    }
                    .disabled(!valid || busy)
                }
            }
            .themedList()
            .navigationTitle("Repo mới")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Hủy") { dismiss() }.disabled(busy)
                }
            }
        }
        .interactiveDismissDisabled(busy)
    }

    private func create() async {
        busy = true
        error = nil
        status = "Đang tạo repo..."
        defer { busy = false }
        do {
            let d = desc.trimmingCharacters(in: .whitespacesAndNewlines)
            let repo = try await session.api.createRepo(
                name: cleanName,
                description: d,
                isPrivate: isPrivate,
                autoInit: autoInit || addWorkflow
            )
            var note: String? = nil
            if addWorkflow {
                status = "Thêm workflow build..."
                if let err = await putWorkflow(repo) {
                    note = "Đã tạo repo nhưng chưa thêm được workflow: \(err)"
                }
            }
            onCreated(repo, note)
            dismiss()
        } catch let e {
            error = e.localizedDescription
        }
    }

    /// Repo vừa tạo đôi khi chưa sẵn sàng ngay, nên thử lại vài lần
    private func putWorkflow(_ repo: Repo) async -> String? {
        var last: String? = nil
        for i in 0..<4 {
            if i > 0 { try? await Task.sleep(nanoseconds: 1_500_000_000) }
            do {
                _ = try await session.api.save(
                    repo,
                    path: ".github/workflows/build-from-zip.yml",
                    data: Data(WorkflowTemplates.buildFromZip.utf8),
                    sha: nil,
                    message: "Thêm workflow build từ zip",
                    branch: repo.defaultBranch
                )
                return nil
            } catch let e {
                last = e.localizedDescription
            }
        }
        return last
    }
}
