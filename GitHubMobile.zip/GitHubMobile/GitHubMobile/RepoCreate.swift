import SwiftUI

// MARK: - Mẫu workflow (build từ file zip tải lên repo)

enum BuildPlatform: String, CaseIterable, Identifiable {
    case ios, android, windows
    var id: String { rawValue }

    var title: String {
        switch self {
        case .ios: return "iOS (IPA chưa ký)"
        case .android: return "Android (APK)"
        case .windows: return "Windows (EXE)"
        }
    }
    /// Thư mục thả file zip để kích hoạt build (khi chọn nhiều nền tảng)
    var folder: String {
        switch self {
        case .ios: return "inbox"
        case .android: return "android"
        case .windows: return "windows"
        }
    }
    var fileName: String {
        switch self {
        case .ios: return "build-from-zip.yml"
        case .android: return "build-apk-from-zip.yml"
        case .windows: return "build-exe-from-zip.yml"
        }
    }
}

enum WorkflowTemplates {
    /// Giữ lại tên cũ cho tương thích
    static var buildFromZip: String { template(.ios, single: true) }

    /// single = chỉ chọn một nền tảng: nhận cả zip ở thư mục gốc của repo.
    /// Chọn nhiều nền tảng: mỗi nền tảng chỉ nhận zip trong thư mục riêng (inbox/, android/, windows/).
    static func template(_ p: BuildPlatform, single: Bool) -> String {
        let folder = p.folder
        var paths = "      - '\(folder)/*.zip'\n"
        if single { paths += "      - '*.zip'\n" }
        let regex = single ? "^(\(folder)/)?[^/]+\\.zip$" : "^\(folder)/[^/]+\\.zip$"
        let glob = single ? "\(folder)/*.zip *.zip" : "\(folder)/*.zip"

        let header = """
        name: Build \(p.title) từ file zip

        # Tải nguyên file .zip (project) vào thư mục \(folder)/\(single ? " hoặc thư mục gốc" : "") của repo.
        # GitHub tự giải nén rồi build. Cũng có thể chạy tay: tab Actions > Run workflow (dùng zip mới nhất).
        on:
          push:
            paths:

        """ + paths + "  workflow_dispatch:\n\n"

        let body: String
        switch p {
        case .ios: body = iosBody
        case .android: body = androidBody
        case .windows: body = windowsBody
        }
        let extract = (p == .windows ? extractWin : extractUnix)
        let joined = header + body.replacingOccurrences(of: "__EXTRACT__", with: extract)
        return joined
            .replacingOccurrences(of: "__REGEX__", with: regex)
            .replacingOccurrences(of: "__GLOB__", with: glob)
    }

    // Tìm file zip mới nhất rồi giải nén (Linux/macOS)
    private static let extractUnix = #"""
      - name: Giải nén zip
        run: |
          set -e
          ZIP=$(git diff --name-only --diff-filter=AM HEAD~1 HEAD 2>/dev/null | grep -E '__REGEX__' | head -1 || true)
          if [ -z "$ZIP" ]; then
            ZIP=$(ls -t __GLOB__ 2>/dev/null | head -1 || true)
          fi
          if [ -z "$ZIP" ]; then
            echo "Không thấy file .zip nào trong repo"
            exit 1
          fi
          echo "Dùng file: $ZIP"
          rm -rf _src && mkdir _src
          unzip -q "$ZIP" -x '__MACOSX/*' '*.DS_Store' -d _src
          # Nếu zip chỉ có đúng một thư mục gốc thì đi vào trong
          SRC=_src
          while [ "$(ls -A "$SRC" | wc -l | tr -d ' ')" = "1" ] && [ -d "$SRC/$(ls -A "$SRC")" ]; do
            SRC="$SRC/$(ls -A "$SRC")"
          done
          echo "Thư mục project: $SRC"
          echo "SRC=$SRC" >> "$GITHUB_ENV"

"""#

    // Tìm file zip mới nhất rồi giải nén (Windows, chạy trong bash + python)
    private static let extractWin = #"""
      - name: Giải nén zip
        run: |
          set -e
          ZIP=$(git diff --name-only --diff-filter=AM HEAD~1 HEAD 2>/dev/null | grep -E '__REGEX__' | head -1 || true)
          if [ -z "$ZIP" ]; then
            ZIP=$(ls -t __GLOB__ 2>/dev/null | head -1 || true)
          fi
          if [ -z "$ZIP" ]; then
            echo "Không thấy file .zip nào trong repo"
            exit 1
          fi
          echo "Dùng file: $ZIP"
          rm -rf _src && mkdir _src
          python -c "import zipfile,sys; zipfile.ZipFile(sys.argv[1]).extractall('_src')" "$ZIP"
          rm -rf _src/__MACOSX
          SRC=_src
          while [ "$(ls -A "$SRC" | wc -l | tr -d ' ')" = "1" ] && [ -d "$SRC/$(ls -A "$SRC")" ]; do
            SRC="$SRC/$(ls -A "$SRC")"
          done
          echo "Thư mục project: $SRC"
          echo "SRC=$SRC" >> "$GITHUB_ENV"

"""#

    private static let iosBody = #"""
jobs:
  build:
    runs-on: macos-15
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 2

__EXTRACT__
      - name: Cài XcodeGen
        run: brew install xcodegen

      - name: Build (không ký)
        run: |
          set -eo pipefail
          mkdir -p "$GITHUB_WORKSPACE/out"
          cd "$SRC"
          if [ -f project.yml ]; then xcodegen generate; fi
          PROJ=$(ls -d *.xcodeproj 2>/dev/null | head -1 || true)
          if [ -z "$PROJ" ]; then
            echo "Không thấy .xcodeproj hoặc project.yml trong zip"
            exit 1
          fi
          SCHEME=$(xcodebuild -list -project "$PROJ" -json | python3 -c "import sys,json; print(json.load(sys.stdin)['project']['schemes'][0])")
          echo "Scheme: $SCHEME"
          xcodebuild \
            -project "$PROJ" \
            -scheme "$SCHEME" \
            -configuration Release \
            -sdk iphoneos \
            -destination 'generic/platform=iOS' \
            -derivedDataPath build \
            CODE_SIGNING_ALLOWED=NO \
            CODE_SIGNING_REQUIRED=NO \
            CODE_SIGN_IDENTITY="" \
            build 2>&1 | tee "$GITHUB_WORKSPACE/out/build.log"
          APP=$(find build/Build/Products/Release-iphoneos -maxdepth 1 -name '*.app' | head -1)
          mkdir -p Payload
          cp -R "$APP" Payload/
          zip -qr "$GITHUB_WORKSPACE/out/$SCHEME.ipa" Payload

      - uses: actions/upload-artifact@v4
        with:
          name: ipa
          path: out/*.ipa

      - uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: build-log
          path: out/build.log
"""#

    private static let androidBody = #"""
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 2

__EXTRACT__
      - name: Nhận diện loại project
        run: |
          cd "$SRC"
          if [ -f pubspec.yaml ]; then KIND=flutter
          elif [ -f gradlew ] || [ -f settings.gradle ] || [ -f settings.gradle.kts ]; then KIND=gradle
          elif [ -f package.json ] && [ -f android/gradlew ]; then KIND=node
          else
            echo "Không nhận ra project Android (cần Gradle, Flutter hoặc Capacitor/React Native)"
            exit 1
          fi
          echo "Loại project: $KIND"
          echo "KIND=$KIND" >> "$GITHUB_ENV"

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - uses: subosito/flutter-action@v2
        if: env.KIND == 'flutter'
        with:
          channel: stable

      - uses: actions/setup-node@v4
        if: env.KIND == 'node'
        with:
          node-version: 20

      - name: Build APK (debug, cài được ngay)
        run: |
          set -eo pipefail
          mkdir -p "$GITHUB_WORKSPACE/out" "$GITHUB_WORKSPACE/logs"
          build() {
          cd "$SRC"
          case "$KIND" in
            flutter)
              if [ ! -d android ]; then flutter create --platforms=android . ; fi
              flutter pub get
              flutter build apk --debug
              ;;
            gradle)
              if [ -f gradlew ]; then
                chmod +x gradlew
                ./gradlew assembleDebug --no-daemon --stacktrace
              else
                gradle assembleDebug --no-daemon --stacktrace
              fi
              ;;
            node)
              npm install
              if grep -q '"@capacitor/core"' package.json; then
                npm run build --if-present
                npx cap sync android
              fi
              cd android
              chmod +x gradlew
              ./gradlew assembleDebug --no-daemon --stacktrace
              ;;
          esac
          }
          build 2>&1 | tee "$GITHUB_WORKSPACE/logs/build.log"
          cd "$GITHUB_WORKSPACE/$SRC"
          find . -name '*.apk' -path '*outputs*' -exec cp --backup=numbered {} "$GITHUB_WORKSPACE/out/" \;
          ls -la "$GITHUB_WORKSPACE/out"
          ls "$GITHUB_WORKSPACE"/out/*.apk >/dev/null 2>&1 || { echo "Không thấy file APK sau khi build"; exit 1; }

      - uses: actions/upload-artifact@v4
        with:
          name: apk
          path: out/*.apk

      - uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: build-log
          path: logs/build.log
"""#

    private static let windowsBody = #"""
jobs:
  build:
    runs-on: windows-latest
    defaults:
      run:
        shell: bash
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 2

__EXTRACT__
      - name: Nhận diện loại project
        run: |
          cd "$SRC"
          if [ -f pubspec.yaml ]; then KIND=flutter
          elif [ -n "$(find . -maxdepth 3 -name '*.csproj' | head -1)" ]; then KIND=dotnet
          elif [ -f package.json ]; then KIND=node
          elif ls *.py >/dev/null 2>&1; then KIND=python
          else
            echo "Không nhận ra project (hỗ trợ Flutter, .NET, Electron, Python)"
            exit 1
          fi
          echo "Loại project: $KIND"
          echo "KIND=$KIND" >> "$GITHUB_ENV"

      - uses: subosito/flutter-action@v2
        if: env.KIND == 'flutter'
        with:
          channel: stable

      - uses: actions/setup-dotnet@v4
        if: env.KIND == 'dotnet'
        with:
          dotnet-version: 8.0.x

      - uses: actions/setup-node@v4
        if: env.KIND == 'node'
        with:
          node-version: 20

      - uses: actions/setup-python@v5
        if: env.KIND == 'python'
        with:
          python-version: '3.12'

      - name: Build EXE
        run: |
          set -eo pipefail
          OUT="$(cygpath -m "$GITHUB_WORKSPACE")/out"
          LOG="$(cygpath -m "$GITHUB_WORKSPACE")/logs"
          mkdir -p "$OUT" "$LOG"
          build() {
          cd "$SRC"
          case "$KIND" in
            flutter)
              if [ ! -d windows ]; then flutter create --platforms=windows . ; fi
              flutter config --enable-windows-desktop
              flutter pub get
              flutter build windows --release
              (cd build/windows/x64/runner/Release && 7z a -tzip "$OUT/app-windows.zip" .)
              ;;
            dotnet)
              P=$(find . -maxdepth 3 -name '*.csproj' | head -1)
              echo "Project: $P"
              dotnet publish "$P" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o "$OUT"
              rm -f "$OUT"/*.pdb
              ;;
            node)
              npm install
              if grep -q electron package.json; then
                npx electron-builder --win portable --publish never
                cp dist/*.exe "$OUT/"
              else
                echo "Project Node này chưa phải Electron nên chưa hỗ trợ build EXE"
                exit 1
              fi
              ;;
            python)
              python -m pip install pyinstaller
              if [ -f requirements.txt ]; then python -m pip install -r requirements.txt; fi
              M=main.py
              [ -f "$M" ] || M=app.py
              [ -f "$M" ] || M=$(ls *.py | head -1)
              pyinstaller --onefile --noconfirm "$M"
              cp dist/*.exe "$OUT/"
              ;;
          esac
          }
          build 2>&1 | tee "$LOG/build.log"
          ls -la "$OUT"

      - uses: actions/upload-artifact@v4
        with:
          name: windows
          path: out/*
          if-no-files-found: error

      - uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: build-log
          path: logs/build.log
"""#
}

// MARK: - Tạo repo mới


struct NewRepoView: View {
    /// Gọi khi tạo xong; tham số thứ hai là ghi chú (ví dụ lỗi khi thêm workflow)
    var onCreated: (Repo, String?) -> Void

    @EnvironmentObject var session: Session
    @Environment(\.dismiss) private var dismiss

    @State private var name = ""
    @State private var desc = ""
    @State private var isPrivate = true
    @State private var autoInit = true
    @State private var addIOS = true
    @State private var addAndroid = false
    @State private var addWindows = false
    @State private var busy = false
    @State private var status = ""
    @State private var error: String?

    private var cleanName: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: " ", with: "-")
    }

    private var selected: [BuildPlatform] {
        var r: [BuildPlatform] = []
        if addIOS { r.append(.ios) }
        if addAndroid { r.append(.android) }
        if addWindows { r.append(.windows) }
        return r
    }

    private var workflowFooter: String {
        let sel = selected
        if sel.isEmpty { return "Không thêm workflow. Bạn có thể tự thêm file .github/workflows/*.yml sau." }
        if sel.count == 1 {
            return "Tải file .zip project vào repo (thư mục gốc hoặc \(sel[0].folder)/) là GitHub tự giải nén và build. Kết quả nằm ở mục Artifacts của lần chạy."
        }
        let dirs = sel.map { "\($0.folder)/" }.joined(separator: ", ")
        return "Chọn nhiều nền tảng nên mỗi nền tảng có thư mục zip riêng: " + dirs + ". Thả zip vào đúng thư mục để build đúng nền tảng. Kết quả nằm ở mục Artifacts."
    }

    private var valid: Bool {
        !cleanName.isEmpty
            && cleanName != "."
            && cleanName != ".."
            && cleanName.range(of: "^[A-Za-z0-9._-]+$", options: .regularExpression) != nil
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("ten-repo", text: $name)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                } header: {
                    Text("Tên repo")
                } footer: {
                    if !name.isEmpty && !valid {
                        Text("Chỉ dùng chữ không dấu, số, dấu - _ . (khoảng trắng sẽ đổi thành -).")
                            .foregroundStyle(.red)
                    }
                }

                Section("Mô tả (không bắt buộc)") {
                    TextField("Ví dụ: app iOS làng quê 3D", text: $desc)
                }

                Section {
                    Toggle("Riêng tư (private)", isOn: $isPrivate)
                    Toggle("Tạo sẵn README", isOn: $autoInit)
                } footer: {
                    Text("Nên bật README để repo có sẵn nhánh chính, dùng được ngay.")
                }

                Section {
                    Toggle("iOS – build IPA chưa ký", isOn: $addIOS)
                    Toggle("Android – build APK", isOn: $addAndroid)
                    Toggle("Windows – build EXE", isOn: $addWindows)
                } header: {
                    Text("Workflow tự build file zip")
                } footer: {
                    Text(workflowFooter)
                }

                if let error = error {
                    Section { Text(error).foregroundStyle(.red) }
                }

                Section {
                    Button {
                        Task { await create() }
                    } label: {
                        if busy {
                            HStack(spacing: 8) {
                                ProgressView()
                                Text(status).font(.footnote)
                            }
                        } else {
                            Text("Tạo repo")
                        }
                    }
                    .disabled(!valid || busy)
                }
            }
            .themedList()
            .navigationTitle("Repo mới")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Hủy") { dismiss() }.disabled(busy)
                }
            }
        }
        .interactiveDismissDisabled(busy)
    }

    private func create() async {
        busy = true
        error = nil
        status = "Đang tạo repo..."
        defer { busy = false }
        do {
            let d = desc.trimmingCharacters(in: .whitespacesAndNewlines)
            let repo = try await session.api.createRepo(
                name: cleanName,
                description: d,
                isPrivate: isPrivate,
                autoInit: autoInit || !selected.isEmpty
            )
            var notes: [String] = []
            let sel = selected
            for p in sel {
                status = "Thêm workflow \(p.title)..."
                let yml = WorkflowTemplates.template(p, single: sel.count == 1)
                if let err = await putFile(repo,
                                           path: ".github/workflows/\(p.fileName)",
                                           data: Data(yml.utf8),
                                           message: "Thêm workflow build \(p.title) từ zip") {
                    notes.append("\(p.title): \(err)")
                } else {
                    // Tạo sẵn thư mục thả zip
                    _ = await putFile(repo,
                                      path: "\(p.folder)/.gitkeep",
                                      data: Data("Thả file .zip project vào thư mục này\n".utf8),
                                      message: "Tạo thư mục \(p.folder)")
                }
            }
            let note: String? = notes.isEmpty ? nil
                : "Đã tạo repo nhưng chưa thêm được workflow: " + notes.joined(separator: "; ")
            onCreated(repo, note)
            dismiss()
        } catch let e {
            error = e.localizedDescription
        }
    }

    /// Repo vừa tạo đôi khi chưa sẵn sàng ngay, nên thử lại vài lần
    private func putFile(_ repo: Repo, path: String, data: Data, message: String) async -> String? {
        var last: String? = nil
        for i in 0..<4 {
            if i > 0 { try? await Task.sleep(nanoseconds: 1_500_000_000) }
            do {
                _ = try await session.api.save(
                    repo,
                    path: path,
                    data: data,
                    sha: nil,
                    message: message,
                    branch: repo.defaultBranch
                )
                return nil
            } catch let e {
                last = e.localizedDescription
            }
        }
        return last
    }
}
