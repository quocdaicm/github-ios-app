import SwiftUI

// MARK: - Mẫu workflow (build từ file zip tải lên repo)

enum BuildPlatform: String, CaseIterable, Identifiable {
    case ios, iosSigned, android, windows, web, test
    var id: String { rawValue }

    var title: String {
        switch self {
        case .ios: return "iOS (IPA chưa ký)"
        case .iosSigned: return "iOS (IPA đã ký)"
        case .android: return "Android (APK)"
        case .windows: return "Windows (EXE)"
        case .web: return "Web (GitHub Pages)"
        case .test: return "Chạy test (Node/Python)"
        }
    }

    /// Workflow chạy khi có file zip mới (riêng "test" chạy theo mỗi lần push)
    var usesZip: Bool { self != .test }

    /// Thư mục thả file zip để kích hoạt build (khi chọn nhiều nền tảng)
    var folder: String {
        switch self {
        case .ios: return "inbox"
        case .iosSigned: return "signed"
        case .android: return "android"
        case .windows: return "windows"
        case .web: return "web"
        case .test: return ""
        }
    }

    var fileName: String {
        switch self {
        case .ios: return "build-from-zip.yml"
        case .iosSigned: return "build-ipa-signed-from-zip.yml"
        case .android: return "build-apk-from-zip.yml"
        case .windows: return "build-exe-from-zip.yml"
        case .web: return "deploy-web-from-zip.yml"
        case .test: return "test.yml"
        }
    }
}

enum WorkflowTemplates {
    /// Giữ lại tên cũ cho tương thích
    static var buildFromZip: String { template(.ios, single: true) }

    /// single = chỉ chọn một nền tảng: nhận cả zip ở thư mục gốc của repo.
    /// Chọn nhiều nền tảng: mỗi nền tảng chỉ nhận zip trong thư mục riêng (inbox/, android/, windows/).
    static func template(_ p: BuildPlatform, single: Bool, ntfy: String = "") -> String {
        if p == .test {
            var t = testTemplate
            if !ntfy.isEmpty { t += "\n" + ntfyStep.replacingOccurrences(of: "__TOPIC__", with: ntfy) }
            return t
        }
        let folder = p.folder
        var paths = "      - '\(folder)/*.zip'\n"
        if single { paths += "      - '*.zip'\n" }
        let regex = single ? "^(\(folder)/)?[^/]+\\.zip$" : "^\(folder)/[^/]+\\.zip$"
        let glob = single ? "\(folder)/*.zip *.zip" : "\(folder)/*.zip"

        let header = """
        name: Build \(p.title) từ file zip

        # Tải nguyên file .zip (project) vào thư mục \(folder)/\(single ? " hoặc thư mục gốc" : "") của repo.
        # GitHub tự giải nén rồi build. Cũng có thể chạy tay: tab Actions > Run workflow (dùng zip mới nhất).
        on:
          push:
            paths:

        """ + paths + "  workflow_dispatch:\n\n"

        let body: String
        switch p {
        case .ios: body = iosBody
        case .iosSigned: body = iosSignedBody
        case .android: body = androidBody
        case .windows: body = windowsBody
        case .web: body = webBody
        case .test: body = ""
        }
        let extract = (p == .windows ? extractWin : extractUnix)
        let joined = header + body.replacingOccurrences(of: "__EXTRACT__", with: extract)
        var result = joined
            .replacingOccurrences(of: "__REGEX__", with: regex)
            .replacingOccurrences(of: "__GLOB__", with: glob)
        if !ntfy.isEmpty {
            result += "\n" + ntfyStep.replacingOccurrences(of: "__TOPIC__", with: ntfy)
        }
        return result
    }

    // Bước cuối: gửi thông báo đẩy qua ntfy.sh khi build xong (dù thành công hay lỗi)
    private static let ntfyStep = #"""

      - name: Thông báo khi build xong (ntfy.sh)
        if: always()
        shell: bash
        run: |
          curl -s -m 20 \
            -H "Title: Build ${{ job.status }} - ${{ github.repository }}" \
            -H "Click: ${{ github.server_url }}/${{ github.repository }}/actions/runs/${{ github.run_id }}" \
            -d "${{ github.workflow }}: ${{ job.status }}" \
            https://ntfy.sh/__TOPIC__ || true
"""#

    // Tìm file zip mới nhất rồi giải nén (Linux/macOS)
    private static let extractUnix = #"""
      - name: Giải nén zip
        run: |
          set -e
          ZIP=$(git diff --name-only --diff-filter=AM HEAD~1 HEAD 2>/dev/null | grep -E '__REGEX__' | head -1 || true)
          if [ -z "$ZIP" ]; then
            ZIP=$(ls -t __GLOB__ 2>/dev/null | head -1 || true)
          fi
          if [ -z "$ZIP" ]; then
            echo "Không thấy file .zip nào trong repo"
            exit 1
          fi
          echo "Dùng file: $ZIP"
          rm -rf _src && mkdir _src
          unzip -q "$ZIP" -x '__MACOSX/*' '*.DS_Store' -d _src
          # Nếu zip chỉ có đúng một thư mục gốc thì đi vào trong
          SRC=_src
          while [ "$(ls -A "$SRC" | wc -l | tr -d ' ')" = "1" ] && [ -d "$SRC/$(ls -A "$SRC")" ]; do
            SRC="$SRC/$(ls -A "$SRC")"
          done
          echo "Thư mục project: $SRC"
          echo "SRC=$SRC" >> "$GITHUB_ENV"

"""#

    // Tìm file zip mới nhất rồi giải nén (Windows, chạy trong bash + python)
    private static let extractWin = #"""
      - name: Giải nén zip
        run: |
          set -e
          ZIP=$(git diff --name-only --diff-filter=AM HEAD~1 HEAD 2>/dev/null | grep -E '__REGEX__' | head -1 || true)
          if [ -z "$ZIP" ]; then
            ZIP=$(ls -t __GLOB__ 2>/dev/null | head -1 || true)
          fi
          if [ -z "$ZIP" ]; then
            echo "Không thấy file .zip nào trong repo"
            exit 1
          fi
          echo "Dùng file: $ZIP"
          rm -rf _src && mkdir _src
          python -c "import zipfile,sys; zipfile.ZipFile(sys.argv[1]).extractall('_src')" "$ZIP"
          rm -rf _src/__MACOSX
          SRC=_src
          while [ "$(ls -A "$SRC" | wc -l | tr -d ' ')" = "1" ] && [ -d "$SRC/$(ls -A "$SRC")" ]; do
            SRC="$SRC/$(ls -A "$SRC")"
          done
          echo "Thư mục project: $SRC"
          echo "SRC=$SRC" >> "$GITHUB_ENV"

"""#


    // Chạy test Node / Python mỗi lần push hoặc pull request (không cần file zip)
    private static let testTemplate = #"""
name: Chạy test (Node / Python)

# Tự chạy khi push lên nhánh main hoặc mở pull request. Cũng chạy tay được: tab Actions > Run workflow.
on:
  push:
    branches: [main]
  pull_request:
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: test-${{ github.ref }}
  cancel-in-progress: true

jobs:
  test:
    runs-on: ubuntu-latest
    timeout-minutes: 20
    steps:
      - uses: actions/checkout@v4

      - name: Nhận diện project
        run: |
          NODE=false
          PY=false
          if [ -f package.json ]; then NODE=true; fi
          if [ -f requirements.txt ] || [ -f pyproject.toml ] || [ -f setup.py ] || ls *.py >/dev/null 2>&1; then PY=true; fi
          echo "NODE=$NODE" >> "$GITHUB_ENV"
          echo "PY=$PY" >> "$GITHUB_ENV"
          if [ "$NODE" = false ] && [ "$PY" = false ]; then
            echo "Không thấy project Node hay Python trong repo, bỏ qua."
          fi

      - uses: actions/setup-node@v4
        if: env.NODE == 'true'
        with:
          node-version: 20

      - name: Cache npm
        if: env.NODE == 'true'
        uses: actions/cache@v4
        with:
          path: ~/.npm
          key: npm-${{ runner.os }}-${{ hashFiles('**/package-lock.json') }}
          restore-keys: npm-${{ runner.os }}-

      - name: Test Node
        if: env.NODE == 'true'
        run: |
          set -eo pipefail
          if [ -f package-lock.json ]; then npm ci; else npm install; fi
          npm test --if-present

      - uses: actions/setup-python@v5
        if: env.PY == 'true'
        with:
          python-version: '3.12'

      - name: Cache pip
        if: env.PY == 'true'
        uses: actions/cache@v4
        with:
          path: ~/.cache/pip
          key: pip-${{ runner.os }}-${{ hashFiles('**/requirements*.txt', '**/pyproject.toml') }}
          restore-keys: pip-${{ runner.os }}-

      - name: Test Python
        if: env.PY == 'true'
        run: |
          python -m pip install --upgrade pip
          if [ -f requirements.txt ]; then python -m pip install -r requirements.txt; fi
          if [ -f pyproject.toml ] || [ -f setup.py ]; then python -m pip install -e . || true; fi
          python -m pip install pytest
          set +e
          pytest -q
          CODE=$?
          if [ "$CODE" -eq 5 ]; then
            echo "Chưa có test nào."
            exit 0
          fi
          exit "$CODE"
"""#

    // Build web rồi đăng lên GitHub Pages
    private static let webBody = #"""
# Lưu ý: với Vite/React Router, hãy đặt base là "/<tên-repo>/" để site chạy đúng trên GitHub Pages.
permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: pages
  cancel-in-progress: false

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 2

__EXTRACT__
      - uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Cache npm
        uses: actions/cache@v4
        with:
          path: ~/.npm
          key: npm-${{ runner.os }}-${{ hashFiles('_src/**/package-lock.json') }}
          restore-keys: npm-${{ runner.os }}-

      - name: Build web
        run: |
          set -eo pipefail
          cd "$SRC"
          OUT=""
          if [ -f package.json ]; then
            if [ -f package-lock.json ]; then npm ci; else npm install; fi
            if grep -q '"build"' package.json; then npm run build; fi
            for d in dist build out _site public; do
              if [ -f "$d/index.html" ]; then OUT="$d"; break; fi
            done
          fi
          if [ -z "$OUT" ] && [ -f index.html ]; then OUT="."; fi
          if [ -z "$OUT" ]; then
            F=$(find . -maxdepth 2 -name index.html -not -path '*/node_modules/*' | head -1 || true)
            if [ -n "$F" ]; then OUT="$(dirname "$F")"; fi
          fi
          if [ -z "$OUT" ]; then
            echo "Không tìm thấy index.html sau khi build"
            exit 1
          fi
          echo "Thư mục đăng: $SRC/$OUT"
          echo "SITE=$SRC/$OUT" >> "$GITHUB_ENV"

      - uses: actions/configure-pages@v5

      - uses: actions/upload-pages-artifact@v3
        with:
          path: ${{ env.SITE }}

  deploy:
    needs: build
    runs-on: ubuntu-latest
    timeout-minutes: 10
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - name: Đăng lên GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
"""#

    // iOS: build và ký bằng chứng chỉ + provisioning profile lưu trong Secrets
    private static let iosSignedBody = #"""
# Cần 3 secret (GitHub web: Settings > Secrets and variables > Actions):
#   BUILD_CERTIFICATE_BASE64  = file chứng chỉ .p12, mã hóa base64
#   P12_PASSWORD              = mật khẩu của file .p12
#   PROVISION_PROFILE_BASE64  = file .mobileprovision, mã hóa base64
# (KEYCHAIN_PASSWORD không bắt buộc, không có thì tự tạo ngẫu nhiên)
# Hỗ trợ app có một target; app có extension cần nhiều profile thì phải chỉnh tay.
permissions:
  contents: read

jobs:
  build:
    runs-on: macos-15
    timeout-minutes: 45
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 2

__EXTRACT__
      - name: Cache SwiftPM
        uses: actions/cache@v4
        with:
          path: ${{ env.SRC }}/build/SourcePackages
          key: spm-${{ runner.os }}-${{ hashFiles('_src/**/Package.resolved') }}
          restore-keys: spm-${{ runner.os }}-

      - name: Cài XcodeGen
        env:
          HOMEBREW_NO_AUTO_UPDATE: 1
          HOMEBREW_NO_INSTALL_CLEANUP: 1
          HOMEBREW_NO_ANALYTICS: 1
        run: brew install xcodegen

      - name: Cài chứng chỉ và provisioning profile
        env:
          BUILD_CERTIFICATE_BASE64: ${{ secrets.BUILD_CERTIFICATE_BASE64 }}
          P12_PASSWORD: ${{ secrets.P12_PASSWORD }}
          PROVISION_PROFILE_BASE64: ${{ secrets.PROVISION_PROFILE_BASE64 }}
          KEYCHAIN_PASSWORD: ${{ secrets.KEYCHAIN_PASSWORD }}
        run: |
          set -eo pipefail
          for v in BUILD_CERTIFICATE_BASE64 P12_PASSWORD PROVISION_PROFILE_BASE64; do
            if [ -z "${!v}" ]; then
              echo "Thiếu secret $v (Settings > Secrets and variables > Actions)"
              exit 1
            fi
          done
          KC_PASS="${KEYCHAIN_PASSWORD:-$(uuidgen)}"
          CERT="$RUNNER_TEMP/cert.p12"
          PP="$RUNNER_TEMP/profile.mobileprovision"
          PLIST="$RUNNER_TEMP/profile.plist"
          KC="$RUNNER_TEMP/build.keychain-db"
          PB=/usr/libexec/PlistBuddy

          echo -n "$BUILD_CERTIFICATE_BASE64" | base64 --decode -o "$CERT"
          echo -n "$PROVISION_PROFILE_BASE64" | base64 --decode -o "$PP"

          security create-keychain -p "$KC_PASS" "$KC"
          security set-keychain-settings -lut 21600 "$KC"
          security unlock-keychain -p "$KC_PASS" "$KC"
          security import "$CERT" -P "$P12_PASSWORD" -A -t cert -f pkcs12 -k "$KC"
          security set-key-partition-list -S apple-tool:,apple: -k "$KC_PASS" "$KC" >/dev/null
          security list-keychain -d user -s "$KC"

          security cms -D -i "$PP" > "$PLIST"
          PUUID=$($PB -c "Print :UUID" "$PLIST")
          PNAME=$($PB -c "Print :Name" "$PLIST")
          TEAM=$($PB -c "Print :TeamIdentifier:0" "$PLIST")
          APPID=$($PB -c "Print :Entitlements:application-identifier" "$PLIST")
          BUNDLE="${APPID#*.}"

          if [ "$($PB -c 'Print :Entitlements:get-task-allow' "$PLIST" 2>/dev/null || true)" = "true" ]; then
            METHOD=development
          elif $PB -c 'Print :ProvisionsAllDevices' "$PLIST" >/dev/null 2>&1; then
            METHOD=enterprise
          elif $PB -c 'Print :ProvisionedDevices' "$PLIST" >/dev/null 2>&1; then
            METHOD=ad-hoc
          else
            METHOD=app-store
          fi

          mkdir -p "$HOME/Library/MobileDevice/Provisioning Profiles"
          cp "$PP" "$HOME/Library/MobileDevice/Provisioning Profiles/$PUUID.mobileprovision"

          SIGN_ID=$(security find-identity -v -p codesigning "$KC" | grep -m1 '"' | sed -E 's/.*"(.*)"$/\1/')
          if [ -z "$SIGN_ID" ]; then
            echo "Không tìm thấy chứng chỉ ký trong file .p12"
            exit 1
          fi

          echo "Profile: $PNAME ($METHOD), team $TEAM, bundle $BUNDLE"
          {
            echo "PROFILE_NAME=$PNAME"
            echo "TEAM_ID=$TEAM"
            echo "PROFILE_BUNDLE=$BUNDLE"
            echo "EXPORT_METHOD=$METHOD"
            echo "SIGN_ID=$SIGN_ID"
          } >> "$GITHUB_ENV"

      - name: Build và ký
        run: |
          set -eo pipefail
          mkdir -p "$GITHUB_WORKSPACE/out"
          cd "$SRC"
          if [ -f project.yml ]; then xcodegen generate; fi
          PROJ=$(ls -d *.xcodeproj 2>/dev/null | head -1 || true)
          if [ -z "$PROJ" ]; then
            echo "Không thấy .xcodeproj hoặc project.yml trong zip"
            exit 1
          fi
          SCHEME=$(xcodebuild -list -project "$PROJ" -json | python3 -c "import sys,json; print(json.load(sys.stdin)['project']['schemes'][0])")
          echo "Scheme: $SCHEME"
          EXTRA=""
          case "$PROFILE_BUNDLE" in
            "*"|*".*") ;;
            *) EXTRA="PRODUCT_BUNDLE_IDENTIFIER=$PROFILE_BUNDLE" ;;
          esac
          xcodebuild \
            -project "$PROJ" \
            -scheme "$SCHEME" \
            -configuration Release \
            -sdk iphoneos \
            -destination 'generic/platform=iOS' \
            -derivedDataPath build \
            -archivePath build/app.xcarchive \
            CODE_SIGN_STYLE=Manual \
            DEVELOPMENT_TEAM="$TEAM_ID" \
            CODE_SIGN_IDENTITY="$SIGN_ID" \
            PROVISIONING_PROFILE_SPECIFIER="$PROFILE_NAME" \
            $EXTRA \
            archive 2>&1 | tee "$GITHUB_WORKSPACE/out/build.log"

          APP=$(find build/app.xcarchive/Products/Applications -maxdepth 1 -name '*.app' | head -1)
          BID=$(/usr/libexec/PlistBuddy -c "Print :CFBundleIdentifier" "$APP/Info.plist")
          cat > "$RUNNER_TEMP/ExportOptions.plist" <<EOF
          <?xml version="1.0" encoding="UTF-8"?>
          <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
          <plist version="1.0">
          <dict>
            <key>method</key><string>$EXPORT_METHOD</string>
            <key>teamID</key><string>$TEAM_ID</string>
            <key>signingStyle</key><string>manual</string>
            <key>signingCertificate</key><string>$SIGN_ID</string>
            <key>provisioningProfiles</key>
            <dict><key>$BID</key><string>$PROFILE_NAME</string></dict>
          </dict>
          </plist>
          EOF
          xcodebuild -exportArchive \
            -archivePath build/app.xcarchive \
            -exportPath "$GITHUB_WORKSPACE/out" \
            -exportOptionsPlist "$RUNNER_TEMP/ExportOptions.plist" 2>&1 | tee -a "$GITHUB_WORKSPACE/out/build.log"

      - name: Dọn chứng chỉ
        if: always()
        run: |
          security delete-keychain "$RUNNER_TEMP/build.keychain-db" 2>/dev/null || true
          rm -f "$HOME/Library/MobileDevice/Provisioning Profiles/"*.mobileprovision || true

      - uses: actions/upload-artifact@v4
        with:
          name: ipa-signed
          path: out/*.ipa
          if-no-files-found: error

      - uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: build-log
          path: out/build.log
"""#

    private static let iosBody = #"""
permissions:
  contents: read

jobs:
  build:
    runs-on: macos-15
    timeout-minutes: 45
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 2

__EXTRACT__
      - name: Cache SwiftPM
        uses: actions/cache@v4
        with:
          path: ${{ env.SRC }}/build/SourcePackages
          key: spm-${{ runner.os }}-${{ hashFiles('_src/**/Package.resolved') }}
          restore-keys: spm-${{ runner.os }}-

      - name: Cài XcodeGen
        env:
          HOMEBREW_NO_AUTO_UPDATE: 1
          HOMEBREW_NO_INSTALL_CLEANUP: 1
          HOMEBREW_NO_ANALYTICS: 1
        run: brew install xcodegen

      - name: Build (không ký)
        run: |
          set -eo pipefail
          mkdir -p "$GITHUB_WORKSPACE/out"
          cd "$SRC"
          if [ -f project.yml ]; then xcodegen generate; fi
          PROJ=$(ls -d *.xcodeproj 2>/dev/null | head -1 || true)
          if [ -z "$PROJ" ]; then
            echo "Không thấy .xcodeproj hoặc project.yml trong zip"
            exit 1
          fi
          SCHEME=$(xcodebuild -list -project "$PROJ" -json | python3 -c "import sys,json; print(json.load(sys.stdin)['project']['schemes'][0])")
          echo "Scheme: $SCHEME"
          xcodebuild \
            -project "$PROJ" \
            -scheme "$SCHEME" \
            -configuration Release \
            -sdk iphoneos \
            -destination 'generic/platform=iOS' \
            -derivedDataPath build \
            CODE_SIGNING_ALLOWED=NO \
            CODE_SIGNING_REQUIRED=NO \
            CODE_SIGN_IDENTITY="" \
            build 2>&1 | tee "$GITHUB_WORKSPACE/out/build.log"
          APP=$(find build/Build/Products/Release-iphoneos -maxdepth 1 -name '*.app' | head -1)
          mkdir -p Payload
          cp -R "$APP" Payload/
          zip -qr "$GITHUB_WORKSPACE/out/$SCHEME.ipa" Payload

      - uses: actions/upload-artifact@v4
        with:
          name: ipa
          path: out/*.ipa

      - uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: build-log
          path: out/build.log
"""#

    private static let androidBody = #"""
permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 45
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 2

__EXTRACT__
      - name: Nhận diện loại project
        run: |
          cd "$SRC"
          if [ -f pubspec.yaml ]; then KIND=flutter
          elif [ -f gradlew ] || [ -f settings.gradle ] || [ -f settings.gradle.kts ]; then KIND=gradle
          elif [ -f package.json ] && [ -f android/gradlew ]; then KIND=node
          else
            echo "Không nhận ra project Android (cần Gradle, Flutter hoặc Capacitor/React Native)"
            exit 1
          fi
          echo "Loại project: $KIND"
          echo "KIND=$KIND" >> "$GITHUB_ENV"

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Cache Gradle
        uses: actions/cache@v4
        with:
          path: |
            ~/.gradle/caches
            ~/.gradle/wrapper
          key: gradle-${{ runner.os }}-${{ hashFiles('_src/**/*.gradle*', '_src/**/gradle-wrapper.properties', '_src/**/pubspec.lock') }}
          restore-keys: gradle-${{ runner.os }}-

      - uses: subosito/flutter-action@v2
        if: env.KIND == 'flutter'
        with:
          channel: stable
          cache: true

      - uses: actions/setup-node@v4
        if: env.KIND == 'node'
        with:
          node-version: 20

      - name: Cache npm
        if: env.KIND == 'node'
        uses: actions/cache@v4
        with:
          path: ~/.npm
          key: npm-${{ runner.os }}-${{ hashFiles('_src/**/package-lock.json') }}
          restore-keys: npm-${{ runner.os }}-

      - name: Build APK (debug, cài được ngay)
        run: |
          set -eo pipefail
          mkdir -p "$GITHUB_WORKSPACE/out" "$GITHUB_WORKSPACE/logs"
          build() {
          cd "$SRC"
          case "$KIND" in
            flutter)
              if [ ! -d android ]; then flutter create --platforms=android . ; fi
              flutter pub get
              flutter build apk --debug
              ;;
            gradle)
              if [ -f gradlew ]; then
                chmod +x gradlew
                ./gradlew assembleDebug --no-daemon --stacktrace
              else
                gradle assembleDebug --no-daemon --stacktrace
              fi
              ;;
            node)
              npm install
              if grep -q '"@capacitor/core"' package.json; then
                npm run build --if-present
                npx cap sync android
              fi
              cd android
              chmod +x gradlew
              ./gradlew assembleDebug --no-daemon --stacktrace
              ;;
          esac
          }
          build 2>&1 | tee "$GITHUB_WORKSPACE/logs/build.log"
          cd "$GITHUB_WORKSPACE/$SRC"
          find . -name '*.apk' -path '*outputs*' -exec cp --backup=numbered {} "$GITHUB_WORKSPACE/out/" \;
          ls -la "$GITHUB_WORKSPACE/out"
          ls "$GITHUB_WORKSPACE"/out/*.apk >/dev/null 2>&1 || { echo "Không thấy file APK sau khi build"; exit 1; }

      - uses: actions/upload-artifact@v4
        with:
          name: apk
          path: out/*.apk

      - uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: build-log
          path: logs/build.log
"""#

    private static let windowsBody = #"""
permissions:
  contents: read

jobs:
  build:
    runs-on: windows-latest
    timeout-minutes: 45
    defaults:
      run:
        shell: bash
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 2

__EXTRACT__
      - name: Nhận diện loại project
        run: |
          cd "$SRC"
          if [ -f pubspec.yaml ]; then KIND=flutter
          elif [ -n "$(find . -maxdepth 3 -name '*.csproj' | head -1)" ]; then KIND=dotnet
          elif [ -f package.json ]; then KIND=node
          elif ls *.py >/dev/null 2>&1; then KIND=python
          else
            echo "Không nhận ra project (hỗ trợ Flutter, .NET, Electron, Python)"
            exit 1
          fi
          echo "Loại project: $KIND"
          echo "KIND=$KIND" >> "$GITHUB_ENV"

      - uses: subosito/flutter-action@v2
        if: env.KIND == 'flutter'
        with:
          channel: stable
          cache: true

      - uses: actions/setup-dotnet@v4
        if: env.KIND == 'dotnet'
        with:
          dotnet-version: 8.0.x

      - name: Cache NuGet
        if: env.KIND == 'dotnet'
        uses: actions/cache@v4
        with:
          path: ~/.nuget/packages
          key: nuget-${{ runner.os }}-${{ hashFiles('_src/**/*.csproj', '_src/**/packages.lock.json') }}
          restore-keys: nuget-${{ runner.os }}-

      - uses: actions/setup-node@v4
        if: env.KIND == 'node'
        with:
          node-version: 20

      - name: Cache npm
        if: env.KIND == 'node'
        uses: actions/cache@v4
        with:
          path: ~/.npm
          key: npm-${{ runner.os }}-${{ hashFiles('_src/**/package-lock.json') }}
          restore-keys: npm-${{ runner.os }}-

      - uses: actions/setup-python@v5
        if: env.KIND == 'python'
        with:
          python-version: '3.12'

      - name: Build EXE
        run: |
          set -eo pipefail
          OUT="$(cygpath -m "$GITHUB_WORKSPACE")/out"
          LOG="$(cygpath -m "$GITHUB_WORKSPACE")/logs"
          mkdir -p "$OUT" "$LOG"
          build() {
          cd "$SRC"
          case "$KIND" in
            flutter)
              if [ ! -d windows ]; then flutter create --platforms=windows . ; fi
              flutter config --enable-windows-desktop
              flutter pub get
              flutter build windows --release
              (cd build/windows/x64/runner/Release && 7z a -tzip "$OUT/app-windows.zip" .)
              ;;
            dotnet)
              P=$(find . -maxdepth 3 -name '*.csproj' | head -1)
              echo "Project: $P"
              dotnet publish "$P" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o "$OUT"
              rm -f "$OUT"/*.pdb
              ;;
            node)
              npm install
              if grep -q electron package.json; then
                npx electron-builder --win portable --publish never
                cp dist/*.exe "$OUT/"
              else
                echo "Project Node này chưa phải Electron nên chưa hỗ trợ build EXE"
                exit 1
              fi
              ;;
            python)
              python -m pip install pyinstaller
              if [ -f requirements.txt ]; then python -m pip install -r requirements.txt; fi
              M=main.py
              [ -f "$M" ] || M=app.py
              [ -f "$M" ] || M=$(ls *.py | head -1)
              pyinstaller --onefile --noconfirm "$M"
              cp dist/*.exe "$OUT/"
              ;;
          esac
          }
          build 2>&1 | tee "$LOG/build.log"
          ls -la "$OUT"

      - uses: actions/upload-artifact@v4
        with:
          name: windows
          path: out/*
          if-no-files-found: error

      - uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: build-log
          path: logs/build.log
"""#
}

// MARK: - Tạo repo mới


struct NewRepoView: View {
    /// Gọi khi tạo xong; tham số thứ hai là ghi chú (ví dụ lỗi khi thêm workflow)
    var onCreated: (Repo, String?) -> Void

    @EnvironmentObject var session: Session
    @Environment(\.dismiss) private var dismiss

    @State private var name = ""
    @State private var desc = ""
    @State private var isPrivate = true
    @State private var autoInit = true
    @State private var addIOS = true
    @State private var addAndroid = false
    @State private var addWindows = false
    @State private var addIOSSigned = false
    @State private var addWeb = false
    @State private var addTest = false
    @State private var ntfyTopic = ""
    @State private var busy = false
    @State private var status = ""
    @State private var error: String?

    private var cleanName: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: " ", with: "-")
    }

    private var selected: [BuildPlatform] {
        var r: [BuildPlatform] = []
        if addIOS { r.append(.ios) }
        if addIOSSigned { r.append(.iosSigned) }
        if addAndroid { r.append(.android) }
        if addWindows { r.append(.windows) }
        if addWeb { r.append(.web) }
        if addTest { r.append(.test) }
        return r
    }

    private var workflowFooter: String {
        let sel = selected
        if sel.isEmpty { return "Không thêm workflow. Bạn có thể tự thêm file .github/workflows/*.yml sau." }
        var parts: [String] = []
        let z = sel.filter { $0.usesZip }
        if z.count == 1 {
            parts.append("Tải file .zip project vào repo (thư mục gốc hoặc \(z[0].folder)/) là GitHub tự giải nén và build. Kết quả nằm ở mục Artifacts của lần chạy.")
        } else if z.count > 1 {
            let dirs = z.map { "\($0.folder)/" }.joined(separator: ", ")
            parts.append("Chọn nhiều nền tảng nên mỗi nền tảng có thư mục zip riêng: " + dirs + ". Thả zip vào đúng thư mục để build đúng nền tảng. Kết quả nằm ở mục Artifacts.")
        }
        if sel.contains(.iosSigned) {
            parts.append("iOS đã ký cần 3 secret: BUILD_CERTIFICATE_BASE64 (file .p12 mã hóa base64), P12_PASSWORD, PROVISION_PROFILE_BASE64 (file .mobileprovision mã hóa base64). Thêm trên web GitHub: Settings > Secrets and variables > Actions.")
        }
        if sel.contains(.web) {
            parts.append("Web: build xong tự đăng lên GitHub Pages (app sẽ thử bật Pages giúp bạn; repo riêng tư cần tài khoản GitHub trả phí).")
        }
        if sel.contains(.test) {
            parts.append("Chạy test: tự chạy mỗi lần push hoặc pull request, không cần file zip.")
        }
        return parts.joined(separator: " ")
    }

    private var valid: Bool {
        !cleanName.isEmpty
            && cleanName != "."
            && cleanName != ".."
            && cleanName.range(of: "^[A-Za-z0-9._-]+$", options: .regularExpression) != nil
            && topicOK
    }

    private var cleanTopic: String {
        ntfyTopic.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var topicOK: Bool {
        cleanTopic.isEmpty
            || cleanTopic.range(of: "^[A-Za-z0-9_-]{6,64}$", options: .regularExpression) != nil
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("ten-repo", text: $name)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .submitLabel(.done)
                } header: {
                    Text("Tên repo")
                } footer: {
                    if !name.isEmpty && !valid {
                        Text("Chỉ dùng chữ không dấu, số, dấu - _ . (khoảng trắng sẽ đổi thành -).")
                            .foregroundStyle(.red)
                    }
                }

                Section("Mô tả (không bắt buộc)") {
                    TextField("Ví dụ: app iOS làng quê 3D", text: $desc)
                        .submitLabel(.done)
                }

                Section {
                    Toggle("Riêng tư (private)", isOn: $isPrivate)
                    Toggle("Tạo sẵn README", isOn: $autoInit)
                } footer: {
                    Text("Nên bật README để repo có sẵn nhánh chính, dùng được ngay.")
                }

                Section {
                    Toggle("iOS – build IPA chưa ký", isOn: $addIOS)
                    Toggle("iOS – build và ký IPA (cần Secrets)", isOn: $addIOSSigned)
                    Toggle("Android – build APK", isOn: $addAndroid)
                    Toggle("Windows – build EXE", isOn: $addWindows)
                    Toggle("Web – build và đăng lên GitHub Pages", isOn: $addWeb)
                    Toggle("Chạy test Node / Python mỗi lần push", isOn: $addTest)
                } header: {
                    Text("Workflow tự build")
                } footer: {
                    Text(workflowFooter)
                }

                Section {
                    TextField("tên kênh, ví dụ build-ab12cd34", text: $ntfyTopic)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Button("Tạo tên kênh ngẫu nhiên") {
                        let chars = Array("abcdefghijklmnopqrstuvwxyz0123456789")
                        ntfyTopic = "build-" + String((0..<10).map { _ in chars.randomElement()! })
                    }
                } header: {
                    Text("Thông báo khi build xong (không bắt buộc)")
                } footer: {
                    if !topicOK {
                        Text("Tên kênh chỉ gồm chữ không dấu, số, - _ và dài 6 đến 64 ký tự.")
                            .foregroundStyle(.red)
                    } else {
                        Text("Cài app ntfy (miễn phí) trên iPhone, đăng ký (subscribe) đúng tên kênh này là điện thoại nhận thông báo khi build xong hoặc lỗi. Ai biết tên kênh đều đọc được thông báo, nên hãy dùng tên khó đoán.")
                    }
                }

                if let error = error {
                    Section { Text(error).foregroundStyle(.red) }
                }

                Section {
                    Button {
                        hideKeyboard()
                        Task { await create() }
                    } label: {
                        Group {
                            if busy {
                                HStack(spacing: 8) {
                                    ProgressView()
                                    Text(status).font(.footnote)
                                }
                            } else {
                                Text("Tạo repo").fontWeight(.semibold)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .disabled(!valid || busy)
                }
            }
            .themedList()
            .navigationTitle("Repo mới")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Hủy") { dismiss() }.disabled(busy)
                }
            }
        }
        .interactiveDismissDisabled(busy)
    }

    private func create() async {
        busy = true
        error = nil
        status = "Đang tạo repo..."
        defer { busy = false }
        do {
            let d = desc.trimmingCharacters(in: .whitespacesAndNewlines)
            let repo = try await session.api.createRepo(
                name: cleanName,
                description: d,
                isPrivate: isPrivate,
                autoInit: autoInit || !selected.isEmpty
            )
            var notes: [String] = []
            let sel = selected
            let zipCount = sel.filter { $0.usesZip }.count
            for p in sel {
                status = "Thêm workflow \(p.title)..."
                let yml = WorkflowTemplates.template(p, single: zipCount == 1, ntfy: cleanTopic)
                if let err = await putFile(repo,
                                           path: ".github/workflows/\(p.fileName)",
                                           data: Data(yml.utf8),
                                           message: "Thêm workflow build \(p.title) từ zip") {
                    notes.append("\(p.title): \(err)")
                } else if p.usesZip {
                    // Tạo sẵn thư mục thả zip
                    _ = await putFile(repo,
                                      path: "\(p.folder)/.gitkeep",
                                      data: Data("Thả file .zip project vào thư mục này\n".utf8),
                                      message: "Tạo thư mục \(p.folder)")
                }
            }
            if sel.contains(.web) {
                status = "Bật GitHub Pages..."
                do {
                    try await session.api.enablePages(repo)
                } catch let e as APIError where e.statusCode == 409 {
                    // Pages đã bật sẵn
                } catch let e {
                    notes.append("Chưa bật được GitHub Pages (\(e.localizedDescription)). Vào Settings > Pages > Source, chọn GitHub Actions")
                }
            }
            let note: String? = notes.isEmpty ? nil
                : "Đã tạo repo nhưng có việc chưa làm được: " + notes.joined(separator: "; ")
            onCreated(repo, note)
            dismiss()
        } catch let e {
            error = e.localizedDescription
        }
    }

    /// Repo vừa tạo đôi khi chưa sẵn sàng ngay, nên thử lại vài lần
    private func putFile(_ repo: Repo, path: String, data: Data, message: String) async -> String? {
        var last: String? = nil
        for i in 0..<4 {
            if i > 0 { try? await Task.sleep(nanoseconds: 1_500_000_000) }
            do {
                _ = try await session.api.save(
                    repo,
                    path: path,
                    data: data,
                    sha: nil,
                    message: message,
                    branch: repo.defaultBranch
                )
                return nil
            } catch let e {
                last = e.localizedDescription
            }
        }
        return last
    }
}
