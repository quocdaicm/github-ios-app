import SwiftUI

// MARK: - Dịch README / Markdown (chọn ngôn ngữ, bật/tắt bản gốc)

struct TLang: Identifiable, Hashable {
    let code: String
    let name: String
    var id: String { code }

    static let all: [TLang] = [
        TLang(code: "vi", name: "Tiếng Việt"),
        TLang(code: "en", name: "English"),
        TLang(code: "zh-CN", name: "中文 (简体)"),
        TLang(code: "zh-TW", name: "中文 (繁體)"),
        TLang(code: "ja", name: "日本語"),
        TLang(code: "ko", name: "한국어"),
        TLang(code: "fr", name: "Français"),
        TLang(code: "de", name: "Deutsch"),
        TLang(code: "es", name: "Español"),
        TLang(code: "pt", name: "Português"),
        TLang(code: "ru", name: "Русский"),
        TLang(code: "th", name: "ไทย"),
        TLang(code: "id", name: "Bahasa Indonesia"),
        TLang(code: "hi", name: "हिन्दी"),
        TLang(code: "ar", name: "العربية")
    ]

    static func name(_ code: String) -> String {
        all.first { $0.code == code }?.name ?? code
    }
}

enum TranslateError: LocalizedError {
    case http(Int)
    case badResponse

    var errorDescription: String? {
        switch self {
        case .http(let c): return "Dịch vụ dịch trả về lỗi \(c). Thử lại sau ít phút."
        case .badResponse: return "Không đọc được kết quả dịch."
        }
    }
}

/// Gọi dịch vụ dịch (không cần khóa API), có bộ nhớ đệm theo (ngôn ngữ + nội dung)
actor Translator {
    static let shared = Translator()
    private var cache: [String: String] = [:]
    private var active = 0

    /// Giới hạn số yêu cầu dịch chạy cùng lúc trong toàn app
    private func acquire() async {
        while active >= 6 { try? await Task.sleep(nanoseconds: 60_000_000) }
        active += 1
    }

    private func release() { active -= 1 }

    func cached(_ text: String, _ lang: String) -> String? {
        cache[lang + "\u{1}" + text.trimmingCharacters(in: .whitespacesAndNewlines)]
    }

    func result(_ text: String, _ lang: String) async -> Result<String, Error> {
        do {
            return .success(try await translate(text, to: lang))
        } catch let e {
            return .failure(e)
        }
    }

    func translate(_ text: String, to lang: String) async throws -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.contains(where: { $0.isLetter }), trimmed.count <= 4500 else { return text }
        let key = lang + "\u{1}" + trimmed
        if let c = cache[key] { return c }

        await acquire()
        defer { release() }
        let (protected, saved) = Translator.protect(trimmed)
        let raw = try await Translator.request(protected, lang)
        // Nếu dịch làm mất ký hiệu bảo vệ (link, `code`) thì giữ nguyên bản gốc cho đoạn đó
        guard let restored = Translator.restore(raw, saved) else { return text }
        cache[key] = restored
        return restored
    }

    // Giữ nguyên `code`, địa chỉ link và URL: thay bằng mã tạm trước khi dịch
    private static let protectRegex = try! NSRegularExpression(
        pattern: "`[^`\\n]+`|(?<=\\]\\()[^)\\s]+|https?://[^\\s)>\\]]+"
    )

    static func protect(_ s: String) -> (String, [String]) {
        let ns = s as NSString
        var saved: [String] = []
        var out = ""
        var last = 0
        for m in protectRegex.matches(in: s, range: NSRange(location: 0, length: ns.length)) {
            out += ns.substring(with: NSRange(location: last, length: m.range.location - last))
            out += "QQ\(saved.count)QQ"
            saved.append(ns.substring(with: m.range))
            last = m.range.location + m.range.length
        }
        out += ns.substring(from: last)
        return (out, saved)
    }

    static func restore(_ s: String, _ saved: [String]) -> String? {
        var r = s
        for (i, v) in saved.enumerated() {
            let token = "QQ\(i)QQ"
            guard r.contains(token) else { return nil }
            r = r.replacingOccurrences(of: token, with: v)
        }
        // Sửa khoảng trắng thừa do bộ dịch chèn vào: "] (" và "** chữ **"
        r = r.replacingOccurrences(of: "\\]\\s+\\(", with: "](", options: .regularExpression)
        r = r.replacingOccurrences(of: "\\*\\*\\s*([^*\\n]+?)\\s*\\*\\*", with: "**$1**", options: .regularExpression)
        return r
    }

    private static func request(_ text: String, _ lang: String) async throws -> String {
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        let enc = text.addingPercentEncoding(withAllowedCharacters: allowed) ?? ""
        let params = "client=gtx&sl=auto&tl=\(lang)&dt=t"
        let base = "https://translate.googleapis.com/translate_a/single"

        var req: URLRequest
        if enc.count < 1500, let url = URL(string: "\(base)?\(params)&q=\(enc)") {
            req = URLRequest(url: url)
        } else {
            guard let url = URL(string: "\(base)?\(params)") else { throw TranslateError.badResponse }
            req = URLRequest(url: url)
            req.httpMethod = "POST"
            req.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")
            req.httpBody = "q=\(enc)".data(using: .utf8)
        }
        req.timeoutInterval = 20

        let (data, resp) = try await URLSession.shared.data(for: req)
        if let h = resp as? HTTPURLResponse, h.statusCode != 200 {
            throw TranslateError.http(h.statusCode)
        }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [Any],
              let segs = root.first as? [Any] else {
            throw TranslateError.badResponse
        }
        var out = ""
        for s in segs {
            if let a = s as? [Any], let t = a.first as? String { out += t }
        }
        if out.isEmpty { throw TranslateError.badResponse }
        return out
    }
}

/// Dịch nhiều chuỗi song song (tối đa 5 yêu cầu cùng lúc)
enum BatchTranslate {
    /// Trả về bản đồ "chuỗi gốc -> chuỗi dịch"; chuỗi nào lỗi thì không có trong kết quả.
    /// Ném lỗi nếu tất cả đều lỗi.
    static func run(_ texts: [String], to lang: String) async throws -> [String: String] {
        if texts.isEmpty { return [:] }
        var results: [String: String] = [:]
        var firstError: Error?
        await withTaskGroup(of: (String, Result<String, Error>).self) { group in
            var index = 0
            let limit = 5
            while index < min(limit, texts.count) {
                let t = texts[index]
                index += 1
                group.addTask { (t, await Translator.shared.result(t, lang)) }
            }
            for await (t, r) in group {
                switch r {
                case .success(let v): results[t] = v
                case .failure(let e): firstError = e
                }
                if index < texts.count {
                    let n = texts[index]
                    index += 1
                    group.addTask { (n, await Translator.shared.result(n, lang)) }
                }
            }
        }
        try Task.checkCancellation()
        if results.isEmpty, let e = firstError { throw e }
        return results
    }
}

/// Dịch từng khối Markdown, bỏ qua khối code
enum MDTranslate {
    private static func mapText(_ blocks: [MDBlock], _ f: (String) -> String) -> [MDBlock] {
        blocks.map { b in
            switch b {
            case .heading(let l, let s): return .heading(l, f(s))
            case .paragraph(let s): return .paragraph(f(s))
            case .item(let l, let m, let s): return .item(l, m, f(s))
            case .quote(let s): return .quote(f(s))
            case .table(let rows): return .table(rows.map { $0.map(f) })
            case .code, .rule: return b
            }
        }
    }

    static func translate(_ blocks: [MDBlock], to lang: String) async throws -> [MDBlock] {
        // 1) Gom các chuỗi cần dịch (không trùng)
        var texts: [String] = []
        var seen = Set<String>()
        _ = mapText(blocks) { s in
            if !seen.contains(s), s.contains(where: { $0.isLetter }) {
                seen.insert(s)
                texts.append(s)
            }
            return s
        }
        if texts.isEmpty { return blocks }

        // 2) Dịch song song
        let results = try await BatchTranslate.run(texts, to: lang)

        // 3) Ghép lại; đoạn nào lỗi thì giữ bản gốc
        return mapText(blocks) { results[$0] ?? $0 }
    }
}

// MARK: - Khung Markdown có nút dịch

struct TranslatableMarkdown: View {
    let text: String

    @AppStorage("translateLang") private var langCode = "vi"
    @AppStorage("translateAuto") private var auto = false
    @AppStorage("translateConsent") private var consent = false
    @State private var askConsent = false
    @State private var translated: [MDBlock]?
    @State private var translatedLang = ""
    @State private var showTranslated = false
    @State private var busy = false
    @State private var error: String?

    private var buttonTitle: String {
        if busy { return "Đang dịch..." }
        return showTranslated ? "Xem bản gốc" : "Dịch sang \(TLang.name(langCode))"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                Button {
                    Task { await toggle() }
                } label: {
                    HStack(spacing: 6) {
                        if busy {
                            ProgressView().controlSize(.small)
                        } else {
                            Image(systemName: "character.bubble")
                        }
                        Text(buttonTitle)
                    }
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Capsule().fill(Theme.accent.opacity(0.12)))
                }
                .buttonStyle(.borderless)
                .disabled(busy)

                Menu {
                    Picker("Ngôn ngữ dịch", selection: $langCode) {
                        ForEach(TLang.all) { l in
                            Text(l.name).tag(l.code)
                        }
                    }
                    Toggle("Tự động dịch README", isOn: $auto)
                } label: {
                    Label(TLang.name(langCode), systemImage: "globe")
                        .font(.caption)
                }
                .disabled(busy)

                Spacer()
            }

            if let error = error {
                Text(error).font(.caption).foregroundStyle(.red)
            }

            if showTranslated, let t = translated {
                MarkdownView(blocks: t)
            } else {
                MarkdownView(text: text)
            }
        }
        .task(id: text) {
            translated = nil
            showTranslated = false
            error = nil
            if auto && consent { await runTranslate() }
        }
        .alert(TranslateNotice.title, isPresented: $askConsent) {
            Button("Hủy", role: .cancel) {}
            Button("Đồng ý và dịch") {
                consent = true
                Task { await runTranslate() }
            }
        } message: {
            Text(TranslateNotice.message)
        }
        .onChange(of: langCode) { _ in
            if showTranslated { Task { await runTranslate() } }
        }
    }

    private func toggle() async {
        if !consent && !showTranslated {
            askConsent = true
            return
        }
        if showTranslated {
            showTranslated = false
        } else if translated != nil && translatedLang == langCode {
            showTranslated = true
        } else {
            await runTranslate()
        }
    }

    private func runTranslate() async {
        if busy { return }
        busy = true
        error = nil
        defer { busy = false }
        let lang = langCode
        do {
            let out = try await MDTranslate.translate(MDParser.parse(text), to: lang)
            translated = out
            translatedLang = lang
            showTranslated = true
        } catch let e {
            if !(e is CancellationError) {
                error = "Không dịch được: \(e.localizedDescription)"
            }
        }
    }
}


// MARK: - Dịch dòng chữ ngắn (mô tả repo, tin nhắn commit)

/// Hiện bản dịch khi bật "Dịch mô tả repo & commit", ngược lại hiện nguyên bản
struct TranslatedText: View {
    let text: String

    @AppStorage("translateInline") private var on = false
    @AppStorage("translateLang") private var lang = "vi"
    @State private var out = ""
    @State private var outKey = ""

    private var key: String { lang + "\u{1}" + text }

    var body: some View {
        Text(on && outKey == key && !out.isEmpty ? out : text)
            .task(id: "\(on)|\(key)") {
                guard on, UserDefaults.standard.bool(forKey: "translateConsent") else { return }
                if let c = await Translator.shared.cached(text, lang) {
                    out = c
                    outKey = key
                    return
                }
                if let r = try? await Translator.shared.translate(text, to: lang) {
                    out = r
                    outKey = key
                }
            }
    }
}

/// Nút bật/tắt nhanh việc dịch mô tả repo và commit
struct TranslateToggleButton: View {
    @AppStorage("translateInline") private var on = false
    @AppStorage("translateConsent") private var consent = false
    @State private var askConsent = false

    var body: some View {
        Button {
            if !on && !consent {
                askConsent = true
            } else {
                on.toggle()
            }
        } label: {
            Image(systemName: on ? "character.bubble.fill" : "character.bubble")
        }
        .alert(TranslateNotice.title, isPresented: $askConsent) {
            Button("Hủy", role: .cancel) {}
            Button("Đồng ý và bật") {
                consent = true
                on = true
            }
        } message: {
            Text(TranslateNotice.message)
        }
    }
}

/// Lời nhắc quyền riêng tư hiện một lần trước khi dùng tính năng dịch
enum TranslateNotice {
    static let title = "Dịch bằng Google Translate"
    static let message = "Nội dung cần dịch (README, mô tả, commit, comment, kể cả của repo riêng tư) sẽ được gửi tới dịch vụ Google Translate. Không nên dùng với nội dung bí mật."
}
