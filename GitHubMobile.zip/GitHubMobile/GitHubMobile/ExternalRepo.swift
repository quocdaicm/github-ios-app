import SwiftUI

// MARK: - Xem repo của người khác và fork về tài khoản của mình

struct ExternalRepoView: View {
    let repo: Repo
    var onForked: (Repo) -> Void = { _ in }

    @EnvironmentObject var session: Session
    @State private var branch: String
    @State private var branches: [String] = []
    @State private var tab = 0
    @State private var confirmFork = false
    @State private var forking = false
    @State private var forkStatus = ""
    @State private var forked: Repo?
    @State private var goForked = false
    @State private var toast: String?

    init(repo: Repo, onForked: @escaping (Repo) -> Void = { _ in }) {
        self.repo = repo
        self.onForked = onForked
        _branch = State(initialValue: repo.defaultBranch)
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 6) {
                Image(systemName: "eye")
                Text("Repo của \(repo.owner.login) · chỉ xem")
                Spacer()
                if let st = repo.stargazersCount {
                    Label(starText(st), systemImage: "star.fill")
                        .foregroundStyle(.orange)
                }
                StarButton(repo: repo)
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            .padding(.horizontal)
            .padding(.vertical, 6)
            .background(.bar)

            Picker("", selection: $tab) {
                Text("Mã nguồn").tag(0)
                Text("Lịch sử").tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal)
            .padding(.bottom, 8)
            .background(.bar)

            if tab == 0 {
                FileBrowserView(repo: repo, branch: branch, path: "", isRoot: true, viewOnly: true)
            } else {
                CommitsView(repo: repo, branch: branch)
            }
        }
        .navigationTitle(repo.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                RepoZipButton(repo: repo, branch: branch)
                Menu {
                    Picker("Nhánh", selection: $branch) {
                        ForEach(branches.isEmpty ? [branch] : branches, id: \.self) { b in
                            Text(b).tag(b)
                        }
                    }
                } label: {
                    Label(branch, systemImage: "arrow.triangle.branch")
                }
            }
        }
        .safeAreaInset(edge: .bottom) {
            Button {
                confirmFork = true
            } label: {
                Group {
                    if forking {
                        HStack(spacing: 8) {
                            ProgressView().tint(.white)
                            Text(forkStatus)
                        }
                    } else {
                        Label("Thêm vào repo của tôi (Fork)", systemImage: "square.and.arrow.down.on.square")
                    }
                }
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 6)
            }
            .buttonStyle(.borderedProminent)
            .disabled(forking)
            .padding(.horizontal)
            .padding(.vertical, 8)
            .background(.bar)
        }
        .task {
            if let list = try? await session.api.branches(repo) {
                branches = list.map { $0.name }
            }
        }
        .sheet(isPresented: $confirmFork) {
            ForkOptionsView(repo: repo) { name, only in
                Task { await fork(name: name, only: only) }
            }
            .presentationDetents([.medium, .large])
        }
        .navigationDestination(isPresented: $goForked) {
            if let f = forked { RepoView(repo: f) }
        }
        .alert("Thông báo", isPresented: Binding(
            get: { toast != nil },
            set: { if !$0 { toast = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(toast ?? "")
        }
    }

    private func fork(name: String, only: Bool) async {
        forking = true
        forkStatus = "Đang fork..."
        defer { forking = false }
        do {
            let f = try await session.api.fork(repo, name: name, defaultBranchOnly: only)
            // GitHub tạo bản fork bất đồng bộ: chờ đến khi nhánh sẵn sàng
            forkStatus = "Đang chuẩn bị bản sao..."
            for _ in 0..<10 {
                if let b = try? await session.api.branches(f), !b.isEmpty { break }
                try? await Task.sleep(nanoseconds: 1_500_000_000)
            }
            forkStatus = "Đang bật Actions..."
            await session.api.enableActions(f)
            onForked(f)
            forked = f
            goForked = true
        } catch let e {
            toast = e.localizedDescription
        }
    }
}
