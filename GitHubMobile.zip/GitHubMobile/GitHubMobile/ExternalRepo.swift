import SwiftUI

// MARK: - Xem repo của người khác và fork về tài khoản của mình

struct ExternalRepoView: View {
    let repo: Repo
    var onForked: (Repo) -> Void = { _ in }

    @EnvironmentObject var session: Session
    @State private var branch: String
    @State private var branches: [String] = []
    @State private var tab = 0
    @State private var confirmFork = false
    @State private var forking = false
    @State private var forkStatus = ""
    @State private var forked: Repo?
    @State private var goForked = false
    @State private var toast: String?

    init(repo: Repo, onForked: @escaping (Repo) -> Void = { _ in }) {
        self.repo = repo
        self.onForked = onForked
        _branch = State(initialValue: repo.defaultBranch)
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 6) {
                Image(systemName: "eye")
                Text("Repo của \(repo.owner.login) · chỉ xem")
                Spacer()
                if let st = repo.stargazersCount {
                    Label(starText(st), systemImage: "star.fill")
                        .foregroundStyle(.orange)
                }
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            .padding(.horizontal)
            .padding(.vertical, 6)
            .background(.bar)

            Picker("", selection: $tab) {
                Text("Mã nguồn").tag(0)
                Text("Lịch sử").tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal)
            .padding(.bottom, 8)
            .background(.bar)

            if tab == 0 {
                FileBrowserView(repo: repo, branch: branch, path: "", isRoot: true, viewOnly: true)
            } else {
                CommitsView(repo: repo, branch: branch)
            }
        }
        .navigationTitle(repo.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    Picker("Nhánh", selection: $branch) {
                        ForEach(branches.isEmpty ? [branch] : branches, id: \.self) { b in
                            Text(b).tag(b)
                        }
                    }
                } label: {
                    Label(branch, systemImage: "arrow.triangle.branch")
                }
            }
        }
        .safeAreaInset(edge: .bottom) {
            Button {
                confirmFork = true
            } label: {
                Group {
                    if forking {
                        HStack(spacing: 8) {
                            ProgressView().tint(.white)
                            Text(forkStatus)
                        }
                    } else {
                        Label("Thêm vào repo của tôi (Fork)", systemImage: "square.and.arrow.down.on.square")
                    }
                }
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 6)
            }
            .buttonStyle(.borderedProminent)
            .disabled(forking)
            .padding(.horizontal)
            .padding(.vertical, 8)
            .background(.bar)
        }
        .task {
            if let list = try? await session.api.branches(repo) {
                branches = list.map { $0.name }
            }
        }
        .confirmationDialog("Fork \(repo.fullName)?", isPresented: $confirmFork, titleVisibility: .visible) {
            Button("Fork về \(session.login.isEmpty ? "tài khoản của tôi" : session.login)") {
                Task { await fork() }
            }
            Button("Hủy", role: .cancel) {}
        } message: {
            Text("Tạo một bản sao của repo này trong tài khoản của bạn (bản fork của repo public luôn là public). Sau đó bạn có thể sửa code và build trên bản sao.")
        }
        .navigationDestination(isPresented: $goForked) {
            if let f = forked { RepoView(repo: f) }
        }
        .alert("Thông báo", isPresented: Binding(
            get: { toast != nil },
            set: { if !$0 { toast = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(toast ?? "")
        }
    }

    private func fork() async {
        forking = true
        forkStatus = "Đang fork..."
        defer { forking = false }
        do {
            let f = try await session.api.fork(repo)
            // GitHub tạo bản fork bất đồng bộ: chờ đến khi nhánh sẵn sàng
            forkStatus = "Đang chuẩn bị bản sao..."
            for _ in 0..<10 {
                if let b = try? await session.api.branches(f), !b.isEmpty { break }
                try? await Task.sleep(nanoseconds: 1_500_000_000)
            }
            forkStatus = "Đang bật Actions..."
            await session.api.enableActions(f)
            onForked(f)
            forked = f
            goForked = true
        } catch let e {
            toast = e.localizedDescription
        }
    }
}
