import SwiftUI
import UIKit

// MARK: - Ngôn ngữ (đoán theo đuôi file)

struct CodeLang {
    enum Kind { case plain, clike, hash, python, yaml, json, markdown, markup }

    let kind: Kind
    let keywords: [String]

    /// Sau dấu ":" ở cuối dòng thì Enter sẽ thụt thêm một cấp
    var indentAfterColon: Bool { kind == .python || kind == .yaml }

    private static let swiftWords = [
        "import", "class", "struct", "enum", "protocol", "extension", "func", "var", "let",
        "if", "else", "guard", "switch", "case", "default", "for", "while", "repeat", "return",
        "break", "continue", "in", "is", "as", "try", "catch", "throw", "throws", "async", "await",
        "init", "self", "Self", "super", "nil", "true", "false", "public", "private", "fileprivate",
        "internal", "open", "static", "final", "override", "mutating", "lazy", "weak", "unowned",
        "where", "some", "any", "typealias", "defer", "do"
    ]
    private static let jsWords = [
        "const", "let", "var", "function", "return", "if", "else", "for", "while", "do", "switch",
        "case", "break", "continue", "new", "class", "extends", "import", "export", "from",
        "default", "async", "await", "try", "catch", "finally", "throw", "typeof", "instanceof",
        "this", "super", "null", "undefined", "true", "false", "interface", "type", "enum",
        "public", "private", "protected", "readonly", "static", "of", "in"
    ]
    private static let genericWords = [
        "class", "struct", "enum", "interface", "public", "private", "protected", "static", "final",
        "void", "int", "float", "double", "bool", "boolean", "char", "string", "String", "long",
        "short", "unsigned", "const", "var", "val", "let", "fun", "func", "fn", "def", "return",
        "if", "else", "for", "while", "do", "switch", "case", "default", "break", "continue", "new",
        "null", "nil", "true", "false", "this", "self", "import", "package", "using", "namespace",
        "include", "extends", "implements", "try", "catch", "finally", "throw", "throws", "async",
        "await", "override", "abstract", "in", "is", "as", "object", "when", "where", "mut", "impl",
        "trait", "use", "pub", "mod", "match", "go", "defer", "chan", "select", "type"
    ]
    private static let pythonWords = [
        "def", "class", "import", "from", "as", "if", "elif", "else", "for", "while", "return",
        "break", "continue", "pass", "try", "except", "finally", "raise", "with", "lambda", "yield",
        "global", "nonlocal", "in", "is", "not", "and", "or", "None", "True", "False", "async",
        "await", "self"
    ]
    private static let shellWords = [
        "if", "then", "else", "elif", "fi", "for", "while", "do", "done", "case", "esac",
        "function", "in", "echo", "export", "local", "return", "exit", "cd", "set", "source"
    ]

    init(fileName: String) {
        let ext = (fileName as NSString).pathExtension.lowercased()
        let base = (fileName as NSString).lastPathComponent.lowercased()
        switch ext {
        case "swift":
            kind = .clike
            keywords = CodeLang.swiftWords
        case "js", "jsx", "ts", "tsx", "mjs", "cjs":
            kind = .clike
            keywords = CodeLang.jsWords
        case "java", "kt", "kts", "c", "h", "m", "mm", "cpp", "cc", "hpp", "cs", "go", "rs",
             "dart", "php", "scala", "gradle":
            kind = .clike
            keywords = CodeLang.genericWords
        case "css", "scss", "less":
            kind = .clike
            keywords = []
        case "py":
            kind = .python
            keywords = CodeLang.pythonWords
        case "sh", "bash", "zsh":
            kind = .hash
            keywords = CodeLang.shellWords
        case "rb", "pl", "toml", "ini", "conf", "cfg", "properties", "env":
            kind = .hash
            keywords = []
        case "yml", "yaml":
            kind = .yaml
            keywords = ["true", "false", "null", "yes", "no", "on", "off"]
        case "json", "jsonl":
            kind = .json
            keywords = ["true", "false", "null"]
        case "md", "markdown":
            kind = .markdown
            keywords = []
        case "html", "htm", "xml", "svg", "plist", "xib", "storyboard":
            kind = .markup
            keywords = []
        default:
            if base == "dockerfile" || base == "makefile" {
                kind = .hash
            } else {
                kind = .plain
            }
            keywords = []
        }
    }
}

// MARK: - Tô màu cú pháp

enum Highlighter {
    private static var cache: [String: NSRegularExpression] = [:]

    private static func regex(_ pattern: String, _ options: NSRegularExpression.Options) -> NSRegularExpression? {
        let key = "\(options.rawValue)|\(pattern)"
        if let r = cache[key] { return r }
        guard let r = try? NSRegularExpression(pattern: pattern, options: options) else { return nil }
        cache[key] = r
        return r
    }

    private static let kwColor = UIColor.systemPink
    private static let strColor = UIColor.systemOrange
    private static let numColor = UIColor.systemBlue
    private static let cmtColor = UIColor.systemGreen
    private static let tagColor = UIColor.systemPurple

    static func apply(to storage: NSTextStorage, lang: CodeLang, font: UIFont) {
        let full = NSRange(location: 0, length: storage.length)
        storage.setAttributes([.font: font, .foregroundColor: UIColor.label], range: full)
        if storage.length == 0 || storage.length > 200_000 || lang.kind == .plain { return }

        let text = storage.string

        func paint(_ pattern: String, _ color: UIColor, _ options: NSRegularExpression.Options = []) {
            guard let re = regex(pattern, options) else { return }
            re.enumerateMatches(in: text, options: [], range: full) { m, _, _ in
                if let r = m?.range, r.location != NSNotFound {
                    storage.addAttribute(.foregroundColor, value: color, range: r)
                }
            }
        }

        let str1 = #""(?:\\.|[^"\\\n])*""#
        let str2 = #"'(?:\\.|[^'\\\n])*'"#
        let num = #"\b\d+(?:\.\d+)?\b"#
        let tripleQuote = "\"\"\"[\\s\\S]*?\"\"\""
        var words: String? = nil
        if !lang.keywords.isEmpty {
            words = #"\b(?:"# + lang.keywords.joined(separator: "|") + #")\b"#
        }

        switch lang.kind {
        case .plain:
            break
        case .clike:
            paint(num, numColor)
            if let w = words { paint(w, kwColor) }
            paint(#"@\w+"#, kwColor)
            paint(str1, strColor)
            paint(str2, strColor)
            paint(#"(?<!:)//[^\n]*"#, cmtColor)
            paint(#"/\*[\s\S]*?\*/"#, cmtColor)
        case .hash:
            paint(num, numColor)
            if let w = words { paint(w, kwColor) }
            paint(str1, strColor)
            paint(str2, strColor)
            paint(#"(?<![\w"'$])#[^\n]*"#, cmtColor)
        case .python:
            paint(num, numColor)
            if let w = words { paint(w, kwColor) }
            paint(#"@\w+"#, kwColor)
            paint(str1, strColor)
            paint(str2, strColor)
            paint(tripleQuote, strColor)
            paint(#"(?<![\w"'$])#[^\n]*"#, cmtColor)
        case .yaml:
            paint(num, numColor)
            if let w = words { paint(w, kwColor) }
            paint(#"^[ \t]*-?[ \t]*[\w.\-/"']+(?=[ \t]*:)"#, tagColor, [.anchorsMatchLines])
            paint(str1, strColor)
            paint(str2, strColor)
            paint(#"(?<![\w"'$])#[^\n]*"#, cmtColor)
        case .json:
            paint(num, numColor)
            if let w = words { paint(w, kwColor) }
            paint(str1, strColor)
            paint(#""(?:\\.|[^"\\\n])*"(?=\s*:)"#, tagColor)
        case .markdown:
            paint(#"^#{1,6}[ \t].*$"#, kwColor, [.anchorsMatchLines])
            paint(#"^[ \t]*(?:[-*+]|\d+\.)[ \t]"#, numColor, [.anchorsMatchLines])
            paint(#"\[[^\]\n]*\]\([^)\n]*\)"#, numColor)
            paint(#"\*\*[^*\n]+\*\*"#, tagColor)
            paint(#"`[^`\n]+`"#, strColor)
            paint(#"^(?:```|~~~).*$"#, strColor, [.anchorsMatchLines])
        case .markup:
            paint(#"</?[A-Za-z][\w:.\-]*"#, kwColor)
            paint(str1, strColor)
            paint(#"<!--[\s\S]*?-->"#, cmtColor)
        }
    }
}

// MARK: - Điều khiển editor từ SwiftUI (tìm/thay thế, ẩn phím)

final class EditorController: ObservableObject {
    weak var textView: UITextView?

    func showFind() {
        guard let tv = textView else { return }
        tv.becomeFirstResponder()
        tv.findInteraction?.presentFindNavigator(showingReplace: true)
    }

    func dismissKeyboard() {
        textView?.resignFirstResponder()
    }
}

// MARK: - Khung soạn code (UITextView)

struct CodeTextView: UIViewRepresentable {
    @Binding var text: String
    let lang: CodeLang
    let controller: EditorController

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIView(context: Context) -> UITextView {
        let tv = UITextView()
        tv.delegate = context.coordinator
        tv.font = UIFont.monospacedSystemFont(ofSize: 13, weight: .regular)
        tv.autocapitalizationType = .none
        tv.autocorrectionType = .no
        tv.spellCheckingType = .no
        tv.smartQuotesType = .no
        tv.smartDashesType = .no
        tv.smartInsertDeleteType = .no
        tv.alwaysBounceVertical = true
        tv.keyboardDismissMode = .interactive
        tv.isFindInteractionEnabled = true
        tv.backgroundColor = .clear
        tv.textContainerInset = UIEdgeInsets(top: 8, left: 6, bottom: 8, right: 6)
        tv.text = text

        context.coordinator.view = tv
        tv.inputAccessoryView = context.coordinator.makeAccessory()
        context.coordinator.rehighlight(tv)
        controller.textView = tv
        return tv
    }

    func updateUIView(_ tv: UITextView, context: Context) {
        context.coordinator.parent = self
        if tv.text != text {
            tv.text = text
            context.coordinator.rehighlight(tv)
        }
    }

    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: CodeTextView
        weak var view: UITextView?
        private var pending: DispatchWorkItem?

        init(_ parent: CodeTextView) {
            self.parent = parent
        }

        // MARK: Văn bản thay đổi

        func textViewDidChange(_ tv: UITextView) {
            if parent.text != tv.text { parent.text = tv.text }
            pending?.cancel()
            let item = DispatchWorkItem { [weak self, weak tv] in
                guard let self = self, let tv = tv else { return }
                self.rehighlight(tv)
            }
            pending = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35, execute: item)
        }

        /// Enter: giữ nguyên thụt lề của dòng trước
        func textView(_ tv: UITextView,
                      shouldChangeTextIn range: NSRange,
                      replacementText replacement: String) -> Bool {
            guard replacement == "\n", tv.markedTextRange == nil else { return true }
            let ns = tv.text as NSString
            guard range.location <= ns.length else { return true }
            let lineRange = ns.lineRange(for: NSRange(location: range.location, length: 0))
            let upTo = ns.substring(with: NSRange(location: lineRange.location,
                                                  length: range.location - lineRange.location))
            let indent = String(upTo.prefix(while: { $0 == " " || $0 == "\t" }))
            var extra = ""
            if let last = upTo.trimmingCharacters(in: .whitespaces).last {
                let openers: [Character] = ["{", "(", "["]
                if openers.contains(last) || (last == ":" && parent.lang.indentAfterColon) {
                    extra = "    "
                }
            }
            if indent.isEmpty && extra.isEmpty { return true }
            tv.insertText("\n" + indent + extra)
            return false
        }

        // MARK: Tô màu

        func rehighlight(_ tv: UITextView) {
            // Đang gõ dấu tiếng Việt (Telex/VNI): đừng đụng vào văn bản
            if tv.markedTextRange != nil { return }
            let font = UIFont.monospacedSystemFont(ofSize: 13, weight: .regular)
            tv.textStorage.beginEditing()
            Highlighter.apply(to: tv.textStorage, lang: parent.lang, font: font)
            tv.textStorage.endEditing()
            tv.typingAttributes = [.font: font, .foregroundColor: UIColor.label]
        }

        // MARK: Thanh phím tắt phía trên bàn phím

        func makeAccessory() -> UIView {
            let bar = UIView(frame: CGRect(x: 0, y: 0, width: 320, height: 44))
            bar.autoresizingMask = .flexibleWidth
            bar.backgroundColor = .secondarySystemBackground

            let scroll = UIScrollView()
            scroll.showsHorizontalScrollIndicator = false
            scroll.translatesAutoresizingMaskIntoConstraints = false

            let stack = UIStackView()
            stack.axis = .horizontal
            stack.spacing = 6
            stack.translatesAutoresizingMaskIntoConstraints = false

            let keys = ["↶", "↷", "⇥", "{", "}", "(", ")", "[", "]", "<", ">",
                        "\"", "'", ";", ":", "=", "/", "\\", "#", "_", "$", "&", "|"]
            for k in keys {
                stack.addArrangedSubview(keyButton(k, minWidth: 38, action: #selector(keyTapped(_:))))
            }
            scroll.addSubview(stack)

            let done = keyButton("Xong", minWidth: 54, action: #selector(doneTapped))
            done.translatesAutoresizingMaskIntoConstraints = false

            bar.addSubview(scroll)
            bar.addSubview(done)

            NSLayoutConstraint.activate([
                done.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -8),
                done.centerYAnchor.constraint(equalTo: bar.centerYAnchor),
                done.heightAnchor.constraint(equalToConstant: 32),
                scroll.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 6),
                scroll.trailingAnchor.constraint(equalTo: done.leadingAnchor, constant: -6),
                scroll.topAnchor.constraint(equalTo: bar.topAnchor),
                scroll.bottomAnchor.constraint(equalTo: bar.bottomAnchor),
                stack.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor),
                stack.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
                stack.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 6),
                stack.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -6),
                scroll.contentLayoutGuide.heightAnchor.constraint(equalTo: scroll.frameLayoutGuide.heightAnchor)
            ])
            return bar
        }

        private func keyButton(_ title: String, minWidth: CGFloat, action: Selector) -> UIButton {
            let b = UIButton(type: .system)
            b.setTitle(title, for: .normal)
            b.titleLabel?.font = UIFont.monospacedSystemFont(ofSize: 17, weight: .medium)
            b.backgroundColor = .tertiarySystemBackground
            b.layer.cornerRadius = 6
            b.widthAnchor.constraint(greaterThanOrEqualToConstant: minWidth).isActive = true
            b.addTarget(self, action: action, for: .touchUpInside)
            return b
        }

        @objc func keyTapped(_ sender: UIButton) {
            guard let tv = view, let k = sender.title(for: .normal) else { return }
            switch k {
            case "↶":
                tv.undoManager?.undo()
                textViewDidChange(tv)
            case "↷":
                tv.undoManager?.redo()
                textViewDidChange(tv)
            case "⇥":
                tv.insertText("    ")
            default:
                tv.insertText(k)
            }
        }

        @objc func doneTapped() {
            view?.resignFirstResponder()
        }
    }
}
