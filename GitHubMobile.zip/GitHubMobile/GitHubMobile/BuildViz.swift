import SwiftUI
import UIKit

// MARK: - Trạng thái dùng chung cho hiệu ứng

enum RunState: Equatable {
    case queued, running, success, failure, cancelled, skipped, other

    init(status: String?, conclusion: String?) {
        if status == "completed" {
            switch conclusion ?? "" {
            case "success": self = .success
            case "failure", "timed_out", "startup_failure": self = .failure
            case "cancelled": self = .cancelled
            case "skipped": self = .skipped
            default: self = .other
            }
        } else if status == "in_progress" {
            self = .running
        } else {
            self = .queued
        }
    }

    var color: Color {
        switch self {
        case .queued: return Theme.queued
        case .running: return Theme.neon
        case .success: return Theme.good
        case .failure: return Theme.bad
        case .cancelled, .skipped: return Color.gray
        case .other: return Theme.warn
        }
    }

    var symbol: String {
        switch self {
        case .queued: return "clock"
        case .running: return "bolt.fill"
        case .success: return "checkmark"
        case .failure: return "xmark"
        case .cancelled: return "slash.circle"
        case .skipped: return "arrow.right"
        case .other: return "exclamationmark"
        }
    }
}

// MARK: - Hiệu ứng nhỏ

struct ShakeEffect: GeometryEffect {
    var travel: CGFloat = 8
    var shakes: CGFloat = 3
    var animatableData: CGFloat

    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(CGAffineTransform(
            translationX: travel * sin(animatableData * .pi * shakes * 2), y: 0))
    }
}

/// Vòng tròn trạng thái: quay khi đang chạy, bật lên khi xong, rung khi lỗi
struct StatusOrb: View {
    let state: RunState
    var size: CGFloat = 84

    @State private var appeared = false
    @State private var shake: CGFloat = 0

    var body: some View {
        ZStack {
            Circle()
                .fill(state.color.opacity(0.22))
                .blur(radius: 18)
                .frame(width: size * 1.25, height: size * 1.25)

            if state == .running {
                TimelineView(.animation) { ctx in
                    let t = ctx.date.timeIntervalSinceReferenceDate
                    let spin = (t.truncatingRemainder(dividingBy: 1.6) / 1.6) * 360
                    let breathe = CGFloat((sin(t * 3) + 1) / 2)
                    ZStack {
                        Circle()
                            .strokeBorder(
                                AngularGradient(
                                    colors: [state.color.opacity(0), state.color, Theme.accent2, state.color.opacity(0)],
                                    center: .center),
                                lineWidth: 5)
                            .rotationEffect(.degrees(spin))
                        Circle()
                            .strokeBorder(state.color.opacity(0.28), lineWidth: 1)
                            .scaleEffect(1.0 + 0.14 * breathe)
                    }
                }
            } else {
                Circle()
                    .strokeBorder(state.color.opacity(0.95), lineWidth: 5)
                    .shadow(color: state.color.opacity(0.7), radius: 8)
            }

            Image(systemName: state.symbol)
                .font(.system(size: size * 0.38, weight: .bold))
                .foregroundStyle(state.color)
                .shadow(color: state.color.opacity(0.8), radius: 6)
                .scaleEffect(appeared ? 1 : 0.3)
                .opacity(appeared ? 1 : 0)
        }
        .frame(width: size, height: size)
        .modifier(ShakeEffect(animatableData: shake))
        .onAppear { trigger() }
        .onChange(of: state) { _ in trigger() }
    }

    private func trigger() {
        appeared = false
        shake = 0
        withAnimation(.spring(response: 0.5, dampingFraction: 0.55)) { appeared = true }
        if state == .failure {
            withAnimation(.easeInOut(duration: 0.6).delay(0.15)) { shake = 1 }
        }
    }
}

/// Thanh tiến độ phát sáng, có vệt sáng chạy khi đang hoạt động
struct ShimmerBar: View {
    let progress: Double
    let color: Color
    let active: Bool

    var body: some View {
        GeometryReader { geo in
            let p = min(max(progress, 0), 1)
            let w = geo.size.width * CGFloat(p)
            ZStack(alignment: .leading) {
                Capsule().fill(Theme.track)
                Capsule()
                    .fill(LinearGradient(colors: [color, Theme.accent2],
                                         startPoint: .leading, endPoint: .trailing))
                    .frame(width: p > 0 ? max(w, 8) : 0)
                    .overlay {
                        if active {
                            TimelineView(.animation) { ctx in
                                let t = ctx.date.timeIntervalSinceReferenceDate
                                let phase = CGFloat((t * 0.9).truncatingRemainder(dividingBy: 1))
                                LinearGradient(colors: [.clear, .white.opacity(0.6), .clear],
                                               startPoint: .leading, endPoint: .trailing)
                                    .frame(width: 60)
                                    .offset(x: (phase - 0.5) * (max(w, 8) + 60))
                            }
                            .clipShape(Capsule())
                        }
                    }
                    .shadow(color: color.opacity(0.7), radius: 6)
            }
        }
        .frame(height: 8)
        .animation(.easeInOut(duration: 0.6), value: progress)
    }
}

/// Chấm trên đường thời gian: có sóng lan ra khi bước đang chạy
struct StepDot: View {
    let state: RunState

    var body: some View {
        ZStack {
            if state == .running {
                TimelineView(.animation) { ctx in
                    let t = ctx.date.timeIntervalSinceReferenceDate
                    let k = CGFloat((t * 1.2).truncatingRemainder(dividingBy: 1))
                    Circle()
                        .stroke(state.color.opacity(Double(1 - k)), lineWidth: 2)
                        .scaleEffect(0.6 + k * 0.9)
                }
            }
            Circle()
                .fill(state == .queued ? Theme.trackStrong : state.color)
                .frame(width: 12, height: 12)
                .shadow(color: state == .queued ? .clear : state.color.opacity(0.85),
                        radius: state == .running ? 7 : 3)
        }
        .frame(width: 22, height: 22)
    }
}

struct PulseModifier: ViewModifier {
    let active: Bool

    func body(content: Content) -> some View {
        if active {
            TimelineView(.animation) { ctx in
                content
                    .opacity(0.7 + 0.3 * sin(ctx.date.timeIntervalSinceReferenceDate * 4))
                    .shadow(color: Theme.neon.opacity(0.7), radius: 4)
            }
        } else {
            content
        }
    }
}

// MARK: - Thẻ tổng quan một lần chạy

struct RunHero: View {
    let run: WorkflowRun
    let jobs: [Job]

    private var state: RunState { RunState(status: run.status, conclusion: run.conclusion) }
    private var allSteps: [Step] { jobs.flatMap { $0.steps ?? [] } }
    private var done: Int { allSteps.filter { $0.status == "completed" }.count }
    private var total: Int { allSteps.count }
    private var progress: Double {
        if state == .success { return 1 }
        return total == 0 ? 0 : Double(done) / Double(total)
    }
    private var started: Date? { jobs.compactMap { $0.startedAt }.min() }
    private var finished: Date? { jobs.compactMap { $0.completedAt }.max() }

    var body: some View {
        VStack(spacing: 12) {
            StatusOrb(state: state)

            Text(statusText(run.status, run.conclusion))
                .font(.title3.weight(.bold))
                .foregroundStyle(state.color)

            Text(run.title)
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .lineLimit(2)

            if state == .running, let s = started ?? run.createdAt {
                Text(s, style: .timer)
                    .font(.system(size: 30, weight: .semibold, design: .monospaced))
                    .foregroundStyle(Theme.neon)
                    .shadow(color: Theme.neon.opacity(0.5), radius: 6)
            } else if state == .queued {
                Text("Đang chờ máy chạy...")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            } else {
                let d = durationText(started, finished)
                if !d.isEmpty {
                    Text(d)
                        .font(.system(size: 24, weight: .semibold, design: .monospaced))
                        .foregroundStyle(.primary.opacity(0.9))
                }
            }

            if total > 0 {
                VStack(spacing: 6) {
                    ShimmerBar(progress: progress, color: state.color, active: state == .running)
                    Text("\(done)/\(total) bước · \(Int(progress * 100))%")
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
                .padding(.horizontal, 6)
            }

            Text("#\(run.runNumber) · \(run.headBranch ?? "-") · \(relative(run.createdAt))")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(18)
        .glassCard(glow: state.color)
        .padding(.horizontal, 14)
    }
}

// MARK: - Đường thời gian các bước

struct StepTimelineRow: View {
    let step: Step
    let isLast: Bool

    private var state: RunState { RunState(status: step.status, conclusion: step.conclusion) }

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            StepDot(state: state)
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(step.name)
                    .font(.footnote.weight(state == .running ? .semibold : .regular))
                    .foregroundStyle(state == .queued ? Color.secondary : Color.primary)
                    .lineLimit(2)
                Spacer(minLength: 4)
                if state == .running, let st = step.startedAt {
                    Text(st, style: .timer)
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(Theme.neon)
                } else {
                    let d = durationText(step.startedAt, step.completedAt)
                    if !d.isEmpty {
                        Text(d).font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            .padding(.top, 3)
        }
        .padding(.vertical, 4)
        .overlay(alignment: .topLeading) {
            if !isLast {
                Rectangle()
                    .fill(state == .success ? Theme.good.opacity(0.45) : Theme.trackStrong)
                    .frame(width: 2)
                    .padding(.leading, 10)
                    .padding(.top, 26)
            }
        }
        .animation(.spring(response: 0.4, dampingFraction: 0.8), value: state)
    }
}

// MARK: - Xem lại quá trình build

private enum ReplayLineKind { case normal, group, error, warning, command }

private struct ReplayLine: Identifiable {
    let id: Int
    let t: Double
    let text: String
    let kind: ReplayLineKind
}

private struct ReplayStep: Identifiable {
    let id: String
    let name: String
    let start: Double
    let end: Double
    let state: RunState
}

private struct ReplayGroup: Identifiable {
    let id: Int
    let job: Job
    let steps: [ReplayStep]
}

struct BuildReplayView: View {
    let repo: Repo
    let run: WorkflowRun
    let jobs: [Job]

    @EnvironmentObject var session: Session
    @Environment(\.dismiss) private var dismiss

    private let base: Date
    private let duration: Double
    private let groups: [ReplayGroup]

    @State private var pos: Double = 0
    @State private var playing = false
    @State private var speedIndex = 0
    @State private var selectedJob: Int
    @State private var logs: [Int: [ReplayLine]] = [:]
    @State private var logError: String?
    @State private var finishedSignal = false

    private static let speeds: [(String, Double?)] = [
        ("Tự động (khoảng 20 giây)", nil), ("1x", 1), ("10x", 10), ("60x", 60)
    ]

    init(repo: Repo, run: WorkflowRun, jobs: [Job]) {
        self.repo = repo
        self.run = run
        self.jobs = jobs

        var dates: [Date] = []
        for j in jobs {
            if let s = j.startedAt { dates.append(s) }
            for st in j.steps ?? [] { if let s = st.startedAt { dates.append(s) } }
        }
        let b = dates.min() ?? run.createdAt ?? Date()
        base = b

        var gs: [ReplayGroup] = []
        var maxEnd = 0.0
        for j in jobs {
            var list: [ReplayStep] = []
            for st in (j.steps ?? []).sorted(by: { $0.number < $1.number }) {
                guard let s = st.startedAt, let e = st.completedAt else { continue }
                let a = max(0, s.timeIntervalSince(b))
                let z = max(a, e.timeIntervalSince(b))
                maxEnd = max(maxEnd, z)
                list.append(ReplayStep(id: "\(j.id)-\(st.number)", name: st.name, start: a, end: z,
                                       state: RunState(status: st.status, conclusion: st.conclusion)))
            }
            if list.isEmpty, let s = j.startedAt, let e = j.completedAt {
                let a = max(0, s.timeIntervalSince(b))
                let z = max(a, e.timeIntervalSince(b))
                maxEnd = max(maxEnd, z)
                list.append(ReplayStep(id: "\(j.id)-job", name: j.name, start: a, end: z,
                                       state: RunState(status: j.status, conclusion: j.conclusion)))
            }
            if !list.isEmpty { gs.append(ReplayGroup(id: j.id, job: j, steps: list)) }
        }
        groups = gs
        duration = max(1, maxEnd)
        let failed = jobs.first { $0.conclusion == "failure" }
        _selectedJob = State(initialValue: (failed ?? jobs.first)?.id ?? 0)
    }

    private var finalState: RunState { RunState(status: run.status, conclusion: run.conclusion) }
    private var speed: Double {
        BuildReplayView.speeds[speedIndex].1 ?? max(1, duration / 20)
    }
    private var currentState: RunState { pos >= duration ? finalState : .running }

    private func clock(_ s: Double) -> String {
        let v = Int(s.rounded(.down))
        return String(format: "%02d:%02d", v / 60, v % 60)
    }

    private func stateAt(_ s: ReplayStep) -> RunState {
        if pos < s.start { return .queued }
        if pos < s.end { return .running }
        return s.state == .queued || s.state == .running ? .success : s.state
    }

    var body: some View {
        ZStack {
            AppBackground()
            if groups.isEmpty {
                Text("Lần chạy này chưa có dữ liệu thời gian để phát lại.")
                    .foregroundStyle(.secondary)
                    .padding()
            } else {
                VStack(spacing: 10) {
                    header
                    gantt
                    terminal
                    controls
                }
                .padding(.horizontal, 14)
                .padding(.bottom, 8)
            }
        }
        .navigationTitle("Phát lại build")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Đóng") { dismiss() }
            }
        }
        .onReceive(Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()) { _ in
            guard playing else { return }
            pos += speed * 0.05
            if pos >= duration {
                pos = duration
                playing = false
                if finalState == .success { Haptics.success() } else if finalState == .failure { Haptics.error() }
            }
        }
        .task(id: selectedJob) { await loadLog(selectedJob) }
        .task {
            try? await Task.sleep(nanoseconds: 600_000_000)
            playing = true
        }
    }

    // MARK: Phần tử giao diện

    private var header: some View {
        HStack(spacing: 14) {
            StatusOrb(state: currentState, size: 54)
            VStack(alignment: .leading, spacing: 2) {
                Text("\(clock(pos)) / \(clock(duration))")
                    .font(.system(size: 26, weight: .semibold, design: .monospaced))
                    .foregroundStyle(currentState.color)
                Text(pos >= duration ? statusText(run.status, run.conclusion) : "Đang phát lại · \(run.title)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer()
        }
        .padding(12)
        .glassCard(glow: currentState.color)
    }

    private var runningStepID: String? {
        for g in groups {
            for s in g.steps where stateAt(s) == .running { return s.id }
        }
        return nil
    }

    private var gantt: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(groups) { g in
                        Text(g.job.name)
                            .font(.caption.weight(.bold))
                            .foregroundStyle(Theme.accent)
                            .padding(.top, 4)
                        ForEach(g.steps) { s in
                            stepBar(s).id(s.id)
                        }
                    }
                }
                .padding(12)
                .overlay {
                    GeometryReader { geo in
                        let x = geo.size.width - 24
                        Rectangle()
                            .fill(Theme.neon)
                            .frame(width: 2)
                            .shadow(color: Theme.neon, radius: 6)
                            .offset(x: 12 + x * CGFloat(pos / duration))
                            .opacity(pos > 0 ? 0.9 : 0)
                    }
                    .allowsHitTesting(false)
                }
            }
            .onChange(of: runningStepID) { id in
                if let id = id {
                    withAnimation(.easeInOut(duration: 0.3)) { proxy.scrollTo(id, anchor: .center) }
                }
            }
        }
        .glassCard(glow: Theme.accent)
    }

    private func stepBar(_ s: ReplayStep) -> some View {
        let st = stateAt(s)
        return VStack(alignment: .leading, spacing: 3) {
            HStack(spacing: 6) {
                StepDot(state: st).scaleEffect(0.7).frame(width: 16, height: 16)
                Text(s.name)
                    .font(.caption2)
                    .foregroundStyle(st == .queued ? Color.secondary : Color.primary)
                    .lineLimit(1)
                Spacer()
                Text(String(format: "%.0fs", max(0, s.end - s.start)))
                    .font(.caption2.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            GeometryReader { geo in
                let w = geo.size.width
                let x0 = w * CGFloat(s.start / duration)
                let full = max(4, w * CGFloat((s.end - s.start) / duration))
                let fillEnd = min(max(pos, s.start), s.end)
                let filled = w * CGFloat((fillEnd - s.start) / duration)
                ZStack(alignment: .leading) {
                    Capsule().fill(Theme.track)
                    Capsule().fill(s.state.color.opacity(0.22))
                        .frame(width: full)
                        .offset(x: x0)
                    Capsule().fill(st == .running ? Theme.neon : s.state.color)
                        .frame(width: max(0, filled))
                        .offset(x: x0)
                        .shadow(color: (st == .running ? Theme.neon : s.state.color).opacity(0.7), radius: 4)
                }
            }
            .frame(height: 6)
        }
    }

    private var visibleLines: ArraySlice<ReplayLine> {
        guard let all = logs[selectedJob], !all.isEmpty else { return [] }
        let limit = pos
        var lo = 0
        var hi = all.count
        while lo < hi {
            let mid = (lo + hi) / 2
            if all[mid].t <= limit { lo = mid + 1 } else { hi = mid }
        }
        return all[max(0, lo - 80)..<lo]
    }

    private var terminal: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Image(systemName: "terminal").foregroundStyle(Theme.neon)
                Text("Log").font(.caption.weight(.bold))
                Spacer()
                if jobs.count > 1 {
                    Picker("Job", selection: $selectedJob) {
                        ForEach(jobs) { j in Text(j.name).tag(j.id) }
                    }
                    .pickerStyle(.menu)
                    .labelsHidden()
                    .scaleEffect(0.9)
                }
            }
            .padding(.horizontal, 12)
            .padding(.top, 8)

            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 1) {
                        if let e = logError {
                            Text(e).font(.caption2).foregroundStyle(.secondary)
                        } else if logs[selectedJob] == nil {
                            ProgressView().controlSize(.small)
                        }
                        ForEach(visibleLines) { l in
                            Text(l.text)
                                .font(.system(size: 10.5, design: .monospaced))
                                .foregroundStyle(color(for: l.kind))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .id(l.id)
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                }
                .onChange(of: visibleLines.last?.id) { id in
                    if let id = id { proxy.scrollTo(id, anchor: .bottom) }
                }
            }
        }
        .frame(height: 170)
        .environment(\.colorScheme, .dark)
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Theme.terminalBG))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous)
            .strokeBorder(Theme.neon.opacity(0.25), lineWidth: 1))
    }

    private func color(for k: ReplayLineKind) -> Color {
        switch k {
        case .normal: return Color.white.opacity(0.78)
        case .group: return Theme.neon
        case .error: return Theme.bad
        case .warning: return Theme.warn
        case .command: return Theme.accent.opacity(0.9)
        }
    }

    private var controls: some View {
        HStack(spacing: 12) {
            Button {
                Haptics.tap()
                pos = 0
                playing = true
            } label: {
                Image(systemName: "arrow.counterclockwise").font(.title3)
            }
            .buttonStyle(PressableStyle())

            Button {
                Haptics.tap()
                if pos >= duration { pos = 0 }
                playing.toggle()
            } label: {
                Image(systemName: playing ? "pause.fill" : "play.fill")
                    .font(.title2)
                    .foregroundStyle(.white)
                    .frame(width: 52, height: 52)
                    .background(Circle().fill(Theme.brandGradient))
                    .shadow(color: Theme.accent.opacity(0.8), radius: 10)
            }
            .buttonStyle(PressableStyle())

            Slider(value: $pos, in: 0...duration) { editing in
                if editing { playing = false }
            }
            .tint(Theme.neon)

            Menu {
                Picker("Tốc độ", selection: $speedIndex) {
                    ForEach(0..<BuildReplayView.speeds.count, id: \.self) { i in
                        Text(BuildReplayView.speeds[i].0).tag(i)
                    }
                }
            } label: {
                Text(speedIndex == 0 ? "Auto" : BuildReplayView.speeds[speedIndex].0)
                    .font(.caption.weight(.bold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Capsule().fill(Theme.trackStrong))
            }
        }
        .padding(10)
        .glassCard(glow: Theme.accent2)
    }

    // MARK: Tải và phân tích log

    private static let iso: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return f
    }()

    /// "2026-11-02T08:40:42.1234567Z nội dung" -> (thời điểm, nội dung)
    private static func parse(_ l: Substring) -> (Date, String)? {
        guard l.count > 21, l.hasPrefix("20"), let sp = l.firstIndex(of: " ") else { return nil }
        let head = l[l.startIndex..<sp]
        guard head.hasSuffix("Z"), head.contains("T"), head.count <= 32 else { return nil }
        var s = String(head)
        if let dot = s.firstIndex(of: ".") {
            let frac = s[s.index(after: dot)..<s.index(before: s.endIndex)]
            let cut = String(frac.prefix(3)).padding(toLength: 3, withPad: "0", startingAt: 0)
            s = String(s[..<dot]) + "." + cut + "Z"
        } else {
            s = String(s.dropLast()) + ".000Z"
        }
        guard let d = iso.date(from: s) else { return nil }
        return (d, String(l[l.index(after: sp)...]))
    }

    private func loadLog(_ id: Int) async {
        if id == 0 || logs[id] != nil { return }
        do {
            let raw = try await session.api.log(repo, jobId: id)
            let clean = raw
                .replacingOccurrences(of: "\u{FEFF}", with: "")
                .replacingOccurrences(of: "\r", with: "")
                .replacingOccurrences(of: "\u{1B}\\[[0-9;]*[A-Za-z]", with: "", options: .regularExpression)
            var out: [ReplayLine] = []
            var lastT = 0.0
            for (i, sub) in clean.split(separator: "\n", omittingEmptySubsequences: true).enumerated() {
                var text = String(sub)
                if let (d, rest) = BuildReplayView.parse(sub) {
                    lastT = max(lastT, d.timeIntervalSince(base))
                    text = rest
                }
                if text.hasPrefix("##[endgroup]") { continue }
                var kind = ReplayLineKind.normal
                let low = text.lowercased()
                if text.hasPrefix("##[group]") {
                    kind = .group
                    text = "▸ " + text.dropFirst("##[group]".count)
                } else if low.contains("##[error]") || low.contains("error:") || low.contains("** build failed") {
                    kind = .error
                } else if low.contains("##[warning]") || low.contains("warning:") {
                    kind = .warning
                } else if text.hasPrefix("[command]") {
                    kind = .command
                }
                out.append(ReplayLine(id: i, t: max(0, lastT), text: text, kind: kind))
            }
            logs[id] = out
            logError = nil
        } catch let e {
            logError = e.localizedDescription
        }
    }
}
