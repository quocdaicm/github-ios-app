import SwiftUI
import UIKit

// MARK: - Gói thay đổi (gom nhiều thay đổi rồi commit một lần)

final class Staging: ObservableObject {
    @Published private(set) var store: [String: [Change]] = [:]

    static func key(_ repo: Repo, _ branch: String) -> String {
        repo.fullName + "@" + branch
    }

    func changes(_ key: String) -> [Change] { store[key] ?? [] }
    func count(_ key: String) -> Int { store[key]?.count ?? 0 }

    func stagedPut(_ key: String, _ path: String) -> Data? {
        for c in store[key] ?? [] {
            if case .put(let p, let d) = c, p == path { return d }
        }
        return nil
    }

    func add(_ c: Change, key: String) {
        addMany([c], key: key)
    }

    func addMany(_ cs: [Change], key: String) {
        var list = store[key] ?? []
        for c in cs {
            switch c {
            case .put(let p, _):
                list.removeAll { old in
                    if case .put(let q, _) = old { return q == p }
                    return false
                }
            case .delete(let p, _):
                list.removeAll { old in
                    if case .put(let q, _) = old { return q == p || q.hasPrefix(p + "/") }
                    return false
                }
            case .move:
                break
            }
            list.append(c)
        }
        store[key] = list
    }

    func remove(_ id: String, key: String) {
        guard var list = store[key] else { return }
        list.removeAll { $0.id == id }
        store[key] = list.isEmpty ? nil : list
    }

    func clear(_ key: String) {
        store[key] = nil
    }
}

struct StagedChangesView: View {
    let repo: Repo
    let branch: String
    var onDone: (String) -> Void = { _ in }

    @EnvironmentObject var session: Session
    @EnvironmentObject var staging: Staging
    @Environment(\.dismiss) private var dismiss

    @State private var message = ""
    @State private var busy = false
    @State private var status = ""
    @State private var error: String?

    private var key: String { Staging.key(repo, branch) }
    private var list: [Change] { staging.changes(key) }

    private var defaultMessage: String {
        if list.count == 1, let c = list.first { return c.summary }
        return "Cập nhật \(list.count) thay đổi"
    }

    var body: some View {
        NavigationStack {
            List {
                Section("Thay đổi (\(list.count))") {
                    ForEach(list) { c in
                        row(c)
                    }
                    .onDelete { idx in
                        let ids = idx.map { list[$0].id }
                        for id in ids { staging.remove(id, key: key) }
                    }
                }

                Section("Nội dung commit") {
                    TextField(defaultMessage, text: $message, axis: .vertical)
                }

                if let error = error {
                    Section { Text(error).foregroundStyle(.red) }
                }

                Section {
                    Button {
                        Task { await commit() }
                    } label: {
                        if busy {
                            HStack(spacing: 8) {
                                ProgressView()
                                Text(status).font(.footnote)
                            }
                        } else {
                            Text("Commit \(list.count) thay đổi lên \(branch)")
                        }
                    }
                    .disabled(busy || list.isEmpty)

                    Button("Bỏ hết gói", role: .destructive) {
                        staging.clear(key)
                        dismiss()
                    }
                    .disabled(busy)
                }
            }
            .themedList()
            .navigationTitle("Gói commit")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Đóng") { dismiss() }
                }
            }
            .overlay {
                if list.isEmpty && !busy {
                    Text("Gói đang trống.").foregroundStyle(.secondary)
                }
            }
        }
    }

    @ViewBuilder
    private func row(_ c: Change) -> some View {
        switch c {
        case .put(let path, let data):
            if data.count < 400_000, String(data: data, encoding: .utf8) != nil {
                NavigationLink {
                    FileEditorView(repo: repo, branch: branch, path: path, isNew: false)
                } label: {
                    changeLabel(c, extra: sizeText(data.count))
                }
            } else {
                changeLabel(c, extra: sizeText(data.count))
            }
        default:
            changeLabel(c, extra: nil)
        }
    }

    private func changeLabel(_ c: Change, extra: String?) -> some View {
        HStack {
            Label(c.summary, systemImage: c.icon)
                .font(.footnote)
                .lineLimit(3)
            if let extra = extra {
                Spacer()
                Text(extra).font(.caption2).foregroundStyle(.secondary)
            }
        }
    }

    private func commit() async {
        busy = true
        error = nil
        defer { busy = false }
        let m = message.trimmingCharacters(in: .whitespacesAndNewlines)
        let count = list.count
        do {
            try await session.api.commitChanges(
                repo,
                branch: branch,
                message: m.isEmpty ? defaultMessage : m,
                changes: list
            ) { s in
                Task { @MainActor in status = s }
            }
            staging.clear(key)
            onDone("Đã commit \(count) thay đổi lên nhánh \(branch).")
            dismiss()
        } catch let e {
            error = e.localizedDescription
        }
    }
}

// MARK: - Tải file / thư mục lên

struct UploadFile: Identifiable, Sendable {
    let id = UUID()
    let root: String?
    let rel: String
    let data: Data

    func path(keepRoot: Bool) -> String {
        if let r = root, keepRoot { return r + "/" + rel }
        return rel
    }
}

struct UploadBatch: Identifiable, Sendable {
    let id = UUID()
    let files: [UploadFile]
    let skipped: Int
    let notes: [String]
}

enum UploadReader {
    static let maxFile = 90 * 1024 * 1024
    static let maxTotal = 200 * 1024 * 1024
    static let maxCount = 1000

    /// Đọc file/thư mục người dùng chọn (chạy ngoài luồng chính)
    static func read(_ urls: [URL], unzip: Bool = false) -> UploadBatch {
        var files: [UploadFile] = []
        var skipped = 0
        var total = 0
        var notes: [String] = []

        func add(root: String?, rel: String, url: URL) {
            if files.count >= maxCount { skipped += 1; return }
            guard let d = try? Data(contentsOf: url) else { skipped += 1; return }
            if d.count > maxFile || total + d.count > maxTotal { skipped += 1; return }
            total += d.count
            files.append(UploadFile(root: root, rel: rel, data: d))
        }

        for url in urls {
            let ok = url.startAccessingSecurityScopedResource()
            defer { if ok { url.stopAccessingSecurityScopedResource() } }

            let isDir = (try? url.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory == true
            if !isDir && unzip {
                let name = url.lastPathComponent
                do {
                    let zd = try Data(contentsOf: url)
                    let r = try ZipReader.extract(zd,
                                                  maxFile: maxFile,
                                                  maxTotal: maxTotal - total,
                                                  maxCount: maxCount - files.count)
                    skipped += r.skipped
                    if r.files.isEmpty {
                        notes.append("\(name): không có file nào để giải nén.")
                    }
                    // Nếu mọi file nằm trong đúng một thư mục gốc thì coi đó là "thư mục gốc"
                    let tops = Set(r.files.compactMap { $0.path.split(separator: "/").first.map(String.init) })
                    let single = tops.count == 1 && r.files.allSatisfy { $0.path.contains("/") }
                    for f in r.files {
                        total += f.data.count
                        if single, let top = tops.first {
                            files.append(UploadFile(root: top,
                                                    rel: String(f.path.dropFirst(top.count + 1)),
                                                    data: f.data))
                        } else {
                            files.append(UploadFile(root: nil, rel: f.path, data: f.data))
                        }
                    }
                } catch let e {
                    notes.append("\(name): \(e.localizedDescription)")
                }
                continue
            }

            if !isDir {
                add(root: nil, rel: url.lastPathComponent, url: url)
                continue
            }

            let rootName = url.lastPathComponent
            let base = url.resolvingSymlinksInPath().pathComponents
            guard let en = FileManager.default.enumerator(
                at: url,
                includingPropertiesForKeys: [.isRegularFileKey],
                options: []
            ) else { continue }

            for case let f as URL in en {
                guard (try? f.resourceValues(forKeys: [.isRegularFileKey]))?.isRegularFile == true else { continue }
                let comps = f.resolvingSymlinksInPath().pathComponents
                guard comps.count > base.count, Array(comps.prefix(base.count)) == base else { continue }
                let rest = Array(comps.dropFirst(base.count))
                if rest.contains(where: { $0 == ".DS_Store" || $0 == "__MACOSX" || $0 == ".git" || $0 == ".." || $0 == "." }) {
                    continue
                }
                add(root: rootName, rel: rest.joined(separator: "/"), url: f)
            }
        }
        return UploadBatch(files: files, skipped: skipped, notes: notes)
    }
}

struct UploadSheet: View {
    let repo: Repo
    let branch: String
    let dir: String
    let batch: UploadBatch
    var onDone: (String) -> Void

    @EnvironmentObject var session: Session
    @EnvironmentObject var staging: Staging
    @Environment(\.dismiss) private var dismiss

    @State private var keepRoot = true
    @State private var message = ""
    @State private var busy = false
    @State private var status = ""
    @State private var error: String?

    private var key: String { Staging.key(repo, branch) }
    private var hasFolder: Bool { batch.files.contains { $0.root != nil } }
    private var totalSize: Int { batch.files.reduce(0) { $0 + $1.data.count } }

    private func dest(_ f: UploadFile) -> String {
        let p = f.path(keepRoot: keepRoot)
        return dir.isEmpty ? p : dir + "/" + p
    }

    private var changes: [Change] {
        batch.files.map { Change.put(path: dest($0), data: $0.data) }
    }

    private var defaultMessage: String {
        batch.files.count == 1
            ? "Thêm \((dest(batch.files[0]) as NSString).lastPathComponent)"
            : "Tải lên \(batch.files.count) file"
    }

    var body: some View {
        NavigationStack {
            List {
                Section("Sẽ tải lên \(batch.files.count) file · \(sizeText(totalSize))") {
                    ForEach(batch.files.prefix(30)) { f in
                        Text(dest(f)).font(.caption).lineLimit(2)
                    }
                    if batch.files.count > 30 {
                        Text("… và \(batch.files.count - 30) file khác")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Text("File trùng đường dẫn sẽ bị ghi đè.")
                        .font(.caption2).foregroundStyle(.secondary)
                }

                if batch.skipped > 0 {
                    Section {
                        Text("Bỏ qua \(batch.skipped) file (quá lớn, không đọc được hoặc vượt giới hạn).")
                            .font(.footnote).foregroundStyle(.orange)
                    }
                }

                if !batch.notes.isEmpty {
                    Section {
                        ForEach(batch.notes, id: \.self) { n in
                            Text(n).font(.footnote).foregroundStyle(.orange)
                        }
                    }
                }

                if hasFolder {
                    Section {
                        Toggle("Giữ tên thư mục gốc", isOn: $keepRoot)
                    } footer: {
                        Text("Tắt để đưa nội dung thư mục thẳng vào vị trí hiện tại.")
                    }
                }

                Section("Nội dung commit") {
                    TextField(defaultMessage, text: $message, axis: .vertical)
                }

                if let error = error {
                    Section { Text(error).foregroundStyle(.red) }
                }

                Section {
                    Button {
                        Task { await commitNow() }
                    } label: {
                        if busy {
                            HStack(spacing: 8) {
                                ProgressView()
                                Text(status).font(.footnote)
                            }
                        } else {
                            Text("Commit ngay lên \(branch)")
                        }
                    }
                    .disabled(busy)

                    Button("Thêm vào gói commit") {
                        staging.addMany(changes, key: key)
                        onDone("Đã thêm \(batch.files.count) file vào gói commit.")
                        dismiss()
                    }
                    .disabled(busy)
                }
            }
            .themedList()
            .navigationTitle("Tải lên")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Hủy") { dismiss() }.disabled(busy)
                }
            }
        }
        .interactiveDismissDisabled(busy)
    }

    private func commitNow() async {
        busy = true
        error = nil
        defer { busy = false }
        let m = message.trimmingCharacters(in: .whitespacesAndNewlines)
        let n = batch.files.count
        do {
            try await session.api.commitChanges(
                repo,
                branch: branch,
                message: m.isEmpty ? defaultMessage : m,
                changes: changes
            ) { s in
                Task { @MainActor in status = s }
            }
            onDone("Đã commit \(n) file lên nhánh \(branch).")
            dismiss()
        } catch let e {
            error = e.localizedDescription
        }
    }
}
