import Foundation
import Compression

/// Đọc file .zip (stored + deflate) hoàn toàn trong app, không cần thư viện ngoài.
enum ZipReader {
    struct Entry {
        let name: String
        let flags: Int
        let method: Int
        let compSize: Int
        let size: Int
        let offset: Int
    }

    private static func byte(_ d: Data, _ i: Int) -> Int {
        Int(d[d.startIndex + i])
    }

    private static func u16(_ d: Data, _ i: Int) -> Int {
        let a = byte(d, i)
        let b = byte(d, i + 1)
        return a | (b << 8)
    }

    private static func u32(_ d: Data, _ i: Int) -> Int {
        let a = byte(d, i)
        let b = byte(d, i + 1)
        let c = byte(d, i + 2)
        let e = byte(d, i + 3)
        return a | (b << 8) | (c << 16) | (e << 24)
    }

    private static let zip64Error = APIError(message: "Zip64 (file hoặc zip quá lớn) chưa được hỗ trợ.")
    private static let badZip = APIError(message: "Không phải file zip hợp lệ hoặc zip bị lỗi.")

    /// Đọc danh sách mục từ thư mục trung tâm của zip
    static func entries(_ d: Data) throws -> [Entry] {
        let n = d.count
        guard n >= 22 else { throw badZip }

        var eocd = -1
        var i = n - 22
        let lowest = max(0, n - 22 - 65535)
        while i >= lowest {
            if u32(d, i) == 0x06054b50 {
                eocd = i
                break
            }
            i -= 1
        }
        guard eocd >= 0 else { throw badZip }

        let total = u16(d, eocd + 10)
        let cdOff = u32(d, eocd + 16)
        if total == 0xFFFF || cdOff == 0xFFFFFFFF { throw zip64Error }

        var p = cdOff
        var list: [Entry] = []
        for _ in 0..<total {
            guard p + 46 <= n, u32(d, p) == 0x02014b50 else { throw badZip }
            let flags = u16(d, p + 8)
            let method = u16(d, p + 10)
            let cs = u32(d, p + 20)
            let us = u32(d, p + 24)
            let nl = u16(d, p + 28)
            let el = u16(d, p + 30)
            let cl = u16(d, p + 32)
            let off = u32(d, p + 42)
            if cs == 0xFFFFFFFF || us == 0xFFFFFFFF || off == 0xFFFFFFFF { throw zip64Error }
            guard p + 46 + nl <= n else { throw badZip }

            let from = d.startIndex + p + 46
            let nameData = d.subdata(in: from..<(from + nl))
            let name = String(data: nameData, encoding: .utf8)
                ?? String(data: nameData, encoding: .isoLatin1)
                ?? ""
            list.append(Entry(name: name, flags: flags, method: method,
                              compSize: cs, size: us, offset: off))
            p += 46 + nl + el + cl
        }
        return list
    }

    /// Chuẩn hóa đường dẫn; trả nil với thư mục, rác của macOS hoặc đường dẫn nguy hiểm (../)
    private static func clean(_ name: String) -> String? {
        if name.hasSuffix("/") { return nil }
        let parts = name.replacingOccurrences(of: "\\", with: "/")
            .split(separator: "/", omittingEmptySubsequences: true)
            .map(String.init)
        if parts.isEmpty { return nil }
        for p in parts {
            if p == ".." || p == "." || p == "__MACOSX" || p == ".git" { return nil }
        }
        if parts.last == ".DS_Store" { return nil }
        return parts.joined(separator: "/")
    }

    private static func payload(_ zip: Data, _ e: Entry) -> Data? {
        guard e.offset + 30 <= zip.count, u32(zip, e.offset) == 0x04034b50 else { return nil }
        let nl = u16(zip, e.offset + 26)
        let el = u16(zip, e.offset + 28)
        let start = e.offset + 30 + nl + el
        guard start + e.compSize <= zip.count else { return nil }
        let a = zip.startIndex + start
        return zip.subdata(in: a..<(a + e.compSize))
    }

    /// Giải nén deflate thô (không có header zlib) với kích thước đầu ra đã biết
    private static func inflate(_ src: Data, expected: Int) -> Data? {
        if expected == 0 { return Data() }
        var out = Data(count: expected)
        let produced: Int = out.withUnsafeMutableBytes { (dst: UnsafeMutableRawBufferPointer) -> Int in
            src.withUnsafeBytes { (s: UnsafeRawBufferPointer) -> Int in
                guard let dp = dst.bindMemory(to: UInt8.self).baseAddress,
                      let sp = s.bindMemory(to: UInt8.self).baseAddress else { return 0 }
                return compression_decode_buffer(dp, expected, sp, src.count, nil, COMPRESSION_ZLIB)
            }
        }
        return produced == expected ? out : nil
    }

    /// Giải nén toàn bộ zip trong bộ nhớ, có giới hạn chống zip bomb
    static func extract(_ zip: Data,
                        maxFile: Int,
                        maxTotal: Int,
                        maxCount: Int) throws -> (files: [(path: String, data: Data)], skipped: Int) {
        let list = try entries(zip)
        var out: [(path: String, data: Data)] = []
        var skipped = 0
        var total = 0

        for e in list {
            guard let path = clean(e.name) else { continue }
            if e.flags & 1 != 0 { skipped += 1; continue }   // file có mật khẩu
            if out.count >= maxCount || e.size > maxFile || total + e.size > maxTotal {
                skipped += 1
                continue
            }
            guard let raw = payload(zip, e) else { skipped += 1; continue }

            let data: Data?
            switch e.method {
            case 0:
                data = raw.count == e.size ? raw : nil
            case 8:
                data = inflate(raw, expected: e.size)
            default:
                data = nil
            }
            guard let d = data else { skipped += 1; continue }
            total += d.count
            out.append((path: path, data: d))
        }
        return (files: out, skipped: skipped)
    }
}
