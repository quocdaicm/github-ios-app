import SwiftUI

// MARK: - Tìm trong repo (tên file và nội dung, nhánh mặc định)

struct RepoSearchView: View {
    let repo: Repo
    var viewOnly: Bool = false

    @EnvironmentObject var session: Session
    @State private var query = ""
    @State private var hits: [CodeHit] = []
    @State private var total = 0
    @State private var searching = false
    @State private var searched = false
    @State private var error: String?

    var body: some View {
        List {
            Text("Tìm trong nhánh mặc định (\(repo.defaultBranch)) của \(repo.fullName). Gõ từ khóa rồi bấm Tìm.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .cardRow(vertical: 12)

            if let error = error {
                Text(error).font(.footnote).foregroundStyle(.red)
            } else if searched && hits.isEmpty && !searching {
                Text("Không tìm thấy kết quả. Repo mới tạo hoặc bản fork có thể chưa được GitHub lập chỉ mục.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            } else if total > hits.count {
                Text("Có \(total) kết quả, hiện \(hits.count) kết quả đầu.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            ForEach(hits) { h in
                NavigationLink {
                    FileEditorView(repo: repo, branch: repo.defaultBranch, path: h.path,
                                   isNew: false, viewOnly: viewOnly)
                } label: {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(h.name).font(.subheadline.weight(.semibold))
                        Text(h.path)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                        if let f = h.textMatches?.first?.fragment {
                            Text(f.trimmingCharacters(in: .whitespacesAndNewlines))
                                .font(.system(size: 11, design: .monospaced))
                                .foregroundStyle(.secondary)
                                .lineLimit(3)
                        }
                    }
                }
                .cardRow()
            }
        }
        .listStyle(.plain)
        .themedList()
        .overlay {
            if searching { ProgressView() }
        }
        .navigationTitle("Tìm trong repo")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, prompt: "Từ khóa, tên hàm, tên file")
        .onSubmit(of: .search) { Task { await run() } }
    }

    private func run() async {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard q.count >= 2 else { return }
        searching = true
        defer { searching = false }
        do {
            let r = try await session.api.searchCode(repo, q)
            hits = r.items
            total = r.totalCount
            error = nil
        } catch let e {
            hits = []
            total = 0
            error = e.localizedDescription
        }
        searched = true
    }
}
