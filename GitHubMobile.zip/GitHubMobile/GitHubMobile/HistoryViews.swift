import SwiftUI
import UIKit

// MARK: - Danh sách commit

struct CommitsView: View {
    let repo: Repo
    let branch: String

    @EnvironmentObject var session: Session
    @State private var commits: [GHCommit] = []
    @State private var page = 1
    @State private var hasMore = false
    @State private var loading = false
    @State private var loadingMore = false
    @State private var error: String?

    private let pageSize = 30

    var body: some View {
        List {
            if let error = error {
                Text(error).font(.footnote).foregroundStyle(.secondary)
            }
            ForEach(commits) { c in
                NavigationLink {
                    CommitDetailView(repo: repo, commit: c)
                } label: {
                    CommitRow(commit: c)
                }
                .cardRow()
            }
            if hasMore {
                Button {
                    Task { await loadMore() }
                } label: {
                    HStack {
                        Spacer()
                        if loadingMore { ProgressView() } else { Text("Tải thêm") }
                        Spacer()
                    }
                }
            }
        }
        .listStyle(.plain)
        .themedList()
        .overlay {
            if loading && commits.isEmpty { ProgressView() }
        }
        .refreshable { await reload() }
        .task(id: branch) { await reload() }
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                TranslateToggleButton()
            }
        }
    }

    private func reload() async {
        if loading { return }
        loading = true
        defer { loading = false }
        do {
            let first = try await session.api.commits(repo, branch: branch, page: 1)
            commits = first
            page = 1
            hasMore = first.count >= pageSize
            error = nil
        } catch let e {
            error = e.localizedDescription
        }
    }

    private func loadMore() async {
        if loadingMore { return }
        loadingMore = true
        defer { loadingMore = false }
        do {
            let next = try await session.api.commits(repo, branch: branch, page: page + 1)
            let have = Set(commits.map { $0.sha })
            commits += next.filter { !have.contains($0.sha) }
            page += 1
            hasMore = next.count >= pageSize
        } catch let e {
            error = e.localizedDescription
        }
    }
}

struct CommitRow: View {
    let commit: GHCommit

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            TranslatedText(text: commit.title)
                .font(.subheadline.weight(.medium))
                .lineLimit(2)
            HStack(spacing: 6) {
                Text(commit.shortSha)
                    .font(.system(size: 11, design: .monospaced))
                Text("· \(commit.authorName) · \(relative(commit.date))")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .padding(.vertical, 2)
    }
}

// MARK: - Chi tiết một commit

struct CommitDetailView: View {
    let repo: Repo
    let commit: GHCommit

    @EnvironmentObject var session: Session
    @State private var detail: CommitDetail?
    @State private var loading = true
    @State private var error: String?
    @State private var copied: String?

    var body: some View {
        List {
            Section {
                TranslatedText(text: commit.commit.message)
                    .font(.subheadline)
                    .textSelection(.enabled)
                Text("\(commit.shortSha) · \(commit.authorName) · \(relative(commit.date))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            if let error = error {
                Section { Text(error).font(.footnote).foregroundStyle(.secondary) }
            }

            if let files = detail?.files {
                Section("Thay đổi (\(files.count) file)") {
                    ForEach(files) { f in
                        NavigationLink {
                            DiffView(file: f)
                        } label: {
                            FileChangeRow(file: f)
                        }
                    }
                }
            }
        }
        .overlay {
            if loading && detail == nil { ProgressView() }
        }
        .themedList()
        .navigationTitle(commit.shortSha)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                TranslateToggleButton()
                Button {
                    UIPasteboard.general.string = commit.sha
                    copied = "Đã sao chép mã commit"
                } label: {
                    Image(systemName: "doc.on.doc")
                }
            }
        }
        .alert("Thông báo", isPresented: Binding(
            get: { copied != nil },
            set: { if !$0 { copied = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(copied ?? "")
        }
        .task { await load() }
    }

    private func load() async {
        loading = true
        defer { loading = false }
        do {
            detail = try await session.api.commit(repo, sha: commit.sha)
            error = nil
        } catch let e {
            error = e.localizedDescription
        }
    }
}

struct FileChangeRow: View {
    let file: CommitFile

    private var icon: (String, Color) {
        switch file.status {
        case "added": return ("plus.circle.fill", .green)
        case "removed": return ("minus.circle.fill", .red)
        case "renamed": return ("arrow.right.circle.fill", .blue)
        default: return ("pencil.circle.fill", .orange)
        }
    }

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon.0).foregroundStyle(icon.1)
            VStack(alignment: .leading, spacing: 2) {
                Text(file.filename)
                    .font(.subheadline)
                    .lineLimit(1)
                    .truncationMode(.middle)
                HStack(spacing: 8) {
                    Text("+\(file.additions)").foregroundStyle(.green)
                    Text("−\(file.deletions)").foregroundStyle(.red)
                }
                .font(.caption)
            }
        }
    }
}

// MARK: - Xem diff

struct DiffView: View {
    let file: CommitFile

    private let lines: [String]
    private let width: Int

    init(file: CommitFile) {
        self.file = file
        var ls = (file.patch ?? "").components(separatedBy: "\n")
        if ls.count > 4000 { ls = Array(ls.prefix(4000)) }
        lines = ls
        width = ls.map { $0.count }.max() ?? 0
    }

    private func rowColor(_ l: String) -> Color {
        if l.hasPrefix("+") { return Color.green.opacity(0.2) }
        if l.hasPrefix("-") { return Color.red.opacity(0.2) }
        if l.hasPrefix("@@") { return Color.blue.opacity(0.15) }
        return Color.clear
    }

    var body: some View {
        Group {
            if (file.patch ?? "").isEmpty {
                Text("Không có bản xem trước (file nhị phân, quá lớn hoặc chỉ đổi tên).")
                    .foregroundStyle(.secondary)
                    .padding()
            } else {
                ScrollView([.vertical, .horizontal]) {
                    LazyVStack(alignment: .leading, spacing: 0) {
                        ForEach(Array(lines.enumerated()), id: \.offset) { pair in
                            Text(pair.element.padding(toLength: width, withPad: " ", startingAt: 0))
                                .font(.system(size: 11, design: .monospaced))
                                .fixedSize(horizontal: true, vertical: false)
                                .background(rowColor(pair.element))
                        }
                    }
                    .padding(8)
                }
            }
        }
        .navigationTitle((file.filename as NSString).lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    UIPasteboard.general.string = file.patch ?? ""
                } label: {
                    Image(systemName: "doc.on.doc")
                }
                .disabled((file.patch ?? "").isEmpty)
            }
        }
    }
}
