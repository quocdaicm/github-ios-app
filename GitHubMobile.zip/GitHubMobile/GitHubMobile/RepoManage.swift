import SwiftUI

// MARK: - Sửa repo của tôi (tên, mô tả, riêng tư/công khai)

struct EditRepoView: View {
    let repo: Repo
    var onSaved: (Repo) -> Void

    @EnvironmentObject var session: Session
    @Environment(\.dismiss) private var dismiss

    @State private var name: String
    @State private var desc: String
    @State private var isPrivate: Bool
    @State private var busy = false
    @State private var error: String?

    init(repo: Repo, onSaved: @escaping (Repo) -> Void) {
        self.repo = repo
        self.onSaved = onSaved
        _name = State(initialValue: repo.name)
        _desc = State(initialValue: repo.description ?? "")
        _isPrivate = State(initialValue: repo.isPrivate)
    }

    private var cleanName: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: " ", with: "-")
    }

    private var cleanDesc: String {
        desc.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var valid: Bool {
        !cleanName.isEmpty
            && cleanName != "." && cleanName != ".."
            && cleanName.range(of: "^[A-Za-z0-9._-]+$", options: .regularExpression) != nil
    }

    private var changed: Bool {
        cleanName != repo.name
            || cleanDesc != (repo.description ?? "")
            || isPrivate != repo.isPrivate
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("ten-repo", text: $name)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .submitLabel(.done)
                } header: {
                    Text("Tên repo")
                } footer: {
                    if !name.isEmpty && !valid {
                        Text("Chỉ dùng chữ không dấu, số, dấu - _ . (khoảng trắng sẽ đổi thành -).")
                            .foregroundStyle(.red)
                    } else if cleanName != repo.name {
                        Text("Đổi tên sẽ đổi địa chỉ repo. GitHub tự chuyển hướng link cũ, nhưng workflow hoặc link đã lưu ở nơi khác nên kiểm tra lại.")
                    }
                }

                Section("Mô tả") {
                    TextField("Mô tả ngắn về repo", text: $desc)
                        .submitLabel(.done)
                }

                Section {
                    Toggle("Riêng tư (private)", isOn: $isPrivate)
                } footer: {
                    if isPrivate != repo.isPrivate {
                        Text(isPrivate
                             ? "Repo sẽ ẩn với mọi người trừ bạn và người được mời."
                             : "Repo sẽ công khai: ai cũng xem được toàn bộ mã nguồn và lịch sử.")
                    }
                }

                if let error = error {
                    Section { Text(error).foregroundStyle(.red) }
                }

                Section {
                    Button {
                        hideKeyboard()
                        Task { await save() }
                    } label: {
                        Group {
                            if busy {
                                ProgressView()
                            } else {
                                Text("Lưu thay đổi").fontWeight(.semibold)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .disabled(!valid || !changed || busy)
                }
            }
            .themedList()
            .navigationTitle("Sửa repo")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Hủy") { dismiss() }.disabled(busy)
                }
            }
        }
        .interactiveDismissDisabled(busy)
    }

    private func save() async {
        busy = true
        error = nil
        defer { busy = false }
        do {
            let updated = try await session.api.updateRepo(
                repo,
                name: cleanName,
                description: cleanDesc,
                isPrivate: isPrivate
            )
            onSaved(updated)
            dismiss()
        } catch let e {
            error = e.localizedDescription
        }
    }
}

// MARK: - Tải cả repo về dạng .zip

struct RepoZipButton: View {
    let repo: Repo
    let branch: String

    @EnvironmentObject var session: Session
    @State private var busy = false
    @State private var shared: SharedFile?
    @State private var error: String?

    var body: some View {
        Button {
            Task { await download() }
        } label: {
            if busy {
                ProgressView()
            } else {
                Image(systemName: "arrow.down.circle")
            }
        }
        .disabled(busy)
        .accessibilityLabel("Tải repo về (zip)")
        .sheet(item: $shared) { f in
            ShareSheet(items: [f.url])
        }
        .alert("Thông báo", isPresented: Binding(
            get: { error != nil },
            set: { if !$0 { error = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(error ?? "")
        }
    }

    private func download() async {
        busy = true
        defer { busy = false }
        do {
            let url = try await session.api.downloadRepoZip(repo, ref: branch)
            shared = SharedFile(url: url)
        } catch let e {
            error = e.localizedDescription
        }
    }
}

// MARK: - Tùy chọn khi fork (đặt tên, chỉ lấy nhánh mặc định)

struct ForkOptionsView: View {
    let repo: Repo
    var onConfirm: (String, Bool) -> Void

    @EnvironmentObject var session: Session
    @Environment(\.dismiss) private var dismiss
    @State private var name: String
    @State private var onlyDefault = false

    init(repo: Repo, onConfirm: @escaping (String, Bool) -> Void) {
        self.repo = repo
        self.onConfirm = onConfirm
        _name = State(initialValue: repo.name)
    }

    private var cleanName: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: " ", with: "-")
    }

    private var valid: Bool {
        !cleanName.isEmpty
            && cleanName != "." && cleanName != ".."
            && cleanName.range(of: "^[A-Za-z0-9._-]+$", options: .regularExpression) != nil
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text(repo.fullName).font(.subheadline)
                } header: {
                    Text("Repo gốc")
                }

                Section {
                    TextField("ten-ban-fork", text: $name)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .submitLabel(.done)
                } header: {
                    Text("Tên bản fork")
                } footer: {
                    if !name.isEmpty && !valid {
                        Text("Chỉ dùng chữ không dấu, số, dấu - _ .")
                            .foregroundStyle(.red)
                    } else {
                        Text("Để nguyên tên gốc hoặc đặt tên khác. Bản fork của repo public luôn là public.")
                    }
                }

                Section {
                    Toggle("Chỉ lấy nhánh mặc định (\(repo.defaultBranch))", isOn: $onlyDefault)
                } footer: {
                    Text(onlyDefault
                         ? "Bản fork nhẹ hơn, chỉ có một nhánh."
                         : "Lấy tất cả nhánh của repo gốc.")
                }

                Section {
                    Button {
                        hideKeyboard()
                        onConfirm(cleanName, onlyDefault)
                        dismiss()
                    } label: {
                        Text("Fork về \(session.login.isEmpty ? "tài khoản của tôi" : session.login)")
                            .fontWeight(.semibold)
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .disabled(!valid)
                }
            }
            .themedList()
            .navigationTitle("Fork repo")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Hủy") { dismiss() }
                }
            }
        }
    }
}

// MARK: - Nút gắn sao

struct StarButton: View {
    let repo: Repo

    @EnvironmentObject var session: Session
    @State private var starred: Bool?
    @State private var busy = false
    @State private var error: String?

    var body: some View {
        Button {
            Task { await toggle() }
        } label: {
            Image(systemName: starred == true ? "star.fill" : "star")
                .font(.subheadline)
                .foregroundStyle(starred == true ? Color.orange : Theme.accent)
        }
        .buttonStyle(.borderless)
        .disabled(starred == nil || busy)
        .accessibilityLabel(starred == true ? "Bỏ gắn sao" : "Gắn sao")
        .task { starred = await session.api.isStarred(repo) }
        .alert("Thông báo", isPresented: Binding(
            get: { error != nil },
            set: { if !$0 { error = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(error ?? "")
        }
    }

    private func toggle() async {
        guard let cur = starred else { return }
        busy = true
        defer { busy = false }
        do {
            try await session.api.setStar(repo, !cur)
            starred = !cur
        } catch let e {
            error = e.localizedDescription
        }
    }
}
