import SwiftUI
import UIKit
import PDFKit

// MARK: - Danh sách hàm / lớp / mục (ký hiệu) của file

struct CodeSymbol: Identifiable {
    let id: Int
    let name: String
    let kind: String
    let line: Int
    let location: Int   // vị trí (UTF-16) để nhảy tới
    let level: Int
}

enum SymbolScanner {
    private struct Hit {
        let loc: Int
        let name: String
        let kind: String
        let level: Int
    }

    private static let clike = #"^[ \t]*(?:(?:export|default|public|private|protected|internal|open|final|static|abstract|async|override|mutating|pub|inline|suspend|data|sealed|fileprivate)[ \t]+)*(class|struct|enum|protocol|extension|actor|interface|trait|impl|func|function|fun|fn|def|type)[ \t]+([A-Za-z_$][\w$]*)"#
    private static let arrow = #"^[ \t]*(?:export[ \t]+)?(?:const|let|var)[ \t]+([A-Za-z_$][\w$]*)[ \t]*=[ \t]*(?:async[ \t]*)?(?:\([^)\n]*\)|[A-Za-z_$][\w$]*)[ \t]*=>"#
    private static let python = #"^[ \t]*(?:async[ \t]+)?(def|class)[ \t]+(\w+)"#
    private static let heading = #"^(#{1,6})[ \t]+(.+?)[ \t]*$"#
    private static let yamlKey = #"^([A-Za-z_][\w.\-]*)[ \t]*:"#
    private static let shellFunc = #"^[ \t]*(?:function[ \t]+)?([A-Za-z_][\w\-]*)[ \t]*\(\)"#

    private static func leadingSpaces(_ ns: NSString, _ loc: Int) -> Int {
        var n = 0
        var i = loc
        while i < ns.length {
            let c = ns.character(at: i)
            if c == 32 { n += 1 } else if c == 9 { n += 4 } else { break }
            i += 1
        }
        return n
    }

    private static func collect(_ pattern: String,
                                in ns: NSString,
                                kindGroup: Int?,
                                nameGroup: Int,
                                fixedKind: String?,
                                level: (NSTextCheckingResult) -> Int) -> [Hit] {
        guard let re = try? NSRegularExpression(pattern: pattern, options: [.anchorsMatchLines]) else { return [] }
        var out: [Hit] = []
        let full = NSRange(location: 0, length: ns.length)
        re.enumerateMatches(in: ns as String, options: [], range: full) { m, _, _ in
            guard let m = m else { return }
            let nameRange = m.range(at: nameGroup)
            guard nameRange.location != NSNotFound else { return }
            var kind = fixedKind ?? "•"
            if let g = kindGroup {
                let r = m.range(at: g)
                if r.location != NSNotFound { kind = ns.substring(with: r) }
            }
            out.append(Hit(loc: m.range.location,
                           name: ns.substring(with: nameRange),
                           kind: kind,
                           level: level(m)))
        }
        return out
    }

    static func scan(_ text: String, kind: CodeLang.Kind) -> [CodeSymbol] {
        let ns = text as NSString
        guard ns.length > 0, ns.length < 400_000 else { return [] }

        var hits: [Hit] = []
        switch kind {
        case .clike:
            hits += collect(clike, in: ns, kindGroup: 1, nameGroup: 2, fixedKind: nil) {
                min(3, leadingSpaces(ns, $0.range.location) / 4)
            }
            hits += collect(arrow, in: ns, kindGroup: nil, nameGroup: 1, fixedKind: "func") {
                min(3, leadingSpaces(ns, $0.range.location) / 4)
            }
        case .python:
            hits += collect(python, in: ns, kindGroup: 1, nameGroup: 2, fixedKind: nil) {
                min(3, leadingSpaces(ns, $0.range.location) / 4)
            }
        case .markdown:
            hits += collect(heading, in: ns, kindGroup: nil, nameGroup: 2, fixedKind: "#") {
                max(0, $0.range(at: 1).length - 1)
            }
        case .yaml:
            hits += collect(yamlKey, in: ns, kindGroup: nil, nameGroup: 1, fixedKind: "key") { _ in 0 }
        case .hash:
            hits += collect(shellFunc, in: ns, kindGroup: nil, nameGroup: 1, fixedKind: "func") { _ in 0 }
        case .json, .markup, .plain:
            return []
        }
        hits.sort { $0.loc < $1.loc }

        var result: [CodeSymbol] = []
        var line = 1
        var last = 0
        for (i, h) in hits.enumerated() {
            if h.loc > last {
                let seg = ns.substring(with: NSRange(location: last, length: h.loc - last))
                line += seg.utf16.reduce(0) { $1 == 10 ? $0 + 1 : $0 }
                last = h.loc
            }
            result.append(CodeSymbol(id: i, name: h.name, kind: h.kind, line: line,
                                     location: h.loc, level: h.level))
        }
        return result
    }
}

struct SymbolListView: View {
    let symbols: [CodeSymbol]
    let onPick: (CodeSymbol) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var query = ""

    private var filtered: [CodeSymbol] {
        query.isEmpty ? symbols : symbols.filter { $0.name.localizedCaseInsensitiveContains(query) }
    }

    var body: some View {
        NavigationStack {
            List(filtered) { s in
                Button {
                    onPick(s)
                    dismiss()
                } label: {
                    HStack(spacing: 8) {
                        Text(s.kind)
                            .font(.caption2.monospaced())
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Capsule().fill(Theme.accent.opacity(0.12)))
                        Text(s.name)
                            .lineLimit(1)
                            .padding(.leading, CGFloat(min(s.level, 6)) * 12)
                        Spacer()
                        Text("\(s.line)").font(.caption).foregroundStyle(.secondary)
                    }
                }
                .foregroundStyle(.primary)
            }
            .searchable(text: $query)
            .overlay {
                if symbols.isEmpty {
                    Text("Không tìm thấy hàm, lớp hay mục nào trong file này.")
                        .foregroundStyle(.secondary)
                        .padding()
                }
            }
            .navigationTitle("Ký hiệu")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Đóng") { dismiss() }
                }
            }
        }
    }
}

// MARK: - Xem gấp code (chỉ đọc)

final class FoldModel: ObservableObject {
    @Published private(set) var visible: [Int] = []
    @Published private(set) var folded = Set<Int>()

    private(set) var lines: [String] = []
    private(set) var regions: [Int: Int] = [:]   // dòng bắt đầu -> dòng cuối bị ẩn khi gấp
    private var lineStarts: [Int] = []
    private var attr = NSAttributedString()

    private static let maxLines = 20_000

    func build(text: String, lang: CodeLang) {
        var ls = text.components(separatedBy: "\n")
        if ls.count > FoldModel.maxLines { ls = Array(ls.prefix(FoldModel.maxLines)) }
        lines = ls
        var starts: [Int] = []
        var pos = 0
        for l in ls {
            starts.append(pos)
            pos += l.utf16.count + 1
        }
        lineStarts = starts

        let storage = NSTextStorage(string: text)
        Highlighter.apply(to: storage, lang: lang,
                          font: UIFont.monospacedSystemFont(ofSize: 13, weight: .regular))
        attr = NSAttributedString(attributedString: storage)

        regions = FoldModel.computeRegions(lines: ls, kind: lang.kind)
        folded = folded.filter { regions[$0] != nil }
        recompute()
    }

    func toggle(_ i: Int) {
        guard regions[i] != nil else { return }
        if folded.contains(i) { folded.remove(i) } else { folded.insert(i) }
        recompute()
    }

    func foldAll() {
        folded = Set(regions.keys)
        recompute()
    }

    func unfoldAll() {
        folded = []
        recompute()
    }

    private func recompute() {
        var out: [Int] = []
        out.reserveCapacity(lines.count)
        var i = 0
        while i < lines.count {
            out.append(i)
            if folded.contains(i), let end = regions[i], end > i {
                i = end + 1
            } else {
                i += 1
            }
        }
        visible = out
    }

    /// Dòng đã tô màu (ghép từ các đoạn cùng màu)
    func text(for i: Int) -> Text {
        guard i < lineStarts.count else { return Text(" ") }
        let ns = attr.string as NSString
        let start = lineStarts[i]
        let len = min(lines[i].utf16.count, max(0, ns.length - start))
        if len <= 0 { return Text(" ") }
        var acc = Text("")
        attr.enumerateAttribute(.foregroundColor, in: NSRange(location: start, length: len), options: []) { value, r, _ in
            let seg = ns.substring(with: r).replacingOccurrences(of: "\r", with: "")
            let color = (value as? UIColor) ?? UIColor.label
            acc = acc + Text(seg).foregroundColor(Color(uiColor: color))
        }
        return acc
    }

    // MARK: Tính vùng gấp

    private static func indent(_ s: String) -> Int? {
        var n = 0
        for ch in s {
            if ch == " " { n += 1 } else if ch == "\t" { n += 4 } else if ch == "\r" { continue } else { return n }
        }
        return nil   // dòng trống
    }

    static func computeRegions(lines: [String], kind: CodeLang.Kind) -> [Int: Int] {
        var out: [Int: Int] = [:]
        switch kind {
        case .clike, .json:
            var stack: [Int] = []
            for (i, raw) in lines.enumerated() {
                let chars = Array(raw)
                var inStr: Character? = nil
                var j = 0
                while j < chars.count {
                    let c = chars[j]
                    if let q = inStr {
                        if c == "\\" { j += 2; continue }
                        if c == q { inStr = nil }
                    } else if c == "\"" || c == "'" || c == "`" {
                        inStr = c
                    } else if c == "/" && j + 1 < chars.count && chars[j + 1] == "/" {
                        break
                    } else if c == "{" || c == "[" || c == "(" {
                        stack.append(i)
                    } else if c == "}" || c == "]" || c == ")" {
                        if let s = stack.popLast(), i - 1 >= s + 1 {
                            out[s] = max(out[s] ?? 0, i - 1)
                        }
                    }
                    j += 1
                }
            }
        case .markdown:
            var heads: [(line: Int, level: Int)] = []
            var inFence = false
            for (i, l) in lines.enumerated() {
                if l.hasPrefix("```") || l.hasPrefix("~~~") { inFence.toggle(); continue }
                if inFence { continue }
                let hashes = l.prefix(while: { $0 == "#" }).count
                if hashes >= 1 && hashes <= 6 && l.dropFirst(hashes).first == " " {
                    heads.append((i, hashes))
                }
            }
            for (k, h) in heads.enumerated() {
                var end = lines.count - 1
                for n in heads[(k + 1)...] where n.level <= h.level {
                    end = n.line - 1
                    break
                }
                while end > h.line, indent(lines[end]) == nil { end -= 1 }
                if end > h.line { out[h.line] = end }
            }
        case .python, .yaml, .hash, .markup, .plain:
            if kind == .plain { return out }
            let ind = lines.map { indent($0) }
            for i in 0..<lines.count {
                guard let a = ind[i] else { continue }
                var last = i
                var j = i + 1
                while j < lines.count {
                    if let b = ind[j] {
                        if b > a { last = j } else { break }
                    }
                    j += 1
                }
                if last > i { out[i] = last }
            }
        }
        return out
    }
}

struct FoldCodeView: View {
    let text: String
    let lang: CodeLang
    let fontSize: CGFloat

    @StateObject private var model = FoldModel()

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Button("Gấp hết") { model.foldAll() }
                Button("Mở hết") { model.unfoldAll() }
                Spacer()
                Text("Chế độ xem, chưa sửa được")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            .font(.caption.weight(.semibold))
            .padding(.horizontal)
            .padding(.vertical, 6)
            .background(.bar)

            ScrollView([.vertical, .horizontal]) {
                LazyVStack(alignment: .leading, spacing: 0) {
                    ForEach(model.visible, id: \.self) { i in
                        HStack(alignment: .top, spacing: 6) {
                            Text("\(i + 1)")
                                .font(.system(size: max(9, fontSize - 3), design: .monospaced))
                                .foregroundStyle(.secondary)
                                .frame(width: 40, alignment: .trailing)
                            if model.regions[i] != nil {
                                Button {
                                    model.toggle(i)
                                } label: {
                                    Image(systemName: model.folded.contains(i) ? "chevron.right" : "chevron.down")
                                        .font(.system(size: 10, weight: .bold))
                                        .frame(width: 18, height: 18)
                                }
                                .buttonStyle(.plain)
                                .foregroundStyle(Theme.accent)
                            } else {
                                Color.clear.frame(width: 18, height: 18)
                            }
                            HStack(spacing: 4) {
                                model.text(for: i)
                                    .font(.system(size: fontSize, design: .monospaced))
                                    .fixedSize(horizontal: true, vertical: false)
                                if model.folded.contains(i), let end = model.regions[i] {
                                    Text("… \(end - i) dòng")
                                        .font(.system(size: max(9, fontSize - 3)))
                                        .foregroundStyle(.secondary)
                                        .padding(.horizontal, 6)
                                        .background(Capsule().fill(Color.secondary.opacity(0.15)))
                                }
                            }
                        }
                        .padding(.vertical, 1)
                    }
                }
                .padding(8)
            }
        }
        .task(id: text.hashValue) {
            model.build(text: text, lang: lang)
        }
    }
}

// MARK: - Xem bảng CSV / TSV

enum CSV {
    static func parse(_ text: String, delimiter: Character, maxRows: Int) -> (rows: [[String]], truncated: Bool) {
        let chars = Array(text)
        let n = chars.count
        var rows: [[String]] = []
        var row: [String] = []
        var field = ""
        var inQuotes = false
        var i = 0
        while i < n {
            let c = chars[i]
            if inQuotes {
                if c == "\"" {
                    if i + 1 < n && chars[i + 1] == "\"" {
                        field.append("\"")
                        i += 1
                    } else {
                        inQuotes = false
                    }
                } else {
                    field.append(c)
                }
            } else if c == "\"" && field.isEmpty {
                inQuotes = true
            } else if c == delimiter {
                row.append(field)
                field = ""
            } else if c == "\n" || c == "\r\n" || c == "\r" {
                row.append(field)
                field = ""
                rows.append(row)
                row = []
                if rows.count >= maxRows { return (rows, true) }
            } else {
                field.append(c)
            }
            i += 1
        }
        if !field.isEmpty || !row.isEmpty {
            row.append(field)
            rows.append(row)
        }
        return (rows, false)
    }
}

struct CSVTableView: View {
    private let rows: [[String]]
    private let truncated: Bool
    private let widths: [CGFloat]

    init(text: String, delimiter: Character) {
        let r = CSV.parse(text, delimiter: delimiter, maxRows: 2000)
        rows = r.rows
        truncated = r.truncated
        let sample = r.rows.prefix(200)
        let cols = min(60, sample.map { $0.count }.max() ?? 0)
        var w: [CGFloat] = []
        for c in 0..<cols {
            let longest = sample.map { c < $0.count ? min($0[c].count, 40) : 0 }.max() ?? 0
            w.append(CGFloat(max(4, longest)) * 8 + 16)
        }
        widths = w
    }

    var body: some View {
        if rows.isEmpty {
            Text("File trống.").foregroundStyle(.secondary).padding()
        } else {
            ScrollView([.vertical, .horizontal]) {
                LazyVStack(alignment: .leading, spacing: 0) {
                    ForEach(Array(rows.enumerated()), id: \.offset) { pair in
                        HStack(spacing: 0) {
                            Text("\(pair.offset + 1)")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                                .frame(width: 36, alignment: .trailing)
                                .padding(.trailing, 6)
                            ForEach(0..<widths.count, id: \.self) { c in
                                Text(c < pair.element.count ? pair.element[c] : "")
                                    .font(.system(size: 12, design: .monospaced))
                                    .fontWeight(pair.offset == 0 ? .bold : .regular)
                                    .lineLimit(1)
                                    .frame(width: widths[c], alignment: .leading)
                                    .padding(.horizontal, 4)
                            }
                        }
                        .padding(.vertical, 4)
                        .background(pair.offset == 0
                                    ? Theme.accent.opacity(0.12)
                                    : (pair.offset % 2 == 0 ? Color.primary.opacity(0.04) : Color.clear))
                    }
                    if truncated {
                        Text("Chỉ hiện \(rows.count) dòng đầu.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .padding(8)
                    }
                }
                .padding(8)
            }
        }
    }
}

// MARK: - Xem PDF

struct PDFPreview: UIViewRepresentable {
    let data: Data

    func makeUIView(context: Context) -> PDFView {
        let v = PDFView()
        v.autoScales = true
        v.document = PDFDocument(data: data)
        return v
    }

    func updateUIView(_ v: PDFView, context: Context) {}
}
