import SwiftUI
import UIKit

// MARK: - Biểu tượng trạng thái

struct StatusIcon: View {
    let status: String?
    let conclusion: String?

    private var info: (String, Color) {
        if status == "completed" {
            switch conclusion ?? "" {
            case "success": return ("checkmark.circle.fill", .green)
            case "failure", "timed_out", "startup_failure": return ("xmark.circle.fill", .red)
            case "cancelled": return ("slash.circle.fill", .gray)
            case "skipped": return ("arrow.right.circle", .gray)
            default: return ("exclamationmark.circle.fill", .orange)
            }
        }
        if status == "in_progress" {
            return ("arrow.triangle.2.circlepath.circle.fill", .orange)
        }
        return ("clock.fill", .gray)
    }

    var body: some View {
        Image(systemName: info.0)
            .foregroundStyle(info.1)
            .modifier(PulseModifier(active: status == "in_progress"))
    }
}

func statusText(_ status: String?, _ conclusion: String?) -> String {
    if status == "completed" {
        switch conclusion ?? "" {
        case "success": return "Thành công"
        case "failure": return "Thất bại"
        case "cancelled": return "Đã hủy"
        case "skipped": return "Bỏ qua"
        case "timed_out": return "Quá thời gian"
        default: return conclusion ?? "Hoàn tất"
        }
    }
    if status == "in_progress" { return "Đang chạy" }
    if status == "queued" { return "Đang chờ" }
    return status ?? "-"
}

// MARK: - Dọn dẹp lần chạy

enum CleanKind: String, CaseIterable, Identifiable {
    case success, failed, cancelled, allDone
    var id: String { rawValue }

    var title: String {
        switch self {
        case .success: return "Xóa các lần chạy thành công"
        case .failed: return "Xóa các lần chạy bị lỗi"
        case .cancelled: return "Xóa các lần chạy đã hủy / bỏ qua"
        case .allDone: return "Xóa tất cả lần chạy đã xong"
        }
    }
    var icon: String {
        switch self {
        case .success: return "checkmark.circle"
        case .failed: return "xmark.circle"
        case .cancelled: return "slash.circle"
        case .allDone: return "trash"
        }
    }
    func matches(_ r: WorkflowRun) -> Bool {
        guard r.status == "completed" else { return false }
        let c = r.conclusion ?? ""
        switch self {
        case .success: return c == "success"
        case .failed: return ["failure", "timed_out", "startup_failure", "action_required"].contains(c)
        case .cancelled: return ["cancelled", "skipped", "neutral", "stale"].contains(c)
        case .allDone: return true
        }
    }
}

struct CleanPlan: Identifiable {
    let id = UUID()
    let kind: CleanKind
    let targets: [WorkflowRun]
}

// MARK: - Danh sách lần chạy

struct ActionsView: View {
    let repo: Repo
    let branch: String

    @EnvironmentObject var session: Session
    @State private var runs: [WorkflowRun] = []
    @State private var workflows: [Workflow] = []
    @State private var onlyBranch = false
    @State private var loading = false
    @State private var loadingMore = false
    @State private var page = 1
    @State private var hasMore = false
    @State private var error: String?
    @State private var toast: String?
    @State private var pickWorkflow = false
    @State private var pending: PendingDispatch?
    @State private var cleaning = false
    @State private var cleanStatus = ""
    @State private var plan: CleanPlan?

    private let pageSize = 30

    var body: some View {
        List {
            Toggle("Chỉ nhánh \(branch)", isOn: $onlyBranch)
                .cardRow(vertical: 8)

            Button {
                Task { await prepareDispatch() }
            } label: {
                Label("Chạy workflow trên \(branch)", systemImage: "play.fill")
                    .font(.subheadline.weight(.semibold))
            }
            .cardRow(vertical: 8)

            Menu {
                ForEach(CleanKind.allCases) { k in
                    Button(role: k == .allDone ? .destructive : nil) {
                        Task { await prepareClean(k) }
                    } label: {
                        Label(k.title, systemImage: k.icon)
                    }
                }
            } label: {
                Label("Dọn dẹp lần chạy", systemImage: "trash")
                    .font(.subheadline.weight(.semibold))
            }
            .disabled(cleaning)
            .cardRow(vertical: 8)

            if cleaning {
                HStack(spacing: 8) {
                    ProgressView()
                    Text(cleanStatus).font(.footnote).foregroundStyle(.secondary)
                }
                .cardRow(vertical: 8)
            }

            if let error = error {
                Text(error).font(.footnote).foregroundStyle(.secondary)
            }

            ForEach(runs) { run in
                NavigationLink {
                    RunDetailView(repo: repo, run: run) { id in
                        runs.removeAll { $0.id == id }
                    }
                } label: {
                    RunRow(run: run)
                }
                .cardRow()
                .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                    if run.status == "completed" {
                        Button(role: .destructive) {
                            Task { await deleteOne(run) }
                        } label: {
                            Label("Xóa", systemImage: "trash")
                        }
                    }
                }
            }

            if hasMore {
                Button {
                    Task { await loadMore() }
                } label: {
                    HStack {
                        Spacer()
                        if loadingMore { ProgressView() } else { Text("Tải thêm") }
                        Spacer()
                    }
                }
            }
        }
        .listStyle(.plain)
        .themedList()
        .overlay {
            if loading && runs.isEmpty {
                ProgressView()
            }
        }
        .refreshable { await load() }
        .task(id: "\(branch)|\(onlyBranch)") { await load() }
        .task { await autoRefresh() }
        .onAppear {
            if !runs.isEmpty { Task { await load(silent: true) } }
        }
        .confirmationDialog("Chọn workflow để chạy", isPresented: $pickWorkflow, titleVisibility: .visible) {
            ForEach(workflows) { w in
                Button(w.name) { Task { await choose(w) } }
            }
        } message: {
            Text("Workflow cần có trigger workflow_dispatch.")
        }
        .confirmationDialog(
            "Xóa lần chạy?",
            isPresented: Binding(get: { plan != nil }, set: { if !$0 { plan = nil } }),
            titleVisibility: .visible,
            presenting: plan
        ) { p in
            Button("Xóa \(p.targets.count) lần chạy", role: .destructive) {
                Task { await runClean(p) }
            }
            Button("Hủy", role: .cancel) {}
        } message: { p in
            Text("\(p.kind.title.replacingOccurrences(of: "Xóa ", with: "")): \(p.targets.count) lần chạy\(onlyBranch ? " (nhánh \(branch))" : ""). Không thể hoàn tác, artifact và log đi kèm cũng bị xóa.")
        }
        .sheet(item: $pending) { p in
            DispatchSheet(workflow: p.workflow, branch: branch, inputs: p.inputs) { values in
                Task { await dispatch(p.workflow, inputs: values) }
            }
        }
        .alert("Thông báo", isPresented: Binding(
            get: { toast != nil },
            set: { if !$0 { toast = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(toast ?? "")
        }
    }

    private func load(silent: Bool = false) async {
        if !silent { loading = true }
        defer { loading = false }
        do {
            let first = try await session.api.runs(repo, branch: onlyBranch ? branch : nil, page: 1)
            if silent && !runs.isEmpty {
                // Làm mới ngầm: cập nhật trang đầu, giữ nguyên các trang đã tải thêm
                let minId = first.map { $0.id }.min() ?? Int.max
                runs = first + runs.filter { $0.id < minId }
            } else {
                runs = first
                page = 1
                hasMore = first.count >= pageSize
            }
            error = nil
        } catch let e {
            error = e.localizedDescription
        }
    }

    /// Tải hết các lần chạy (tối đa 20 trang = 600 lần) rồi lọc theo loại cần xóa
    private func prepareClean(_ kind: CleanKind) async {
        cleaning = true
        cleanStatus = "Đang tìm các lần chạy..."
        defer { cleaning = false }
        do {
            var all: [WorkflowRun] = []
            var pg = 1
            while pg <= 20 {
                let part = try await session.api.runs(repo, branch: onlyBranch ? branch : nil, page: pg)
                all += part
                cleanStatus = "Đang tìm... (\(all.count) lần chạy)"
                if part.count < pageSize { break }
                pg += 1
            }
            let targets = all.filter { kind.matches($0) }
            if targets.isEmpty {
                toast = "Không có lần chạy nào thuộc loại này."
            } else {
                plan = CleanPlan(kind: kind, targets: targets)
            }
        } catch let e {
            toast = e.localizedDescription
        }
    }

    private func runClean(_ p: CleanPlan) async {
        cleaning = true
        defer { cleaning = false }
        var ok = 0
        var fail = 0
        var lastErr: String?
        let api = session.api
        let repo = self.repo
        var i = 0
        while i < p.targets.count {
            let batch = Array(p.targets[i..<min(i + 3, p.targets.count)])
            i += batch.count
            await withTaskGroup(of: (Int, String?).self) { group in
                for r in batch {
                    group.addTask {
                        do {
                            try await api.deleteRun(repo, runId: r.id)
                            return (r.id, nil)
                        } catch let e {
                            return (r.id, e.localizedDescription)
                        }
                    }
                }
                for await (id, err) in group {
                    if let err = err {
                        fail += 1
                        lastErr = err
                    } else {
                        ok += 1
                        runs.removeAll { $0.id == id }
                    }
                }
            }
            cleanStatus = "Đang xóa... \(ok + fail)/\(p.targets.count)"
            if fail >= 5 && ok == 0 { break }
        }
        var msg = "Đã xóa \(ok) lần chạy."
        if fail > 0 { msg += " Không xóa được \(fail): \(lastErr ?? "")" }
        toast = msg
        await load(silent: true)
    }

    private func deleteOne(_ run: WorkflowRun) async {
        do {
            try await session.api.deleteRun(repo, runId: run.id)
            runs.removeAll { $0.id == run.id }
        } catch let e {
            toast = e.localizedDescription
        }
    }

    private func loadMore() async {
        if loadingMore { return }
        loadingMore = true
        defer { loadingMore = false }
        do {
            let next = try await session.api.runs(repo, branch: onlyBranch ? branch : nil, page: page + 1)
            let have = Set(runs.map { $0.id })
            runs += next.filter { !have.contains($0.id) }
            page += 1
            hasMore = next.count >= pageSize
        } catch let e {
            error = e.localizedDescription
        }
    }

    private func autoRefresh() async {
        while !Task.isCancelled {
            try? await Task.sleep(nanoseconds: 8_000_000_000)
            if Task.isCancelled { break }
            if runs.contains(where: { $0.status != "completed" }) {
                await load(silent: true)
            }
        }
    }

    private func prepareDispatch() async {
        do {
            workflows = try await session.api.workflows(repo)
            if workflows.isEmpty {
                toast = "Repo chưa có workflow nào đang bật."
            } else {
                pickWorkflow = true
            }
        } catch let e {
            toast = e.localizedDescription
        }
    }

    /// Đọc file workflow để biết có inputs không: có thì hiện form, không thì chạy luôn
    private func choose(_ w: Workflow) async {
        var inputs: [WorkflowInput] = []
        if let f = try? await session.api.file(repo, path: w.path, ref: branch),
           let yaml = String(data: f.data, encoding: .utf8) {
            inputs = WorkflowYAML.dispatchInputs(yaml) ?? []
        }
        if inputs.isEmpty {
            await dispatch(w, inputs: [:])
        } else {
            pending = PendingDispatch(workflow: w, inputs: inputs)
        }
    }

    private func dispatch(_ w: Workflow, inputs: [String: String]) async {
        do {
            try await session.api.dispatch(repo, workflowId: w.id, ref: branch, inputs: inputs)
            toast = "Đã gửi lệnh chạy \(w.name) trên \(branch)."
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            await load(silent: true)
        } catch let e {
            toast = e.localizedDescription
        }
    }
}

struct RunRow: View {
    let run: WorkflowRun

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(run.title)
                .font(.subheadline.weight(.semibold))
                .lineLimit(2)
            HStack(spacing: 6) {
                StatusPill(status: run.status, conclusion: run.conclusion)
                Text("#\(run.runNumber) · \(run.headBranch ?? "-") · \(relative(run.createdAt))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
        }
        .padding(.vertical, 2)
    }
}

// MARK: - Chi tiết một lần chạy

struct RunDetailView: View {
    let repo: Repo
    let run: WorkflowRun
    /// Gọi khi đã xóa lần chạy này, để danh sách bên ngoài cập nhật
    var onDeleted: (Int) -> Void = { _ in }

    @Environment(\.dismiss) private var dismiss
    @State private var confirmDelete = false

    @EnvironmentObject var session: Session
    @State private var current: WorkflowRun?
    @State private var jobs: [Job] = []
    @State private var artifacts: [Artifact] = []
    @State private var loading = true
    @State private var error: String?
    @State private var toast: String?
    @State private var shared: SharedFile?
    @State private var downloading: Int?
    @State private var showReplay = false
    @State private var logJob: Job?
    @State private var showLog = false

    private var shownRun: WorkflowRun { current ?? run }

    var body: some View {
        List {
            Section {
                RunHero(run: shownRun, jobs: jobs)
                    .listRowInsets(EdgeInsets(top: 8, leading: 0, bottom: 8, trailing: 0))
                    .listRowBackground(Color.clear)
                    .listRowSeparator(.hidden)
            }

            if shownRun.status != "completed" && !jobs.isEmpty {
                Section {
                    LiveLogPanel(repo: repo, runId: run.id, jobs: jobs) { j in
                        logJob = j
                        showLog = true
                    }
                    .listRowInsets(EdgeInsets(top: 4, leading: 0, bottom: 8, trailing: 0))
                    .listRowBackground(Color.clear)
                    .listRowSeparator(.hidden)
                }
            }

            if let error = error {
                Section { Text(error).font(.footnote).foregroundStyle(.secondary) }
            }

            Section("Jobs") {
                if jobs.isEmpty && !loading {
                    Text("Chưa có job nào.").foregroundStyle(.secondary)
                }
                ForEach(jobs) { job in
                    NavigationLink {
                        LogView(repo: repo, job: job)
                    } label: {
                        JobRow(job: job)
                    }
                }
            }

            ForEach(jobs) { job in
                if let steps = job.steps, !steps.isEmpty,
                   job.status != "completed" || job.conclusion != "success" {
                    Section("Các bước · \(job.name)") {
                        let ordered = steps.sorted { $0.number < $1.number }
                        ForEach(ordered, id: \.number) { st in
                            StepTimelineRow(step: st, isLast: st.number == ordered.last?.number)
                                .listRowBackground(Theme.track)
                        }
                    }
                }
            }

            if !artifacts.isEmpty {
                Section("Artifacts") {
                    ForEach(artifacts) { a in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(a.name).font(.subheadline)
                                Text(a.expired ? "Đã hết hạn" : sizeText(a.sizeInBytes))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            if downloading == a.id {
                                ProgressView()
                            } else if !a.expired {
                                Button {
                                    Task { await download(a) }
                                } label: {
                                    Image(systemName: "arrow.down.circle")
                                }
                                .buttonStyle(.borderless)
                            }
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                            Button(role: .destructive) {
                                Task { await deleteArtifact(a) }
                            } label: {
                                Label("Xóa", systemImage: "trash")
                            }
                        }
                    }
                }
            }
        }
        .overlay {
            if loading && jobs.isEmpty { ProgressView() }
        }
        .themedList()
        .navigationTitle("Run #\(run.runNumber)")
        .navigationBarTitleDisplayMode(.inline)
        .refreshable { await load() }
        .task { await poll() }
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if shownRun.status == "completed" && !jobs.isEmpty {
                    Button {
                        Haptics.tap()
                        showReplay = true
                    } label: {
                        Image(systemName: "play.circle")
                    }
                }
            }
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    Button {
                        Task { await act("Đã yêu cầu chạy lại.") { try await session.api.rerun(repo, runId: run.id) } }
                    } label: {
                        Label("Chạy lại tất cả", systemImage: "arrow.clockwise")
                    }
                    Button {
                        Task { await act("Đã yêu cầu chạy lại job lỗi.") { try await session.api.rerunFailed(repo, runId: run.id) } }
                    } label: {
                        Label("Chạy lại job lỗi", systemImage: "arrow.clockwise.circle")
                    }
                    Button(role: .destructive) {
                        Task { await act("Đã yêu cầu hủy.") { try await session.api.cancel(repo, runId: run.id) } }
                    } label: {
                        Label("Hủy lần chạy", systemImage: "stop.circle")
                    }
                    if shownRun.status == "completed" {
                        Button(role: .destructive) {
                            confirmDelete = true
                        } label: {
                            Label("Xóa lần chạy này", systemImage: "trash")
                        }
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
        .confirmationDialog("Xóa lần chạy #\(run.runNumber)?", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("Xóa", role: .destructive) {
                Task { await deleteThisRun() }
            }
            Button("Hủy", role: .cancel) {}
        } message: {
            Text("Log và artifact của lần chạy này cũng bị xóa. Không thể hoàn tác.")
        }
        .sheet(item: $shared) { f in
            ShareSheet(items: [f.url])
        }
        .navigationDestination(isPresented: $showLog) {
            if let j = logJob { LogView(repo: repo, job: j) }
        }
        .sheet(isPresented: $showReplay) {
            NavigationStack {
                BuildReplayView(repo: repo, run: shownRun, jobs: jobs)
            }
        }
        .alert("Thông báo", isPresented: Binding(
            get: { toast != nil },
            set: { if !$0 { toast = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(toast ?? "")
        }
    }

    private func poll() async {
        await load()
        while !Task.isCancelled {
            try? await Task.sleep(nanoseconds: 6_000_000_000)
            if Task.isCancelled { break }
            if shownRun.status != "completed" {
                await load(silent: true)
            }
        }
    }

    private func load(silent: Bool = false) async {
        if !silent { loading = true }
        defer { loading = false }
        do {
            let prev = current?.status ?? run.status
            let r = try await session.api.run(repo, run.id)
            let j = try await session.api.jobs(repo, runId: run.id)
            let a = try await session.api.artifacts(repo, runId: run.id)
            withAnimation(.spring(response: 0.45, dampingFraction: 0.85)) {
                current = r
                jobs = j
                artifacts = a
            }
            if prev != "completed" && r.status == "completed" {
                if r.conclusion == "success" { Haptics.success() } else { Haptics.error() }
            }
            error = nil
        } catch let e {
            error = e.localizedDescription
        }
    }

    private func act(_ okText: String, _ op: @escaping () async throws -> Void) async {
        do {
            try await op()
            toast = okText
            try? await Task.sleep(nanoseconds: 2_000_000_000)
            await load(silent: true)
        } catch let e {
            toast = e.localizedDescription
        }
    }

    private func deleteThisRun() async {
        do {
            try await session.api.deleteRun(repo, runId: run.id)
            onDeleted(run.id)
            dismiss()
        } catch let e {
            toast = e.localizedDescription
        }
    }

    private func deleteArtifact(_ a: Artifact) async {
        do {
            try await session.api.deleteArtifact(repo, id: a.id)
            artifacts.removeAll { $0.id == a.id }
        } catch let e {
            toast = e.localizedDescription
        }
    }

    private func download(_ a: Artifact) async {
        downloading = a.id
        defer { downloading = nil }
        do {
            let url = try await session.api.downloadArtifact(repo, a)
            shared = SharedFile(url: url)
        } catch let e {
            toast = e.localizedDescription
        }
    }
}

struct JobRow: View {
    let job: Job

    private var steps: [Step] { (job.steps ?? []).sorted { $0.number < $1.number } }
    private var doneCount: Int { steps.filter { $0.status == "completed" }.count }
    private var currentStep: Step? { steps.first { $0.status == "in_progress" } }

    private var failedStep: String? {
        job.steps?.first(where: { $0.conclusion == "failure" })?.name
    }

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            StatusIcon(status: job.status, conclusion: job.conclusion)
                .padding(.top, 2)
            VStack(alignment: .leading, spacing: 2) {
                Text(job.name).font(.subheadline.weight(.medium))
                if job.status == "in_progress", let st = job.startedAt {
                    HStack(spacing: 4) {
                        Text("\(statusText(job.status, job.conclusion)) ·")
                        Text(st, style: .timer).monospacedDigit()
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)
                } else {
                    let dur = durationText(job.startedAt, job.completedAt)
                    Text([statusText(job.status, job.conclusion), dur]
                            .filter { !$0.isEmpty }
                            .joined(separator: " · "))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                if job.status == "in_progress", !steps.isEmpty {
                    ProgressView(value: Double(doneCount), total: Double(steps.count))
                        .tint(.orange)
                    Text("Bước \(min(doneCount + 1, steps.count))/\(steps.count)" + (currentStep.map { ": \($0.name)" } ?? ""))
                        .font(.caption)
                        .foregroundStyle(.orange)
                        .lineLimit(2)
                }
                if let f = failedStep {
                    Text("Lỗi ở bước: \(f)")
                        .font(.caption)
                        .foregroundStyle(.red)
                }
            }
        }
    }
}

struct StepRow: View {
    let step: Step

    var body: some View {
        HStack(spacing: 10) {
            StatusIcon(status: step.status, conclusion: step.conclusion)
            Text(step.name)
                .font(.footnote)
                .lineLimit(2)
            Spacer()
            if step.status == "in_progress", let st = step.startedAt {
                Text(st, style: .timer)
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.orange)
            } else {
                let d = durationText(step.startedAt, step.completedAt)
                if !d.isEmpty {
                    Text(d).font(.caption).foregroundStyle(.secondary)
                }
            }
        }
    }
}

// MARK: - Log của job

struct LogView: View {
    let repo: Repo
    let job: Job

    @EnvironmentObject var session: Session
    @State private var lines: [String] = []
    @State private var loading = true
    @State private var error: String?
    @State private var onlyErrors = false
    @State private var copied: String?
    @State private var live = false
    @State private var fullFile: URL?
    @State private var errFile: URL?

    private var shown: [String] {
        if onlyErrors { return lines.filter { isErrorLine($0) } }
        return lines.count > 3000 ? Array(lines.suffix(3000)) : lines
    }

    var body: some View {
        Group {
            if loading {
                ProgressView()
            } else if let error = error {
                Text(error).foregroundStyle(.secondary).padding()
            } else if shown.isEmpty {
                Text(onlyErrors ? "Không thấy dòng lỗi nào." : "Log trống.")
                    .foregroundStyle(.secondary)
                    .padding()
            } else {
                ScrollViewReader { proxy in
                    ScrollView([.vertical, .horizontal]) {
                        VStack(alignment: .leading, spacing: 0) {
                            Text(shown.joined(separator: "\n"))
                                .font(.system(size: 11, design: .monospaced))
                                .textSelection(.enabled)
                                .fixedSize(horizontal: true, vertical: false)
                                .padding(8)
                            Color.clear.frame(width: 1, height: 1).id("end")
                        }
                    }
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                            proxy.scrollTo("end", anchor: .bottom)
                        }
                    }
                    .onChange(of: lines.count) { _ in
                        if live { proxy.scrollTo("end", anchor: .bottom) }
                    }
                    .onChange(of: onlyErrors) { _ in
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                            proxy.scrollTo("end", anchor: .bottom)
                        }
                    }
                }
            }
        }
        .navigationTitle(job.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                Button {
                    onlyErrors.toggle()
                } label: {
                    Image(systemName: onlyErrors ? "exclamationmark.triangle.fill" : "exclamationmark.triangle")
                }
                Menu {
                    Button {
                        copy(shown, label: "phần đang hiện")
                    } label: {
                        Label("Sao chép phần đang hiện", systemImage: "doc.on.doc")
                    }
                    Button {
                        copy(lines, label: "toàn bộ log")
                    } label: {
                        Label("Sao chép toàn bộ log", systemImage: "doc.on.doc.fill")
                    }
                    if let f = fullFile {
                        ShareLink(item: f) {
                            Label("Lưu / chia sẻ toàn bộ log (.txt)", systemImage: "square.and.arrow.up")
                        }
                    }
                    if let e = errFile {
                        ShareLink(item: e) {
                            Label("Lưu / chia sẻ chỉ dòng lỗi (.txt)", systemImage: "exclamationmark.triangle")
                        }
                    }
                    Button {
                        Task { await load() }
                    } label: {
                        Label("Tải lại", systemImage: "arrow.clockwise")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
        .overlay(alignment: .top) {
            if live {
                HStack(spacing: 6) {
                    ProgressView().controlSize(.mini)
                    Text("Đang chạy · tự cập nhật")
                        .font(.caption2)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(.thinMaterial, in: Capsule())
                .padding(.top, 6)
            }
        }
        .overlay(alignment: .bottom) {
            if let c = copied {
                Text(c)
                    .font(.footnote)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(.thinMaterial, in: Capsule())
                    .padding(.bottom, 24)
                    .transition(.opacity)
            }
        }
        .task {
            live = job.status != "completed"
            await load()
            await follow()
        }
    }

    /// Khi job còn đang chạy: cứ vài giây tải lại log và tự cuộn xuống cuối
    private func follow() async {
        while live && !Task.isCancelled {
            try? await Task.sleep(nanoseconds: 4_000_000_000)
            if Task.isCancelled { return }
            let fresh = try? await session.api.job(repo, job.id)
            if fresh?.status == "completed" { live = false }
            await load(silent: true)
        }
    }

    private func copy(_ ls: [String], label: String) {
        UIPasteboard.general.string = ls.joined(separator: "\n")
        withAnimation { copied = "Đã sao chép \(label) (\(ls.count) dòng)" }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
            withAnimation { copied = nil }
        }
    }

    private func isErrorLine(_ l: String) -> Bool {
        let s = l.lowercased()
        return s.contains("error:")
            || s.contains("##[error]")
            || s.contains("fatal")
            || s.contains("** build failed")
            || s.contains(" failed")
    }

    private func load(silent: Bool = false) async {
        if !silent { loading = true }
        defer { if !silent { loading = false } }
        do {
            let raw = try await session.api.log(repo, jobId: job.id)
            let clean = raw
                .replacingOccurrences(of: "\u{FEFF}", with: "")
                .replacingOccurrences(of: "\r", with: "")
                .replacingOccurrences(of: "\u{1B}\\[[0-9;]*[A-Za-z]", with: "", options: .regularExpression)
            lines = clean.split(separator: "\n", omittingEmptySubsequences: false).map { stripTimestamp($0) }
            error = nil
            if !live { makeFiles() }
        } catch let e {
            if !silent || lines.isEmpty {
                if live, let a = e as? APIError, a.statusCode == 404 {
                    error = "Job đang chạy: GitHub chỉ cung cấp log sau khi job kết thúc. Xem tiến trình từng bước ở màn hình lần chạy, hoặc mở log trực tiếp trên web GitHub."
                } else {
                    error = e.localizedDescription
                }
            }
        }
    }

    /// Ghi log ra file tạm .txt để lưu vào Tệp hoặc gửi đi
    private func makeFiles() {
        let safe = job.name
            .components(separatedBy: CharacterSet(charactersIn: "/\\:*?\"<>|")).joined(separator: "-")
            .trimmingCharacters(in: .whitespaces)
        let base = safe.isEmpty ? "job" : safe
        let dir = FileManager.default.temporaryDirectory
        func write(_ ls: [String], _ name: String) -> URL? {
            let url = dir.appendingPathComponent(name)
            do {
                try ls.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8)
                return url
            } catch { return nil }
        }
        fullFile = write(lines, "\(base)-log.txt")
        let errs = lines.filter { isErrorLine($0) }
        errFile = errs.isEmpty ? nil : write(errs, "\(base)-loi.txt")
    }

    // "2026-11-02T08:40:42.1234567Z nội dung" -> "nội dung"
    private func stripTimestamp(_ l: Substring) -> String {
        if l.hasPrefix("20"),
           let sp = l.firstIndex(of: " "),
           l.distance(from: l.startIndex, to: sp) <= 32 {
            let head = l[l.startIndex..<sp]
            if head.hasSuffix("Z") && head.contains("T") {
                return String(l[l.index(after: sp)...])
            }
        }
        return String(l)
    }
}
