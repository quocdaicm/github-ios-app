import Foundation

// MARK: - Mô hình Git Data API

struct GitRefResponse: Decodable {
    struct Obj: Decodable { let sha: String }
    let object: Obj
}

struct GitCommitResponse: Decodable {
    struct Tree: Decodable { let sha: String }
    let sha: String
    let tree: Tree
}

struct GitShaResponse: Decodable { let sha: String }

struct GitTreeEntry: Decodable {
    let path: String
    let mode: String
    let type: String
    let sha: String?
}

struct GitTreeResponse: Decodable {
    let sha: String
    let tree: [GitTreeEntry]
    let truncated: Bool?
}

// MARK: - Thay đổi chờ commit

enum Change: Identifiable {
    case put(path: String, data: Data)
    case delete(path: String, isDir: Bool)
    case move(from: String, to: String, isDir: Bool)

    var id: String {
        switch self {
        case .put(let p, _): return "put:" + p
        case .delete(let p, _): return "del:" + p
        case .move(let f, _, _): return "mv:" + f
        }
    }

    var summary: String {
        switch self {
        case .put(let p, _): return "Thêm/sửa \(p)"
        case .delete(let p, let d): return (d ? "Xóa thư mục " : "Xóa ") + p
        case .move(let f, let t, _): return "Đổi tên \(f) → \(t)"
        }
    }

    var icon: String {
        switch self {
        case .put: return "square.and.pencil"
        case .delete: return "trash"
        case .move: return "arrow.right.doc.on.clipboard"
        }
    }
}

private let gdDecoder: JSONDecoder = {
    let d = JSONDecoder()
    d.keyDecodingStrategy = .convertFromSnakeCase
    return d
}()

private func gdDecode<T: Decodable>(_ type: T.Type, _ data: Data) throws -> T {
    do {
        return try gdDecoder.decode(type, from: data)
    } catch let e {
        throw APIError(message: "Không đọc được dữ liệu từ GitHub: \(e.localizedDescription)")
    }
}

// MARK: - Commit nhiều file một lần

extension GitHubAPI {
    func createBlob(_ repo: Repo, data: Data) async throws -> String {
        let out = try await raw("/repos/\(repo.fullName)/git/blobs",
                                method: "POST",
                                body: ["content": data.base64EncodedString(), "encoding": "base64"])
        return try gdDecode(GitShaResponse.self, out).sha
    }

    /// Áp dụng danh sách thay đổi theo thứ tự và tạo đúng một commit trên nhánh.
    func commitChanges(_ repo: Repo,
                       branch: String,
                       message: String,
                       changes: [Change],
                       progress: @escaping (String) -> Void = { _ in }) async throws {
        let base = "/repos/\(repo.fullName)/git"

        progress("Đọc nhánh \(branch)...")
        let ref: GitRefResponse = try await get("\(base)/ref/heads/\(branch)")
        let headSha = ref.object.sha
        let head: GitCommitResponse = try await get("\(base)/commits/\(headSha)")
        let baseTree = head.tree.sha

        // Xóa/đổi tên cần biết danh sách file hiện có
        let needTree = changes.contains { c in
            if case .put = c { return false }
            return true
        }
        var baseFiles: [String: (sha: String, mode: String)] = [:]
        if needTree {
            progress("Đọc cây thư mục...")
            let t: GitTreeResponse = try await get("\(base)/trees/\(baseTree)", query: ["recursive": "1"])
            if t.truncated == true {
                throw APIError(message: "Repo quá lớn để xóa/đổi tên hàng loạt trên điện thoại.")
            }
            for e in t.tree where e.type == "blob" {
                if let s = e.sha { baseFiles[e.path] = (s, e.mode) }
            }
        }

        var files = baseFiles
        var touched = Set<String>()
        var done = 0
        let total = changes.count

        for c in changes {
            done += 1
            switch c {
            case .put(let path, let data):
                progress("Tải lên \(done)/\(total): \((path as NSString).lastPathComponent)")
                let blob = try await createBlob(repo, data: data)
                files[path] = (blob, baseFiles[path]?.mode ?? "100644")
                touched.insert(path)

            case .delete(let path, let isDir):
                if isDir {
                    let prefix = path + "/"
                    for p in Array(files.keys) where p.hasPrefix(prefix) {
                        files[p] = nil
                        touched.insert(p)
                    }
                } else {
                    files[path] = nil
                    touched.insert(path)
                }

            case .move(let from, let to, let isDir):
                if isDir {
                    let prefix = from + "/"
                    for (p, v) in Array(files) where p.hasPrefix(prefix) {
                        let np = to + "/" + String(p.dropFirst(prefix.count))
                        files[p] = nil
                        files[np] = v
                        touched.insert(p)
                        touched.insert(np)
                    }
                } else if let v = files[from] {
                    files[from] = nil
                    files[to] = v
                    touched.insert(from)
                    touched.insert(to)
                }
            }
        }

        var entries: [[String: Any]] = []
        for p in touched.sorted() {
            if let v = files[p] {
                if let old = baseFiles[p], old.sha == v.sha, old.mode == v.mode { continue }
                entries.append(["path": p, "mode": v.mode, "type": "blob", "sha": v.sha])
            } else if let old = baseFiles[p] {
                entries.append(["path": p, "mode": old.mode, "type": "blob", "sha": NSNull()])
            }
        }
        if entries.isEmpty {
            throw APIError(message: "Không có thay đổi nào để commit.")
        }

        progress("Tạo commit...")
        let treeOut = try await raw("\(base)/trees", method: "POST",
                                    body: ["base_tree": baseTree, "tree": entries])
        let newTree = try gdDecode(GitShaResponse.self, treeOut)

        let commitOut = try await raw("\(base)/commits", method: "POST",
                                      body: ["message": message, "tree": newTree.sha, "parents": [headSha]])
        let newCommit = try gdDecode(GitShaResponse.self, commitOut)

        do {
            _ = try await raw("\(base)/refs/heads/\(branch)", method: "PATCH",
                              body: ["sha": newCommit.sha, "force": false])
        } catch let e as APIError where e.statusCode == 422 {
            throw APIError(message: "Nhánh \(branch) vừa có commit mới. Hãy mở lại và thử lần nữa.", statusCode: 422)
        }
    }
}
