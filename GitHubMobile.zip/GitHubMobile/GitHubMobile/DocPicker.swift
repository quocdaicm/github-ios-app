import UIKit
import UniformTypeIdentifiers

/// Mở bộ chọn file gốc của iOS trực tiếp từ UIKit (ổn định hơn SwiftUI fileImporter)
final class DocPicker: NSObject, UIDocumentPickerDelegate {
    private static var current: DocPicker?
    private let onPick: ([URL]) -> Void

    private init(onPick: @escaping ([URL]) -> Void) {
        self.onPick = onPick
    }

    /// asCopy = true: iOS sao chép file vào vùng tạm của app (đọc được ngay, kể cả file iCloud).
    /// Chọn thư mục thì phải để asCopy = false.
    static func present(types: [UTType],
                        asCopy: Bool,
                        multiple: Bool = true,
                        onPick: @escaping ([URL]) -> Void) {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: asCopy)
        picker.allowsMultipleSelection = multiple
        let d = DocPicker(onPick: onPick)
        current = d            // delegate là weak nên phải giữ lại
        picker.delegate = d
        guard let top = topController() else {
            current = nil
            return
        }
        top.present(picker, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        DocPicker.current = nil
        // Đợi bảng chọn đóng xong để màn hình kế tiếp (sheet) hiện được
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { [onPick] in
            onPick(urls)
        }
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        DocPicker.current = nil
    }

    private static func topController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first
        let window = scene?.windows.first(where: { $0.isKeyWindow }) ?? scene?.windows.first
        var vc = window?.rootViewController
        while let p = vc?.presentedViewController { vc = p }
        return vc
    }
}
