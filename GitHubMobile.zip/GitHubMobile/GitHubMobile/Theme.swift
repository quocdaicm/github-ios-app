import SwiftUI
import UIKit

/// Ẩn bàn phím ở bất kỳ đâu
func hideKeyboard() {
    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder),
                                    to: nil, from: nil, for: nil)
}

// MARK: - Bảng màu và kiểu dáng dùng chung

private func rgb(_ r: Double, _ g: Double, _ b: Double, _ a: Double = 1) -> UIColor {
    UIColor(red: r, green: g, blue: b, alpha: a)
}

/// Màu tự đổi theo chế độ sáng/tối
private func dynamic(_ light: UIColor, _ dark: UIColor) -> Color {
    Color(UIColor { traits in
        traits.userInterfaceStyle == .dark ? dark : light
    })
}

enum Theme {
    static let accent = Color(red: 0.30, green: 0.58, blue: 1.0)
    static let accent2 = Color(red: 0.62, green: 0.42, blue: 1.0)
    static let neon = Color(red: 0.22, green: 0.92, blue: 0.86)
    static let good = Color(red: 0.28, green: 0.90, blue: 0.56)
    static let bad = Color(red: 1.0, green: 0.36, blue: 0.46)
    static let warn = Color(red: 1.0, green: 0.74, blue: 0.28)

    static let brandGradient = LinearGradient(
        colors: [accent, accent2],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    static let bgTop = dynamic(rgb(0.925, 0.945, 1.0), rgb(0.035, 0.045, 0.115))
    static let bgBottom = dynamic(rgb(0.975, 0.978, 0.990), rgb(0.010, 0.014, 0.040))
    static let card = dynamic(rgb(1, 1, 1), rgb(0.075, 0.095, 0.185))
    static let border = dynamic(rgb(0.10, 0.20, 0.45, 0.10), rgb(1, 1, 1, 0.10))
    static let shadow = dynamic(rgb(0.10, 0.20, 0.45, 0.10), rgb(0, 0, 0, 0.45))
    static let codeBG = dynamic(rgb(0.955, 0.965, 0.985), rgb(0.07, 0.09, 0.14))
    static let editorBG = dynamic(rgb(0.992, 0.994, 1.0), rgb(0.045, 0.060, 0.090))

    /// Áp dụng một lần khi khởi động app (các thành phần UIKit)
    static func applyAppearance() {
        let seg = UISegmentedControl.appearance()
        seg.selectedSegmentTintColor = UIColor(accent)
        seg.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)
    }
}

// MARK: - Nền

/// Các vì sao nhấp nháy (chỉ vẽ ở chế độ tối)
struct StarField: View {
    let animated: Bool

    private struct Star {
        let x: Double
        let y: Double
        let r: Double
        let phase: Double
        let speed: Double
        let bright: Double
        let tint: Int
    }

    fileprivate static func rnd(_ i: Int, _ salt: Double) -> Double {
        let v = sin(Double(i) * 12.9898 + salt * 78.233) * 43758.5453
        return v - v.rounded(.down)
    }

    private static let stars: [Star] = (0..<80).map { i in
        Star(x: StarField.rnd(i, 1), y: StarField.rnd(i, 2), r: 0.5 + StarField.rnd(i, 3) * 1.4,
             phase: StarField.rnd(i, 4) * 6.28, speed: 0.6 + StarField.rnd(i, 5) * 1.8,
             bright: 0.35 + StarField.rnd(i, 6) * 0.65, tint: Int(StarField.rnd(i, 7) * 3))
    }

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 12.0, paused: !animated)) { ctx in
            Canvas { gc, size in
                let t = ctx.date.timeIntervalSinceReferenceDate
                for s in StarField.stars {
                    let tw = 0.5 + 0.5 * sin(t * s.speed + s.phase)
                    let alpha = 0.12 + 0.75 * tw * s.bright
                    let color: Color = s.tint == 0 ? Theme.neon : (s.tint == 1 ? Theme.accent2 : .white)
                    let rect = CGRect(x: s.x * size.width - s.r, y: s.y * size.height - s.r,
                                      width: s.r * 2, height: s.r * 2)
                    gc.fill(Path(ellipseIn: rect), with: .color(color.opacity(alpha)))
                }
            }
        }
        .allowsHitTesting(false)
    }
}

struct AppBackground: View {
    @Environment(\.colorScheme) private var scheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        ZStack {
            LinearGradient(colors: [Theme.bgTop, Theme.bgBottom],
                           startPoint: .top, endPoint: .bottom)
            RadialGradient(colors: [Theme.accent.opacity(scheme == .dark ? 0.26 : 0.16), .clear],
                           center: .topTrailing, startRadius: 0, endRadius: 420)
            RadialGradient(colors: [Theme.accent2.opacity(scheme == .dark ? 0.20 : 0.10), .clear],
                           center: .bottomLeading, startRadius: 0, endRadius: 380)
            if scheme == .dark {
                RadialGradient(colors: [Theme.neon.opacity(0.08), .clear],
                               center: .center, startRadius: 0, endRadius: 300)
                StarField(animated: !reduceMotion)
            }
        }
        .ignoresSafeArea()
    }
}

// MARK: - Phản hồi xúc giác và kiểu nút

enum Haptics {
    static func tap() {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }
    static func success() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }
    static func error() {
        UINotificationFeedbackGenerator().notificationOccurred(.error)
    }
}

/// Nút co nhẹ khi nhấn
struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.92 : 1)
            .opacity(configuration.isPressed ? 0.85 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.65), value: configuration.isPressed)
    }
}

extension View {
    /// Thẻ kính tối có viền sáng và quầng sáng theo màu `glow`
    func glassCard(glow: Color = Theme.accent) -> some View {
        self.background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Theme.card.opacity(0.78))
                .overlay(
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .strokeBorder(
                            LinearGradient(colors: [glow.opacity(0.65), Theme.accent2.opacity(0.18), Theme.border],
                                           startPoint: .topLeading, endPoint: .bottomTrailing),
                            lineWidth: 1)
                )
                .shadow(color: glow.opacity(0.22), radius: 14, x: 0, y: 4)
        )
    }
}

extension View {
    /// Danh sách/biểu mẫu trong suốt, đặt trên nền gradient
    func themedList() -> some View {
        self
            .scrollContentBackground(.hidden)
            .background { AppBackground() }
            // Vuốt danh sách là bàn phím tự ẩn; thêm nút "Xong" trên bàn phím
            .scrollDismissesKeyboard(.interactively)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Xong") { hideKeyboard() }
                }
            }
    }

    /// Dòng danh sách dạng thẻ bo góc có viền và bóng nhẹ
    func cardRow(vertical: CGFloat = 10) -> some View {
        self
            .listRowSeparator(.hidden)
            .listRowInsets(EdgeInsets(top: vertical, leading: 28, bottom: vertical, trailing: 28))
            .listRowBackground(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Theme.card.opacity(0.85))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .strokeBorder(
                                LinearGradient(colors: [Theme.accent.opacity(0.45), Theme.accent2.opacity(0.12), Theme.border],
                                               startPoint: .topLeading, endPoint: .bottomTrailing),
                                lineWidth: 1)
                    )
                    .shadow(color: Theme.accent.opacity(0.14), radius: 8, x: 0, y: 2)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 3)
            )
    }
}

// MARK: - Thành phần nhỏ

struct Chip: View {
    let text: String
    var icon: String? = nil
    var color: Color = Theme.accent

    var body: some View {
        HStack(spacing: 4) {
            if let icon = icon {
                Image(systemName: icon).font(.system(size: 9, weight: .bold))
            }
            Text(text).font(.caption2.weight(.semibold))
        }
        .foregroundStyle(color)
        .padding(.horizontal, 8)
        .padding(.vertical, 3)
        .background(Capsule().fill(color.opacity(0.13)))
    }
}

func statusStyle(_ status: String?, _ conclusion: String?) -> (icon: String, color: Color) {
    if status == "completed" {
        switch conclusion ?? "" {
        case "success": return ("checkmark.circle.fill", .green)
        case "failure", "timed_out", "startup_failure": return ("xmark.circle.fill", .red)
        case "cancelled": return ("slash.circle.fill", .gray)
        case "skipped": return ("arrow.right.circle", .gray)
        default: return ("exclamationmark.circle.fill", .orange)
        }
    }
    if status == "in_progress" { return ("arrow.triangle.2.circlepath", .orange) }
    return ("clock.fill", .gray)
}

struct StatusPill: View {
    let status: String?
    let conclusion: String?

    var body: some View {
        let s = statusStyle(status, conclusion)
        Chip(text: statusText(status, conclusion), icon: s.icon, color: s.color)
    }
}
