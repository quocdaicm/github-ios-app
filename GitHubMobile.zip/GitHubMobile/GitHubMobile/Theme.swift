import SwiftUI
import UIKit

// MARK: - Bảng màu và kiểu dáng dùng chung

private func rgb(_ r: Double, _ g: Double, _ b: Double, _ a: Double = 1) -> UIColor {
    UIColor(red: r, green: g, blue: b, alpha: a)
}

/// Màu tự đổi theo chế độ sáng/tối
private func dynamic(_ light: UIColor, _ dark: UIColor) -> Color {
    Color(UIColor { traits in
        traits.userInterfaceStyle == .dark ? dark : light
    })
}

enum Theme {
    static let accent = Color(red: 0.14, green: 0.42, blue: 0.96)
    static let accent2 = Color(red: 0.46, green: 0.32, blue: 0.95)

    static let brandGradient = LinearGradient(
        colors: [accent, accent2],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    static let bgTop = dynamic(rgb(0.925, 0.945, 1.0), rgb(0.055, 0.075, 0.125))
    static let bgBottom = dynamic(rgb(0.975, 0.978, 0.990), rgb(0.025, 0.035, 0.065))
    static let card = dynamic(rgb(1, 1, 1), rgb(0.105, 0.125, 0.185))
    static let border = dynamic(rgb(0.10, 0.20, 0.45, 0.10), rgb(1, 1, 1, 0.09))
    static let shadow = dynamic(rgb(0.10, 0.20, 0.45, 0.10), rgb(0, 0, 0, 0.40))
    static let codeBG = dynamic(rgb(0.955, 0.965, 0.985), rgb(0.07, 0.09, 0.14))
    static let editorBG = dynamic(rgb(0.992, 0.994, 1.0), rgb(0.045, 0.060, 0.090))

    /// Áp dụng một lần khi khởi động app (các thành phần UIKit)
    static func applyAppearance() {
        let seg = UISegmentedControl.appearance()
        seg.selectedSegmentTintColor = UIColor(accent)
        seg.setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)
    }
}

// MARK: - Nền

struct AppBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [Theme.bgTop, Theme.bgBottom],
                           startPoint: .top, endPoint: .bottom)
            RadialGradient(colors: [Theme.accent.opacity(0.16), .clear],
                           center: .topTrailing, startRadius: 0, endRadius: 380)
            RadialGradient(colors: [Theme.accent2.opacity(0.10), .clear],
                           center: .bottomLeading, startRadius: 0, endRadius: 340)
        }
        .ignoresSafeArea()
    }
}

extension View {
    /// Danh sách/biểu mẫu trong suốt, đặt trên nền gradient
    func themedList() -> some View {
        self
            .scrollContentBackground(.hidden)
            .background { AppBackground() }
    }

    /// Dòng danh sách dạng thẻ bo góc có viền và bóng nhẹ
    func cardRow(vertical: CGFloat = 10) -> some View {
        self
            .listRowSeparator(.hidden)
            .listRowInsets(EdgeInsets(top: vertical, leading: 28, bottom: vertical, trailing: 28))
            .listRowBackground(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Theme.card)
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .strokeBorder(Theme.border, lineWidth: 1)
                    )
                    .shadow(color: Theme.shadow, radius: 6, x: 0, y: 2)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 3)
            )
    }
}

// MARK: - Thành phần nhỏ

struct Chip: View {
    let text: String
    var icon: String? = nil
    var color: Color = Theme.accent

    var body: some View {
        HStack(spacing: 4) {
            if let icon = icon {
                Image(systemName: icon).font(.system(size: 9, weight: .bold))
            }
            Text(text).font(.caption2.weight(.semibold))
        }
        .foregroundStyle(color)
        .padding(.horizontal, 8)
        .padding(.vertical, 3)
        .background(Capsule().fill(color.opacity(0.13)))
    }
}

func statusStyle(_ status: String?, _ conclusion: String?) -> (icon: String, color: Color) {
    if status == "completed" {
        switch conclusion ?? "" {
        case "success": return ("checkmark.circle.fill", .green)
        case "failure", "timed_out", "startup_failure": return ("xmark.circle.fill", .red)
        case "cancelled": return ("slash.circle.fill", .gray)
        case "skipped": return ("arrow.right.circle", .gray)
        default: return ("exclamationmark.circle.fill", .orange)
        }
    }
    if status == "in_progress" { return ("arrow.triangle.2.circlepath", .orange) }
    return ("clock.fill", .gray)
}

struct StatusPill: View {
    let status: String?
    let conclusion: String?

    var body: some View {
        let s = statusStyle(status, conclusion)
        Chip(text: statusText(status, conclusion), icon: s.icon, color: s.color)
    }
}
