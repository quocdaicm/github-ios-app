import SwiftUI
import UIKit
import UniformTypeIdentifiers

private let mono = Font.system(size: 13, design: .monospaced)

// MARK: - Đăng nhập

struct LoginView: View {
    @EnvironmentObject var session: Session
    @State private var token = ""
    @State private var busy = false
    @State private var error: String?

    private var trimmed: String { token.trimmingCharacters(in: .whitespacesAndNewlines) }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    VStack(spacing: 10) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 22, style: .continuous)
                                .fill(Theme.brandGradient)
                            Image(systemName: "chevron.left.forwardslash.chevron.right")
                                .font(.system(size: 34, weight: .semibold))
                                .foregroundStyle(.white)
                        }
                        .frame(width: 76, height: 76)
                        .shadow(color: Theme.accent.opacity(0.35), radius: 12, x: 0, y: 6)
                        Text("GitHub Mobile").font(.title2.bold())
                        Text("Sửa code và quản lý build ngay trên điện thoại")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                }
                .listRowBackground(Color.clear)

                Section {
                    SecureField("Dán Personal Access Token", text: $token)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .submitLabel(.go)
                        .onSubmit {
                            if !trimmed.isEmpty && !busy {
                                hideKeyboard()
                                Task { await go() }
                            }
                        }
                } footer: {
                    Text("Token được lưu trên máy này, chỉ dùng để gọi api.github.com.")
                }

                if let notice = session.notice {
                    Section { Text(notice).foregroundStyle(.orange) }
                }

                if let error = error {
                    Section { Text(error).foregroundStyle(.red) }
                }

                Section {
                    Button {
                        hideKeyboard()
                        Task { await go() }
                    } label: {
                        Group {
                            if busy { ProgressView() } else { Text("Đăng nhập").fontWeight(.semibold) }
                        }
                        .frame(maxWidth: .infinity, alignment: .center)
                    }
                    .disabled(trimmed.isEmpty || busy)
                }

                Section("Cách tạo token") {
                    Text("Tạo token (classic) với quyền repo và workflow. Token dạng fine-grained cần quyền Contents, Actions và Metadata ở mức đọc/ghi.")
                        .font(.footnote)
                    Link("Mở trang tạo token",
                         destination: URL(string: "https://github.com/settings/tokens/new?scopes=repo,workflow&description=GitHubMobile")!)
                }
            }
            .navigationTitle("GitHub Mobile")
            .navigationBarTitleDisplayMode(.inline)
            .themedList()
        }
    }

    private func go() async {
        busy = true
        error = nil
        defer { busy = false }
        do {
            try await session.signIn(token: trimmed)
        } catch let e {
            error = e.localizedDescription
        }
    }
}

// MARK: - Danh sách repo

func starText(_ n: Int) -> String {
    if n >= 1_000_000 { return String(format: "%.1fM", Double(n) / 1_000_000) }
    if n >= 1000 { return String(format: "%.1fk", Double(n) / 1000) }
    return "\(n)"
}

enum RepoScope: Hashable { case mine, github, starred }

struct RepoListView: View {
    @EnvironmentObject var session: Session
    @State private var repos: [Repo] = []
    @State private var query = ""
    @State private var scope: RepoScope = .mine
    @State private var results: [Repo] = []
    @State private var searching = false
    @State private var searchError: String?
    @State private var searchPage = 1
    @State private var hasMoreResults = false
    @State private var loading = false
    @State private var error: String?
    @State private var showNew = false
    @State private var pendingRepo: Repo?
    @State private var openRepo: Repo?
    @State private var goRepo = false
    @State private var toast: String?
    @State private var pendingToast: String?
    @State private var editRepo: Repo?
    @State private var deleteTarget: Repo?
    @State private var showDelete = false
    @State private var deleteText = ""
    @State private var deleting = false
    @State private var starredRepos: [Repo] = []
    @State private var loadingStarred = false
    @State private var starredError: String?
    @AppStorage("translateInline") private var translateInline = false
    @AppStorage("translateLang") private var translateLang = "vi"
    @AppStorage("appearance") private var appearance = "dark"

    private var filtered: [Repo] {
        query.isEmpty ? repos : repos.filter { $0.fullName.localizedCaseInsensitiveContains(query) }
    }

    private var searchPrompt: String {
        switch scope {
        case .github: return "Tìm repo trên GitHub, hoặc dán link"
        case .starred: return "Tìm trong repo đã gắn sao"
        case .mine: return "Tìm repo của tôi"
        }
    }

    private var starredFiltered: [Repo] {
        query.isEmpty ? starredRepos : starredRepos.filter { $0.fullName.localizedCaseInsensitiveContains(query) }
    }

    private var trimmedQuery: String { query.trimmingCharacters(in: .whitespacesAndNewlines) }

    var body: some View {
        List {
            if scope == .github {
                githubRows
            } else if scope == .starred {
                starredRows
            } else {
                if let error = error {
                    Text(error).foregroundStyle(.red)
                }
                ForEach(filtered) { repo in
                    NavigationLink {
                        RepoView(repo: repo)
                    } label: {
                        RepoRow(repo: repo)
                    }
                    .cardRow()
                    .swipeActions(edge: .trailing) {
                        if isOwner(repo) {
                            Button(role: .destructive) {
                                askDeleteRepo(repo)
                            } label: {
                                Label("Xóa", systemImage: "trash")
                            }
                            Button {
                                editRepo = repo
                            } label: {
                                Label("Sửa", systemImage: "pencil")
                            }
                            .tint(.blue)
                        }
                    }
                    .contextMenu {
                        if isOwner(repo) {
                            Button {
                                editRepo = repo
                            } label: {
                                Label("Sửa repo", systemImage: "pencil")
                            }
                            Button(role: .destructive) {
                                askDeleteRepo(repo)
                            } label: {
                                Label("Xóa repo", systemImage: "trash")
                            }
                        }
                    }
                }
            }
        }
        .listStyle(.plain)
        .themedList()
        .overlay {
            if (scope == .mine && loading && repos.isEmpty)
                || (scope == .starred && loadingStarred && starredRepos.isEmpty)
                || deleting { ProgressView() }
        }
        .navigationTitle("Repo của tôi")
        .searchable(text: $query, prompt: searchPrompt)
        .searchScopes($scope) {
            Text("Của tôi").tag(RepoScope.mine)
            Text("GitHub").tag(RepoScope.github)
            Text("Gắn sao").tag(RepoScope.starred)
        }
        .task(id: "\(scope)|\(query)") { await runSearch() }
        .task(id: scope) {
            if scope == .starred { await loadStarred() }
        }
        .refreshable {
            if scope == .starred { await loadStarred() } else { await load() }
        }
        .task {
            await session.refreshUser()
            await load()
        }
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                Button {
                    showNew = true
                } label: {
                    Image(systemName: "plus")
                }
                Menu {
                    if !session.login.isEmpty {
                        Button {
                            showMine()
                        } label: {
                            Label(session.login, systemImage: "person.crop.circle")
                        }
                    }
                    Picker("Giao diện", selection: $appearance) {
                        Text("Tối").tag("dark")
                        Text("Theo hệ thống").tag("system")
                    }
                    Toggle("Dịch mô tả repo & commit", isOn: $translateInline)
                    Picker("Ngôn ngữ dịch", selection: $translateLang) {
                        ForEach(TLang.all) { l in
                            Text(l.name).tag(l.code)
                        }
                    }
                    Button("Đăng xuất", role: .destructive) { session.signOut() }
                } label: {
                    Image(systemName: "person.circle")
                }
            }
        }
        .sheet(isPresented: $showNew, onDismiss: {
            if let r = pendingRepo {
                openRepo = r
                pendingRepo = nil
                goRepo = true
            }
            if let t = pendingToast {
                toast = t
                pendingToast = nil
            }
        }) {
            NewRepoView { repo, note in
                repos.insert(repo, at: 0)
                pendingRepo = repo
                pendingToast = note
            }
        }
        .sheet(item: $editRepo) { r in
            EditRepoView(repo: r) { updated in
                if let i = repos.firstIndex(where: { $0.id == updated.id }) {
                    repos[i] = updated
                }
                toast = "Đã lưu thay đổi cho \(updated.name)."
            }
        }
        .alert("Xóa repo \(deleteTarget?.name ?? "")?", isPresented: $showDelete) {
            TextField("Gõ tên repo để xác nhận", text: $deleteText)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Button("Hủy", role: .cancel) {}
            Button("Xóa vĩnh viễn", role: .destructive) {
                Task { await confirmDeleteRepo() }
            }
        } message: {
            Text("Toàn bộ mã nguồn, lịch sử, issue và Actions sẽ bị xóa và không khôi phục được. Gõ đúng tên repo để xác nhận.")
        }
        .navigationDestination(isPresented: $goRepo) {
            if let r = openRepo { RepoView(repo: r) }
        }
        .alert("Thông báo", isPresented: Binding(
            get: { toast != nil },
            set: { if !$0 { toast = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(toast ?? "")
        }
    }

    // MARK: Sửa / xóa repo

    private func isOwner(_ repo: Repo) -> Bool {
        !session.login.isEmpty && repo.owner.login.lowercased() == session.login.lowercased()
    }

    private func askDeleteRepo(_ repo: Repo) {
        deleteTarget = repo
        deleteText = ""
        showDelete = true
    }

    private func confirmDeleteRepo() async {
        guard let r = deleteTarget else { return }
        if deleteText.trimmingCharacters(in: .whitespacesAndNewlines) != r.name {
            toast = "Tên nhập vào không khớp nên chưa xóa repo."
            return
        }
        deleting = true
        defer { deleting = false }
        do {
            try await session.api.deleteRepo(r)
            repos.removeAll { $0.id == r.id }
            deleteTarget = nil
            toast = "Đã xóa repo \(r.name)."
        } catch let e {
            toast = e.localizedDescription
        }
    }

    /// Bấm tên đăng nhập: thoát chế độ tìm GitHub, quay về danh sách repo của tôi
    private func showMine() {
        hideKeyboard()
        query = ""
        results = []
        searchError = nil
        hasMoreResults = false
        scope = .mine
        Task { await load() }
    }

    // MARK: Repo đã gắn sao

    @ViewBuilder
    private var starredRows: some View {
        if let e = starredError {
            Text(e).font(.footnote).foregroundStyle(.red)
        } else if !loadingStarred && starredFiltered.isEmpty {
            Text("Chưa có repo nào được gắn sao. Mở repo của người khác và bấm ngôi sao để lưu lại.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .cardRow(vertical: 12)
        }
        ForEach(starredFiltered) { repo in
            NavigationLink {
                if repo.owner.login.lowercased() == session.login.lowercased() {
                    RepoView(repo: repo)
                } else {
                    ExternalRepoView(repo: repo) { forked in
                        repos.removeAll { $0.id == forked.id }
                        repos.insert(forked, at: 0)
                    }
                }
            } label: {
                RepoRow(repo: repo)
            }
            .cardRow()
        }
    }

    private func loadStarred() async {
        if loadingStarred { return }
        loadingStarred = true
        defer { loadingStarred = false }
        do {
            starredRepos = try await session.api.starred()
            starredError = nil
        } catch let e {
            starredError = e.localizedDescription
        }
    }

    // MARK: Tìm repo trên GitHub

    @ViewBuilder
    private var githubRows: some View {
        if trimmedQuery.count < 2 {
            Text("Gõ tên repo, từ khóa, hoặc dán link github.com/chủ/repo để tìm repo của người khác.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .cardRow(vertical: 12)
        } else if searching && results.isEmpty {
            HStack {
                Spacer()
                ProgressView()
                Spacer()
            }
        } else if let e = searchError {
            Text(e).font(.footnote).foregroundStyle(.red)
        } else if results.isEmpty {
            Text("Không tìm thấy repo nào.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .cardRow(vertical: 12)
        }
        ForEach(results) { repo in
            NavigationLink {
                if repo.owner.login.lowercased() == session.login.lowercased() {
                    RepoView(repo: repo)
                } else {
                    ExternalRepoView(repo: repo) { forked in
                        repos.removeAll { $0.id == forked.id }
                        repos.insert(forked, at: 0)
                    }
                }
            } label: {
                RepoRow(repo: repo)
            }
            .cardRow()
        }
        if hasMoreResults {
            Button {
                Task { await loadMoreResults() }
            } label: {
                HStack {
                    Spacer()
                    if searching { ProgressView() } else { Text("Tải thêm") }
                    Spacer()
                }
            }
        }
    }

    /// "chủ/repo" hoặc link github.com/chủ/repo -> "chủ/repo"
    private static func parseFullName(_ q: String) -> String? {
        var s = q
        for p in ["https://www.github.com/", "https://github.com/", "http://github.com/",
                  "www.github.com/", "github.com/"] where s.lowercased().hasPrefix(p) {
            s = String(s.dropFirst(p.count))
            break
        }
        let parts = s.split(separator: "/", omittingEmptySubsequences: true).map(String.init)
        guard parts.count >= 2 else { return nil }
        let owner = parts[0]
        var name = parts[1]
        if name.hasSuffix(".git") { name = String(name.dropLast(4)) }
        let ok = { (x: String) in
            !x.isEmpty && x.range(of: "^[A-Za-z0-9._-]+$", options: .regularExpression) != nil
        }
        guard ok(owner), ok(name) else { return nil }
        return owner + "/" + name
    }

    private func runSearch() async {
        guard scope == .github else { return }
        let q = trimmedQuery
        if q.count < 2 {
            results = []
            searchError = nil
            hasMoreResults = false
            return
        }
        try? await Task.sleep(nanoseconds: 600_000_000)   // chờ người dùng gõ xong
        if Task.isCancelled { return }
        searching = true
        defer { searching = false }
        if let full = Self.parseFullName(q),
           let r = try? await session.api.repo(fullName: full) {
            if Task.isCancelled { return }
            results = [r]
            searchError = nil
            hasMoreResults = false
            return
        }
        do {
            let found = try await session.api.searchRepos(q)
            if Task.isCancelled { return }
            results = found
            searchPage = 1
            hasMoreResults = found.count >= 30
            searchError = nil
        } catch let e {
            if Task.isCancelled { return }
            results = []
            hasMoreResults = false
            searchError = e.localizedDescription
        }
    }

    private func loadMoreResults() async {
        if searching { return }
        searching = true
        defer { searching = false }
        do {
            let next = try await session.api.searchRepos(trimmedQuery, page: searchPage + 1)
            let have = Set(results.map { $0.id })
            results += next.filter { !have.contains($0.id) }
            searchPage += 1
            hasMoreResults = next.count >= 30 && searchPage < 10
        } catch let e {
            searchError = e.localizedDescription
        }
    }

    private func load() async {
        if loading { return }
        loading = true
        defer { loading = false }
        do {
            repos = try await session.api.repos()
            error = nil
        } catch let e {
            error = e.localizedDescription
        }
    }
}

struct RepoRow: View {
    let repo: Repo

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 11, style: .continuous)
                    .fill(Theme.accent.opacity(0.13))
                Image(systemName: repo.isPrivate ? "lock.fill" : "shippingbox.fill")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(Theme.accent)
            }
            .frame(width: 40, height: 40)

            VStack(alignment: .leading, spacing: 4) {
                Text(repo.name)
                    .font(.subheadline.weight(.semibold))
                    .lineLimit(1)
                Text(repo.owner.login)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                if let d = repo.description, !d.isEmpty {
                    TranslatedText(text: d)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }
                HStack(spacing: 6) {
                    if let l = repo.language, !l.isEmpty {
                        Chip(text: l, icon: "chevron.left.forwardslash.chevron.right")
                    }
                    if let st = repo.stargazersCount, st > 0 {
                        Chip(text: starText(st), icon: "star.fill", color: .yellow)
                    }
                    if repo.isPrivate {
                        Chip(text: "Private", icon: "lock.fill", color: .orange)
                    }
                    Text(relative(repo.updatedAt))
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                .padding(.top, 2)
            }
        }
        .padding(.vertical, 2)
    }
}

// MARK: - Màn hình repo (Mã nguồn / Actions)

struct RepoView: View {
    let repo: Repo
    @EnvironmentObject var session: Session
    @State private var branch: String
    @State private var branches: [String] = []
    @State private var tab = 0
    @State private var askNewBranch = false
    @State private var newBranchName = ""
    @State private var askDeleteBranch = false
    @State private var branchToast: String?

    init(repo: Repo) {
        self.repo = repo
        _branch = State(initialValue: repo.defaultBranch)
    }

    private func createBranch() async {
        let n = newBranchName.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: " ", with: "-")
        guard !n.isEmpty else { return }
        do {
            try await session.api.createBranch(repo, name: n, from: branch)
            if !branches.contains(n) { branches.append(n) }
            branch = n
            branchToast = "Đã tạo nhánh \(n)."
        } catch let e {
            branchToast = e.localizedDescription
        }
    }

    private func deleteBranch() async {
        let n = branch
        do {
            try await session.api.deleteBranch(repo, name: n)
            branches.removeAll { $0 == n }
            branch = repo.defaultBranch
            branchToast = "Đã xóa nhánh \(n)."
        } catch let e {
            branchToast = e.localizedDescription
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            Picker("", selection: $tab) {
                Text("Mã nguồn").tag(0)
                Text("Actions").tag(1)
                Text("Lịch sử").tag(2)
                Text("PR/Issue").tag(3)
                Text("Release").tag(4)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal)
            .padding(.bottom, 8)
            .background(.bar)

            if tab == 0 {
                FileBrowserView(repo: repo, branch: branch, path: "", isRoot: true)
            } else if tab == 1 {
                ActionsView(repo: repo, branch: branch)
            } else if tab == 2 {
                CommitsView(repo: repo, branch: branch)
            } else if tab == 3 {
                PullsIssuesView(repo: repo)
            } else {
                ReleasesView(repo: repo, branch: branch)
            }
        }
        .navigationTitle(repo.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                RepoZipButton(repo: repo, branch: branch)
                Menu {
                    Picker("Nhánh", selection: $branch) {
                        ForEach(branches.isEmpty ? [branch] : branches, id: \.self) { b in
                            Text(b).tag(b)
                        }
                    }
                    Divider()
                    Button {
                        newBranchName = ""
                        askNewBranch = true
                    } label: {
                        Label("Tạo nhánh mới từ \(branch)", systemImage: "plus")
                    }
                    if branch != repo.defaultBranch {
                        Button(role: .destructive) {
                            askDeleteBranch = true
                        } label: {
                            Label("Xóa nhánh \(branch)", systemImage: "trash")
                        }
                    }
                } label: {
                    Label(branch, systemImage: "arrow.triangle.branch")
                }
            }
        }
        .task {
            if let list = try? await session.api.branches(repo) {
                branches = list.map { $0.name }
            }
        }
        .alert("Tạo nhánh mới", isPresented: $askNewBranch) {
            TextField("Tên nhánh", text: $newBranchName)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Button("Hủy", role: .cancel) {}
            Button("Tạo") { Task { await createBranch() } }
        } message: {
            Text("Nhánh mới được tạo từ đầu nhánh \(branch).")
        }
        .alert("Xóa nhánh \(branch)?", isPresented: $askDeleteBranch) {
            Button("Hủy", role: .cancel) {}
            Button("Xóa", role: .destructive) { Task { await deleteBranch() } }
        } message: {
            Text("Nhánh sẽ bị xóa khỏi GitHub. Các commit chưa gộp có thể khó lấy lại.")
        }
        .alert("Thông báo", isPresented: Binding(
            get: { branchToast != nil },
            set: { if !$0 { branchToast = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(branchToast ?? "")
        }
    }
}

// MARK: - Duyệt file

struct FileBrowserView: View {
    let repo: Repo
    let branch: String
    let path: String
    var isRoot: Bool = false
    /// true: xem repo của người khác (ẩn mọi thao tác sửa)
    var viewOnly: Bool = false

    @EnvironmentObject var session: Session
    @EnvironmentObject var staging: Staging
    @State private var items: [ContentItem] = []
    @State private var loading = false
    @State private var working = false
    @State private var error: String?
    @State private var askName = false
    @State private var newName = ""
    @State private var goNew = false
    @State private var newPath = ""
    @State private var readmeName = ""
    @State private var readmeText: String?
    // Bộ chọn file gốc của iOS (UIKit), mở trực tiếp: tránh lỗi nút "Mở" của SwiftUI fileImporter
    enum ImportMode { case file, folder, zip }
    @State private var batch: UploadBatch?
    @State private var showPack = false
    @State private var renameItem: ContentItem?
    @State private var renameText = ""
    @State private var showRename = false
    @State private var deleteItem: ContentItem?
    @State private var showDelete = false
    @State private var toast: String?
    @State private var pendingToast: String?

    private var key: String { Staging.key(repo, branch) }
    private var stagedCount: Int { staging.count(key) }

    private var title: String {
        path.isEmpty ? repo.name : (path as NSString).lastPathComponent
    }

    var body: some View {
        List {
            if let error = error {
                Text(error).font(.footnote).foregroundStyle(.secondary)
            }
            ForEach(items) { item in
                Group {
                    if item.type == "dir" {
                        NavigationLink {
                            FileBrowserView(repo: repo, branch: branch, path: item.path, viewOnly: viewOnly)
                        } label: {
                            Label(item.name, systemImage: "folder.fill")
                        }
                    } else {
                        NavigationLink {
                            FileEditorView(repo: repo, branch: branch, path: item.path, isNew: false, viewOnly: viewOnly)
                        } label: {
                            HStack {
                                Label(item.name, systemImage: icon(for: item.name))
                                Spacer()
                                Text(sizeText(item.size))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                .cardRow(vertical: 8)
                .swipeActions(edge: .trailing) {
                    if !viewOnly {
                        Button(role: .destructive) {
                            askDelete(item)
                        } label: {
                            Label("Xóa", systemImage: "trash")
                        }
                        Button {
                            askRename(item)
                        } label: {
                            Label("Đổi tên", systemImage: "pencil")
                        }
                        .tint(.blue)
                    }
                }
                .contextMenu {
                    if !viewOnly {
                        Button {
                            askRename(item)
                        } label: {
                            Label("Đổi tên / di chuyển", systemImage: "pencil")
                        }
                        Button(role: .destructive) {
                            askDelete(item)
                        } label: {
                            Label("Xóa", systemImage: "trash")
                        }
                    }
                }
            }
            if let md = readmeText {
                Section {
                    TranslatableMarkdown(text: md).padding(.vertical, 6).cardRow()
                } header: {
                    Label(readmeName, systemImage: "book")
                }
            }
        }
        .listStyle(.plain)
        .themedList()
        .overlay {
            if (loading && items.isEmpty) || working { ProgressView() }
        }
        .navigationTitle(isRoot ? repo.name : title)
        .navigationBarTitleDisplayMode(.inline)
        .refreshable { await load() }
        .task(id: branch) { await load() }
        .onAppear {
            if !items.isEmpty { Task { await load(silent: true) } }
        }
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                if isRoot {
                    NavigationLink {
                        RepoSearchView(repo: repo, viewOnly: viewOnly)
                    } label: {
                        Image(systemName: "magnifyingglass")
                    }
                }
                if !viewOnly && stagedCount > 0 {
                    Button {
                        showPack = true
                    } label: {
                        Label("\(stagedCount)", systemImage: "tray.full")
                    }
                }
                if !viewOnly {
                Menu {
                    Button {
                        newName = ""
                        askName = true
                    } label: {
                        Label("Tạo file mới", systemImage: "doc.badge.plus")
                    }
                    Button {
                        openImporter(.file)
                    } label: {
                        Label("Tải file lên", systemImage: "square.and.arrow.up")
                    }
                    Button {
                        openImporter(.folder)
                    } label: {
                        Label("Tải thư mục lên", systemImage: "folder.badge.plus")
                    }
                    Button {
                        openImporter(.zip)
                    } label: {
                        Label("Tải zip lên và giải nén", systemImage: "doc.zipper")
                    }
                    if stagedCount > 0 {
                        Button {
                            showPack = true
                        } label: {
                            Label("Gói commit (\(stagedCount))", systemImage: "tray.full")
                        }
                    }
                } label: {
                    Image(systemName: "plus")
                }
                }
            }
        }
        .alert("Tạo file mới", isPresented: $askName) {
            TextField("ten-file.txt", text: $newName)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Button("Hủy", role: .cancel) {}
            Button("Tạo") {
                let n = newName.trimmingCharacters(in: .whitespaces)
                if !n.isEmpty {
                    newPath = path.isEmpty ? n : path + "/" + n
                    goNew = true
                }
            }
        } message: {
            Text("Gõ thư-mục/ten-file để tạo luôn thư mục mới.")
        }
        .alert("Đổi tên / di chuyển", isPresented: $showRename) {
            TextField("thư-mục/tên-mới", text: $renameText)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Button("Hủy", role: .cancel) {}
            Button("Thêm vào gói") { applyRename(now: false) }
            Button("Commit ngay") { applyRename(now: true) }
        } message: {
            Text("Sửa đường dẫn đầy đủ. Đổi thư mục cha nghĩa là chuyển sang nơi khác.")
        }
        .alert("Xóa \(deleteItem?.name ?? "")?", isPresented: $showDelete) {
            Button("Hủy", role: .cancel) {}
            Button("Thêm vào gói") { applyDelete(now: false) }
            Button("Xóa và commit", role: .destructive) { applyDelete(now: true) }
        } message: {
            Text(deleteItem?.type == "dir"
                 ? "Toàn bộ file trong thư mục này sẽ bị xóa."
                 : "File sẽ bị xóa khỏi nhánh \(branch).")
        }
        .alert("Thông báo", isPresented: Binding(
            get: { toast != nil },
            set: { if !$0 { toast = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(toast ?? "")
        }
        .sheet(item: $batch, onDismiss: afterSheet) { b in
            UploadSheet(repo: repo, branch: branch, dir: path, batch: b) { msg in
                pendingToast = msg
            }
        }
        .sheet(isPresented: $showPack, onDismiss: afterSheet) {
            StagedChangesView(repo: repo, branch: branch) { msg in
                pendingToast = msg
            }
        }
        .navigationDestination(isPresented: $goNew) {
            FileEditorView(repo: repo, branch: branch, path: newPath, isNew: true)
        }
    }

    private func icon(for name: String) -> String {
        switch (name as NSString).pathExtension.lowercased() {
        case "swift": return "swift"
        case "md", "txt": return "doc.text"
        case "yml", "yaml", "json", "plist": return "gearshape"
        case "png", "jpg", "jpeg", "gif", "webp": return "photo"
        default: return "doc"
        }
    }

    // MARK: Thao tác

    private func afterSheet() {
        if let t = pendingToast {
            toast = t
            pendingToast = nil
        }
        Task { await load(silent: true) }
    }

    private func openImporter(_ mode: ImportMode) {
        let types: [UTType]
        switch mode {
        case .file: types = [.item]
        case .folder: types = [.folder]
        case .zip: types = [.zip]
        }
        // Đợi menu đóng hẳn rồi mới mở bảng chọn file
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            DocPicker.present(types: types, asCopy: mode != .folder) { urls in
                handleImport(.success(urls), unzip: mode == .zip)
            }
        }
    }

    private func handleImport(_ result: Result<[URL], Error>, unzip: Bool) {
        switch result {
        case .failure(let e):
            toast = e.localizedDescription
        case .success(let urls):
            Task {
                let b = await Task.detached { UploadReader.read(urls, unzip: unzip) }.value
                if b.files.isEmpty {
                    toast = b.notes.first ?? "Không đọc được file nào."
                } else {
                    batch = b
                }
            }
        }
    }

    private func askRename(_ item: ContentItem) {
        renameItem = item
        renameText = item.path
        showRename = true
    }

    private func askDelete(_ item: ContentItem) {
        deleteItem = item
        showDelete = true
    }

    private func applyRename(now: Bool) {
        guard let item = renameItem else { return }
        let to = renameText.trimmingCharacters(in: CharacterSet(charactersIn: "/ \n"))
        let isDir = item.type == "dir"
        if to.isEmpty || to == item.path { return }
        if isDir && (to + "/").hasPrefix(item.path + "/") {
            toast = "Không thể chuyển thư mục vào chính nó."
            return
        }
        let ch = Change.move(from: item.path, to: to, isDir: isDir)
        if now {
            Task { await commitNow([ch], "Đổi tên \(item.name) → \(to)") }
        } else {
            staging.add(ch, key: key)
            toast = "Đã thêm vào gói commit (\(staging.count(key)) thay đổi)."
        }
    }

    private func applyDelete(now: Bool) {
        guard let item = deleteItem else { return }
        let ch = Change.delete(path: item.path, isDir: item.type == "dir")
        if now {
            Task { await commitNow([ch], "Xóa \(item.name)") }
        } else {
            staging.add(ch, key: key)
            toast = "Đã thêm vào gói commit (\(staging.count(key)) thay đổi)."
        }
    }

    private func commitNow(_ changes: [Change], _ message: String) async {
        working = true
        defer { working = false }
        do {
            try await session.api.commitChanges(repo, branch: branch, message: message, changes: changes)
            toast = "Đã commit lên nhánh \(branch)."
            await load(silent: true)
        } catch let e {
            toast = e.localizedDescription
        }
    }

    private func load(silent: Bool = false) async {
        if !silent { loading = true }
        defer { loading = false }
        do {
            let list = try await session.api.listDir(repo, path: path, ref: branch)
            items = list.sorted { a, b in
                if (a.type == "dir") != (b.type == "dir") { return a.type == "dir" }
                return a.name.localizedCaseInsensitiveCompare(b.name) == .orderedAscending
            }
            error = nil
            if isRoot && !silent { await loadReadme() }
        } catch let e {
            error = e.localizedDescription
            if !silent { items = [] }
        }
    }

    private func loadReadme() async {
        let names = ["readme.md", "readme.markdown", "readme"]
        guard let rd = items.first(where: { $0.type == "file" && names.contains($0.name.lowercased()) }),
              rd.size > 0, rd.size < 120_000 else {
            readmeText = nil
            return
        }
        if let f = try? await session.api.file(repo, path: rd.path, ref: branch),
           let s = String(data: f.data, encoding: .utf8) {
            readmeName = rd.name
            readmeText = s
        } else {
            readmeText = nil
        }
    }
}
