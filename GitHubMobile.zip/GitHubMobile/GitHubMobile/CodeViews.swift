import SwiftUI
import UIKit
import UniformTypeIdentifiers

private let mono = Font.system(size: 13, design: .monospaced)

// MARK: - Đăng nhập

struct LoginView: View {
    @EnvironmentObject var session: Session
    @State private var token = ""
    @State private var busy = false
    @State private var error: String?

    private var trimmed: String { token.trimmingCharacters(in: .whitespacesAndNewlines) }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField("Dán Personal Access Token", text: $token)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                } footer: {
                    Text("Token được lưu trên máy này, chỉ dùng để gọi api.github.com.")
                }

                if let notice = session.notice {
                    Section { Text(notice).foregroundStyle(.orange) }
                }

                if let error = error {
                    Section { Text(error).foregroundStyle(.red) }
                }

                Section {
                    Button {
                        Task { await go() }
                    } label: {
                        if busy { ProgressView() } else { Text("Đăng nhập") }
                    }
                    .disabled(trimmed.isEmpty || busy)
                }

                Section("Cách tạo token") {
                    Text("Tạo token (classic) với quyền repo và workflow. Token dạng fine-grained cần quyền Contents, Actions và Metadata ở mức đọc/ghi.")
                        .font(.footnote)
                    Link("Mở trang tạo token",
                         destination: URL(string: "https://github.com/settings/tokens/new?scopes=repo,workflow&description=GitHubMobile")!)
                }
            }
            .navigationTitle("GitHub Mobile")
        }
    }

    private func go() async {
        busy = true
        error = nil
        defer { busy = false }
        do {
            try await session.signIn(token: trimmed)
        } catch let e {
            error = e.localizedDescription
        }
    }
}

// MARK: - Danh sách repo

struct RepoListView: View {
    @EnvironmentObject var session: Session
    @State private var repos: [Repo] = []
    @State private var query = ""
    @State private var loading = false
    @State private var error: String?

    private var filtered: [Repo] {
        query.isEmpty ? repos : repos.filter { $0.fullName.localizedCaseInsensitiveContains(query) }
    }

    var body: some View {
        List {
            if let error = error {
                Text(error).foregroundStyle(.red)
            }
            ForEach(filtered) { repo in
                NavigationLink {
                    RepoView(repo: repo)
                } label: {
                    RepoRow(repo: repo)
                }
            }
        }
        .listStyle(.plain)
        .overlay {
            if loading && repos.isEmpty { ProgressView() }
        }
        .navigationTitle("Repo của tôi")
        .searchable(text: $query, prompt: "Tìm repo")
        .refreshable { await load() }
        .task {
            await session.refreshUser()
            await load()
        }
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    if !session.login.isEmpty { Text(session.login) }
                    Button("Đăng xuất", role: .destructive) { session.signOut() }
                } label: {
                    Image(systemName: "person.circle")
                }
            }
        }
    }

    private func load() async {
        if loading { return }
        loading = true
        defer { loading = false }
        do {
            repos = try await session.api.repos()
            error = nil
        } catch let e {
            error = e.localizedDescription
        }
    }
}

struct RepoRow: View {
    let repo: Repo

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(spacing: 6) {
                if repo.isPrivate {
                    Image(systemName: "lock.fill").font(.caption).foregroundStyle(.secondary)
                }
                Text(repo.fullName).font(.subheadline.weight(.semibold))
            }
            if let d = repo.description, !d.isEmpty {
                Text(d).font(.caption).foregroundStyle(.secondary).lineLimit(2)
            }
            Text([repo.language ?? "", relative(repo.updatedAt)]
                    .filter { !$0.isEmpty }
                    .joined(separator: " · "))
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 2)
    }
}

// MARK: - Màn hình repo (Mã nguồn / Actions)

struct RepoView: View {
    let repo: Repo
    @EnvironmentObject var session: Session
    @State private var branch: String
    @State private var branches: [String] = []
    @State private var tab = 0

    init(repo: Repo) {
        self.repo = repo
        _branch = State(initialValue: repo.defaultBranch)
    }

    var body: some View {
        VStack(spacing: 0) {
            Picker("", selection: $tab) {
                Text("Mã nguồn").tag(0)
                Text("Actions").tag(1)
                Text("Lịch sử").tag(2)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal)
            .padding(.bottom, 8)

            if tab == 0 {
                FileBrowserView(repo: repo, branch: branch, path: "", isRoot: true)
            } else if tab == 1 {
                ActionsView(repo: repo, branch: branch)
            } else {
                CommitsView(repo: repo, branch: branch)
            }
        }
        .navigationTitle(repo.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    Picker("Nhánh", selection: $branch) {
                        ForEach(branches.isEmpty ? [branch] : branches, id: \.self) { b in
                            Text(b).tag(b)
                        }
                    }
                } label: {
                    Label(branch, systemImage: "arrow.triangle.branch")
                }
            }
        }
        .task {
            if let list = try? await session.api.branches(repo) {
                branches = list.map { $0.name }
            }
        }
    }
}

// MARK: - Duyệt file

struct FileBrowserView: View {
    let repo: Repo
    let branch: String
    let path: String
    var isRoot: Bool = false

    @EnvironmentObject var session: Session
    @EnvironmentObject var staging: Staging
    @State private var items: [ContentItem] = []
    @State private var loading = false
    @State private var working = false
    @State private var error: String?
    @State private var askName = false
    @State private var newName = ""
    @State private var goNew = false
    @State private var newPath = ""
    @State private var readmeName = ""
    @State private var readmeText: String?
    @State private var showFileImport = false
    @State private var showFolderImport = false
    @State private var showZipImport = false
    @State private var batch: UploadBatch?
    @State private var showPack = false
    @State private var renameItem: ContentItem?
    @State private var renameText = ""
    @State private var showRename = false
    @State private var deleteItem: ContentItem?
    @State private var showDelete = false
    @State private var toast: String?
    @State private var pendingToast: String?

    private var key: String { Staging.key(repo, branch) }
    private var stagedCount: Int { staging.count(key) }

    private var title: String {
        path.isEmpty ? repo.name : (path as NSString).lastPathComponent
    }

    var body: some View {
        List {
            if let error = error {
                Text(error).font(.footnote).foregroundStyle(.secondary)
            }
            ForEach(items) { item in
                Group {
                    if item.type == "dir" {
                        NavigationLink {
                            FileBrowserView(repo: repo, branch: branch, path: item.path)
                        } label: {
                            Label(item.name, systemImage: "folder.fill")
                        }
                    } else {
                        NavigationLink {
                            FileEditorView(repo: repo, branch: branch, path: item.path, isNew: false)
                        } label: {
                            HStack {
                                Label(item.name, systemImage: icon(for: item.name))
                                Spacer()
                                Text(sizeText(item.size))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                .swipeActions(edge: .trailing) {
                    Button(role: .destructive) {
                        askDelete(item)
                    } label: {
                        Label("Xóa", systemImage: "trash")
                    }
                    Button {
                        askRename(item)
                    } label: {
                        Label("Đổi tên", systemImage: "pencil")
                    }
                    .tint(.blue)
                }
                .contextMenu {
                    Button {
                        askRename(item)
                    } label: {
                        Label("Đổi tên / di chuyển", systemImage: "pencil")
                    }
                    Button(role: .destructive) {
                        askDelete(item)
                    } label: {
                        Label("Xóa", systemImage: "trash")
                    }
                }
            }
            if let md = readmeText {
                Section {
                    MarkdownView(text: md).padding(.vertical, 6)
                } header: {
                    Label(readmeName, systemImage: "book")
                }
            }
        }
        .listStyle(.plain)
        .overlay {
            if (loading && items.isEmpty) || working { ProgressView() }
        }
        .navigationTitle(isRoot ? repo.name : title)
        .navigationBarTitleDisplayMode(.inline)
        .refreshable { await load() }
        .task(id: branch) { await load() }
        .onAppear {
            if !items.isEmpty { Task { await load(silent: true) } }
        }
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                if stagedCount > 0 {
                    Button {
                        showPack = true
                    } label: {
                        Label("\(stagedCount)", systemImage: "tray.full")
                    }
                }
                Menu {
                    Button {
                        newName = ""
                        askName = true
                    } label: {
                        Label("Tạo file mới", systemImage: "doc.badge.plus")
                    }
                    Button {
                        showFileImport = true
                    } label: {
                        Label("Tải file lên", systemImage: "square.and.arrow.up")
                    }
                    Button {
                        showFolderImport = true
                    } label: {
                        Label("Tải thư mục lên", systemImage: "folder.badge.plus")
                    }
                    Button {
                        showZipImport = true
                    } label: {
                        Label("Tải zip lên và giải nén", systemImage: "doc.zipper")
                    }
                    if stagedCount > 0 {
                        Button {
                            showPack = true
                        } label: {
                            Label("Gói commit (\(stagedCount))", systemImage: "tray.full")
                        }
                    }
                } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .alert("Tạo file mới", isPresented: $askName) {
            TextField("ten-file.txt", text: $newName)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Button("Hủy", role: .cancel) {}
            Button("Tạo") {
                let n = newName.trimmingCharacters(in: .whitespaces)
                if !n.isEmpty {
                    newPath = path.isEmpty ? n : path + "/" + n
                    goNew = true
                }
            }
        } message: {
            Text("Gõ thư-mục/ten-file để tạo luôn thư mục mới.")
        }
        .alert("Đổi tên / di chuyển", isPresented: $showRename) {
            TextField("thư-mục/tên-mới", text: $renameText)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Button("Hủy", role: .cancel) {}
            Button("Thêm vào gói") { applyRename(now: false) }
            Button("Commit ngay") { applyRename(now: true) }
        } message: {
            Text("Sửa đường dẫn đầy đủ. Đổi thư mục cha nghĩa là chuyển sang nơi khác.")
        }
        .alert("Xóa \(deleteItem?.name ?? "")?", isPresented: $showDelete) {
            Button("Hủy", role: .cancel) {}
            Button("Thêm vào gói") { applyDelete(now: false) }
            Button("Xóa và commit", role: .destructive) { applyDelete(now: true) }
        } message: {
            Text(deleteItem?.type == "dir"
                 ? "Toàn bộ file trong thư mục này sẽ bị xóa."
                 : "File sẽ bị xóa khỏi nhánh \(branch).")
        }
        .alert("Thông báo", isPresented: Binding(
            get: { toast != nil },
            set: { if !$0 { toast = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(toast ?? "")
        }
        .fileImporter(isPresented: $showFileImport,
                      allowedContentTypes: [.item],
                      allowsMultipleSelection: true) { handleImport($0, unzip: false) }
        .background(
            Color.clear.fileImporter(isPresented: $showFolderImport,
                                     allowedContentTypes: [.folder],
                                     allowsMultipleSelection: true) { handleImport($0, unzip: false) }
        )
        .background(
            Color.clear.fileImporter(isPresented: $showZipImport,
                                     allowedContentTypes: [.zip],
                                     allowsMultipleSelection: true) { handleImport($0, unzip: true) }
        )
        .sheet(item: $batch, onDismiss: afterSheet) { b in
            UploadSheet(repo: repo, branch: branch, dir: path, batch: b) { msg in
                pendingToast = msg
            }
        }
        .sheet(isPresented: $showPack, onDismiss: afterSheet) {
            StagedChangesView(repo: repo, branch: branch) { msg in
                pendingToast = msg
            }
        }
        .navigationDestination(isPresented: $goNew) {
            FileEditorView(repo: repo, branch: branch, path: newPath, isNew: true)
        }
    }

    private func icon(for name: String) -> String {
        switch (name as NSString).pathExtension.lowercased() {
        case "swift": return "swift"
        case "md", "txt": return "doc.text"
        case "yml", "yaml", "json", "plist": return "gearshape"
        case "png", "jpg", "jpeg", "gif", "webp": return "photo"
        default: return "doc"
        }
    }

    // MARK: Thao tác

    private func afterSheet() {
        if let t = pendingToast {
            toast = t
            pendingToast = nil
        }
        Task { await load(silent: true) }
    }

    private func handleImport(_ result: Result<[URL], Error>, unzip: Bool) {
        switch result {
        case .failure(let e):
            toast = e.localizedDescription
        case .success(let urls):
            Task {
                let b = await Task.detached { UploadReader.read(urls, unzip: unzip) }.value
                if b.files.isEmpty {
                    toast = b.notes.first ?? "Không đọc được file nào."
                } else {
                    batch = b
                }
            }
        }
    }

    private func askRename(_ item: ContentItem) {
        renameItem = item
        renameText = item.path
        showRename = true
    }

    private func askDelete(_ item: ContentItem) {
        deleteItem = item
        showDelete = true
    }

    private func applyRename(now: Bool) {
        guard let item = renameItem else { return }
        let to = renameText.trimmingCharacters(in: CharacterSet(charactersIn: "/ \n"))
        let isDir = item.type == "dir"
        if to.isEmpty || to == item.path { return }
        if isDir && (to + "/").hasPrefix(item.path + "/") {
            toast = "Không thể chuyển thư mục vào chính nó."
            return
        }
        let ch = Change.move(from: item.path, to: to, isDir: isDir)
        if now {
            Task { await commitNow([ch], "Đổi tên \(item.name) → \(to)") }
        } else {
            staging.add(ch, key: key)
            toast = "Đã thêm vào gói commit (\(staging.count(key)) thay đổi)."
        }
    }

    private func applyDelete(now: Bool) {
        guard let item = deleteItem else { return }
        let ch = Change.delete(path: item.path, isDir: item.type == "dir")
        if now {
            Task { await commitNow([ch], "Xóa \(item.name)") }
        } else {
            staging.add(ch, key: key)
            toast = "Đã thêm vào gói commit (\(staging.count(key)) thay đổi)."
        }
    }

    private func commitNow(_ changes: [Change], _ message: String) async {
        working = true
        defer { working = false }
        do {
            try await session.api.commitChanges(repo, branch: branch, message: message, changes: changes)
            toast = "Đã commit lên nhánh \(branch)."
            await load(silent: true)
        } catch let e {
            toast = e.localizedDescription
        }
    }

    private func load(silent: Bool = false) async {
        if !silent { loading = true }
        defer { loading = false }
        do {
            let list = try await session.api.listDir(repo, path: path, ref: branch)
            items = list.sorted { a, b in
                if (a.type == "dir") != (b.type == "dir") { return a.type == "dir" }
                return a.name.localizedCaseInsensitiveCompare(b.name) == .orderedAscending
            }
            error = nil
            if isRoot && !silent { await loadReadme() }
        } catch let e {
            error = e.localizedDescription
            if !silent { items = [] }
        }
    }

    private func loadReadme() async {
        let names = ["readme.md", "readme.markdown", "readme"]
        guard let rd = items.first(where: { $0.type == "file" && names.contains($0.name.lowercased()) }),
              rd.size > 0, rd.size < 120_000 else {
            readmeText = nil
            return
        }
        if let f = try? await session.api.file(repo, path: rd.path, ref: branch),
           let s = String(data: f.data, encoding: .utf8) {
            readmeName = rd.name
            readmeText = s
        } else {
            readmeText = nil
        }
    }
}
