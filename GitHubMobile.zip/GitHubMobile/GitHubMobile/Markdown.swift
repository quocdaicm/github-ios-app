import SwiftUI

// MARK: - Bộ phân tích Markdown (đủ dùng cho README)

enum MDBlock {
    case heading(Int, String)
    case paragraph(String)
    case code(String)
    case item(Int, String, String)   // cấp thụt lề, ký hiệu đầu dòng, nội dung
    case quote(String)
    case rule
    case table([[String]])
}

enum MDParser {
    static func parse(_ src: String) -> [MDBlock] {
        var blocks: [MDBlock] = []
        var para: [String] = []
        var code: [String] = []
        var table: [[String]] = []
        var inCode = false

        func flushPara() {
            if !para.isEmpty {
                let joined = para.joined(separator: " ")
                // Bỏ dòng chỉ có ảnh/huy hiệu (badge)
                if !(joined.hasPrefix("![") || joined.hasPrefix("[![")) {
                    blocks.append(.paragraph(joined))
                }
                para = []
            }
        }
        func flushTable() {
            if !table.isEmpty {
                blocks.append(.table(table))
                table = []
            }
        }

        let lines = src.replacingOccurrences(of: "\r", with: "").components(separatedBy: "\n")
        for line in lines {
            let t = line.trimmingCharacters(in: .whitespaces)

            if inCode {
                if t.hasPrefix("```") || t.hasPrefix("~~~") {
                    blocks.append(.code(code.joined(separator: "\n")))
                    code = []
                    inCode = false
                } else {
                    code.append(line)
                }
                continue
            }
            if t.hasPrefix("```") || t.hasPrefix("~~~") {
                flushPara()
                flushTable()
                inCode = true
                continue
            }
            if t.isEmpty {
                flushPara()
                flushTable()
                continue
            }

            if t.hasPrefix("|") {
                flushPara()
                var cells = t.components(separatedBy: "|").map { $0.trimmingCharacters(in: .whitespaces) }
                if cells.first == "" { cells.removeFirst() }
                if cells.last == "" { cells.removeLast() }
                let isSeparator = !cells.isEmpty && cells.allSatisfy { c in
                    !c.isEmpty && c.allSatisfy { $0 == "-" || $0 == ":" }
                }
                if !isSeparator { table.append(cells) }
                continue
            }
            flushTable()

            if t.hasPrefix("<") { continue }   // thẻ HTML: bỏ qua

            if t.hasPrefix("#") {
                let hashes = t.prefix(while: { $0 == "#" }).count
                let rest = t.dropFirst(hashes)
                if hashes <= 6, rest.first == " " {
                    flushPara()
                    blocks.append(.heading(hashes, rest.trimmingCharacters(in: .whitespaces)))
                    continue
                }
            }

            if t.count >= 3, let f = t.first, "-*_".contains(f), t.allSatisfy({ $0 == f }) {
                flushPara()
                blocks.append(.rule)
                continue
            }

            if t.hasPrefix(">") {
                flushPara()
                let q = t.drop(while: { $0 == ">" || $0 == " " })
                blocks.append(.quote(String(q)))
                continue
            }

            if let item = listItem(t) {
                flushPara()
                let indent = line.prefix(while: { $0 == " " || $0 == "\t" }).count
                blocks.append(.item(min(indent / 2, 4), item.0, item.1))
                continue
            }

            para.append(t)
        }

        if inCode { blocks.append(.code(code.joined(separator: "\n"))) }
        flushPara()
        flushTable()
        return blocks
    }

    private static func listItem(_ t: String) -> (String, String)? {
        if t.count > 2, let f = t.first, "-*+".contains(f),
           t[t.index(after: t.startIndex)] == " " {
            var body = String(t.dropFirst(2))
            var marker = "•"
            if body.hasPrefix("[ ] ") {
                marker = "☐"
                body = String(body.dropFirst(4))
            } else if body.lowercased().hasPrefix("[x] ") {
                marker = "☑"
                body = String(body.dropFirst(4))
            }
            return (marker, body)
        }
        let digits = t.prefix(while: { $0.isNumber })
        if !digits.isEmpty, digits.count <= 3 {
            let rest = t.dropFirst(digits.count)
            if rest.hasPrefix(". ") || rest.hasPrefix(") ") {
                return ("\(digits).", String(rest.dropFirst(2)))
            }
        }
        return nil
    }
}

// MARK: - Hiển thị

struct MarkdownView: View {
    private let blocks: [MDBlock]

    init(text: String) {
        blocks = MDParser.parse(text)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ForEach(Array(blocks.enumerated()), id: \.offset) { pair in
                blockView(pair.element)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func inline(_ s: String) -> Text {
        let opts = AttributedString.MarkdownParsingOptions(interpretedSyntax: .inlineOnlyPreservingWhitespace)
        if let a = try? AttributedString(markdown: s, options: opts) {
            return Text(a)
        }
        return Text(s)
    }

    private func headingFont(_ level: Int) -> Font {
        switch level {
        case 1: return .title2.bold()
        case 2: return .title3.bold()
        case 3: return .headline
        default: return .subheadline.bold()
        }
    }

    @ViewBuilder
    private func blockView(_ b: MDBlock) -> some View {
        switch b {
        case .heading(let level, let s):
            inline(s)
                .font(headingFont(level))
                .padding(.top, level <= 2 ? 4 : 0)
        case .paragraph(let s):
            inline(s).font(.subheadline)
        case .code(let c):
            ScrollView(.horizontal, showsIndicators: false) {
                Text(c)
                    .font(.system(size: 12, design: .monospaced))
                    .padding(8)
                    .fixedSize(horizontal: true, vertical: false)
            }
            .background(Theme.codeBG)
            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .strokeBorder(Theme.border, lineWidth: 1)
            )
        case .item(let level, let marker, let s):
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Text(marker).font(.subheadline).foregroundStyle(.secondary)
                inline(s).font(.subheadline)
            }
            .padding(.leading, CGFloat(level) * 14)
        case .quote(let s):
            HStack(spacing: 8) {
                Rectangle()
                    .fill(Color.secondary.opacity(0.5))
                    .frame(width: 3)
                inline(s).font(.subheadline).foregroundStyle(.secondary)
            }
            .fixedSize(horizontal: false, vertical: true)
        case .rule:
            Divider()
        case .table(let rows):
            ScrollView(.horizontal, showsIndicators: false) {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(Array(rows.enumerated()), id: \.offset) { pair in
                        Text(pair.element.joined(separator: "  │  "))
                            .font(.system(size: 12, design: .monospaced))
                            .fontWeight(pair.offset == 0 ? .bold : .regular)
                    }
                }
                .padding(8)
            }
            .background(Theme.codeBG)
            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .strokeBorder(Theme.border, lineWidth: 1)
            )
        }
    }
}
