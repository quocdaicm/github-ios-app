import Foundation

struct APIError: LocalizedError {
    let message: String
    var statusCode: Int? = nil
    var errorDescription: String? { message }
}

// MARK: - Mô hình dữ liệu

struct GHErrDetail: Decodable {
    let message: String?
    enum Keys: String, CodingKey { case message }
    init(from decoder: Decoder) throws {
        if let c = try? decoder.singleValueContainer(), let s = try? c.decode(String.self) {
            message = s
            return
        }
        let k = try decoder.container(keyedBy: Keys.self)
        message = try k.decodeIfPresent(String.self, forKey: .message)
    }
}

struct GHMessage: Decodable {
    let message: String
    let detail: String?
    enum Keys: String, CodingKey { case message, errors }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: Keys.self)
        message = try c.decode(String.self, forKey: .message)
        var d: String? = nil
        if let arr = try? c.decode([GHErrDetail].self, forKey: .errors) {
            d = arr.compactMap { $0.message }.first
        }
        detail = d
    }
}
struct GHUser: Decodable { let login: String }

struct Owner: Decodable, Hashable { let login: String }

struct Repo: Decodable, Identifiable, Hashable {
    let id: Int
    let name: String
    let fullName: String
    let description: String?
    let defaultBranch: String
    let updatedAt: Date?
    let language: String?
    let isPrivate: Bool
    let owner: Owner
    let stargazersCount: Int?

    enum CodingKeys: String, CodingKey {
        case id, name, fullName, description, defaultBranch, updatedAt, language, owner, stargazersCount
        case isPrivate = "private"
    }
}

struct SearchReposResponse: Decodable { let items: [Repo] }

struct Branch: Decodable, Hashable { let name: String }

struct ContentItem: Decodable, Identifiable, Hashable {
    let name: String
    let path: String
    let type: String
    let size: Int
    var id: String { path }
}

struct FileMeta: Decodable {
    let sha: String
    let size: Int
    let content: String?
    let encoding: String?
}

struct RemoteFile {
    let sha: String
    let data: Data
}

struct PutResult: Decodable {
    struct Content: Decodable { let sha: String }
    let content: Content?
}

struct WorkflowRun: Decodable, Identifiable, Hashable {
    let id: Int
    let name: String?
    let displayTitle: String?
    let status: String?
    let conclusion: String?
    let headBranch: String?
    let event: String?
    let runNumber: Int
    let createdAt: Date?

    var title: String { displayTitle ?? name ?? "Run #\(runNumber)" }
}

struct RunsResponse: Decodable { let workflowRuns: [WorkflowRun] }

struct Workflow: Decodable, Identifiable, Hashable {
    let id: Int
    let name: String
    let path: String
    let state: String
}

struct WorkflowsResponse: Decodable { let workflows: [Workflow] }

struct Step: Decodable, Hashable {
    let name: String
    let status: String?
    let conclusion: String?
    let number: Int
    let startedAt: Date?
    let completedAt: Date?
}

struct Job: Decodable, Identifiable, Hashable {
    let id: Int
    let name: String
    let status: String?
    let conclusion: String?
    let startedAt: Date?
    let completedAt: Date?
    let steps: [Step]?
}

struct JobsResponse: Decodable { let jobs: [Job] }

struct Artifact: Decodable, Identifiable, Hashable {
    let id: Int
    let name: String
    let sizeInBytes: Int
    let expired: Bool
}

struct ArtifactsResponse: Decodable { let artifacts: [Artifact] }

struct GHCommit: Decodable, Identifiable, Hashable {
    struct Info: Decodable, Hashable {
        struct Person: Decodable, Hashable {
            let name: String?
            let date: Date?
        }
        let message: String
        let author: Person?
    }
    struct Author: Decodable, Hashable { let login: String? }

    let sha: String
    let commit: Info
    let author: Author?

    var id: String { sha }
    var shortSha: String { String(sha.prefix(7)) }
    var title: String {
        commit.message
            .split(separator: "\n", maxSplits: 1, omittingEmptySubsequences: true)
            .first.map(String.init) ?? commit.message
    }
    var authorName: String { author?.login ?? commit.author?.name ?? "-" }
    var date: Date? { commit.author?.date }
}

struct CommitFile: Decodable, Identifiable, Hashable {
    let filename: String
    let status: String
    let additions: Int
    let deletions: Int
    let patch: String?
    var id: String { filename }
}

struct CommitDetail: Decodable {
    let sha: String
    let commit: GHCommit.Info
    let files: [CommitFile]?
}

// MARK: - Chặn gửi token sang host khác khi chuyển hướng

final class RedirectGuard: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession,
                    task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest) async -> URLRequest? {
        var r = request
        if r.url?.host != task.originalRequest?.url?.host {
            r.setValue(nil, forHTTPHeaderField: "Authorization")
        }
        return r
    }
}

// MARK: - Client

struct GitHubAPI {
    let token: String
    /// Được gọi khi GitHub trả 401 (token sai/hết hạn)
    var onUnauthorized: (() -> Void)? = nil

    private static let decoder: JSONDecoder = {
        let d = JSONDecoder()
        d.keyDecodingStrategy = .convertFromSnakeCase
        d.dateDecodingStrategy = .iso8601
        return d
    }()

    private func makeRequest(_ path: String,
                             method: String = "GET",
                             query: [String: String] = [:],
                             body: [String: Any]? = nil,
                             accept: String = "application/vnd.github+json") throws -> URLRequest {
        var comps = URLComponents()
        comps.scheme = "https"
        comps.host = "api.github.com"
        comps.path = path
        if !query.isEmpty {
            comps.queryItems = query.map { URLQueryItem(name: $0.key, value: $0.value) }
        }
        guard let url = comps.url else { throw APIError(message: "Đường dẫn không hợp lệ") }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.timeoutInterval = 180
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        req.setValue(accept, forHTTPHeaderField: "Accept")
        req.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        if let body = body {
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        return req
    }

    private func check(_ data: Data, _ resp: URLResponse) throws {
        guard let http = resp as? HTTPURLResponse else {
            throw APIError(message: "Phản hồi không hợp lệ")
        }
        let code = http.statusCode
        if (200..<300).contains(code) { return }

        let decoded = try? Self.decoder.decode(GHMessage.self, from: data)
        var msg: String? = decoded?.message
        if let m = msg, let d = decoded?.detail { msg = m + " (" + d + ")" }
        if code == 401 {
            throw APIError(message: "Token không hợp lệ hoặc đã hết hạn. Hãy đăng nhập lại.", statusCode: 401)
        }

        let remaining = http.value(forHTTPHeaderField: "x-ratelimit-remaining")
        let retryAfter = http.value(forHTTPHeaderField: "retry-after")
        if code == 429 || (code == 403 && (remaining == "0" || retryAfter != nil)) {
            var text = "GitHub đang giới hạn số lần gọi API."
            if let ra = retryAfter, let secs = Int(ra) {
                text += " Thử lại sau \(secs) giây."
            } else if let reset = http.value(forHTTPHeaderField: "x-ratelimit-reset"),
                      let t = TimeInterval(reset) {
                let f = DateFormatter()
                f.dateFormat = "HH:mm"
                text += " Thử lại sau \(f.string(from: Date(timeIntervalSince1970: t)))."
            }
            throw APIError(message: text, statusCode: code)
        }
        throw APIError(message: msg ?? "Lỗi HTTP \(code)", statusCode: code)
    }

    func raw(_ path: String,
             method: String = "GET",
             query: [String: String] = [:],
             body: [String: Any]? = nil,
             accept: String = "application/vnd.github+json") async throws -> Data {
        let req = try makeRequest(path, method: method, query: query, body: body, accept: accept)
        let result: (Data, URLResponse)
        do {
            result = try await URLSession.shared.data(for: req, delegate: RedirectGuard())
        } catch let e as URLError where e.code != .cancelled {
            switch e.code {
            case .notConnectedToInternet, .networkConnectionLost:
                throw APIError(message: "Không có kết nối mạng.")
            case .timedOut:
                throw APIError(message: "Hết thời gian chờ, hãy thử lại.")
            default:
                throw APIError(message: e.localizedDescription)
            }
        }
        let data = result.0
        do {
            try check(data, result.1)
        } catch let e as APIError {
            if e.statusCode == 401 { onUnauthorized?() }
            throw e
        }
        return data
    }

    func get<T: Decodable>(_ path: String, query: [String: String] = [:]) async throws -> T {
        let data = try await raw(path, query: query)
        do {
            return try Self.decoder.decode(T.self, from: data)
        } catch let e {
            throw APIError(message: "Không đọc được dữ liệu từ GitHub: \(e.localizedDescription)")
        }
    }

    // MARK: Repo & mã nguồn

    func repos() async throws -> [Repo] {
        var all: [Repo] = []
        for page in 1...10 {
            let part: [Repo] = try await get("/user/repos", query: [
                "per_page": "100",
                "page": "\(page)",
                "sort": "updated",
                "affiliation": "owner,collaborator,organization_member"
            ])
            all += part
            if part.count < 100 { break }
        }
        return all
    }

    func branches(_ repo: Repo) async throws -> [Branch] {
        try await get("/repos/\(repo.fullName)/branches", query: ["per_page": "100"])
    }

    func listDir(_ repo: Repo, path: String, ref: String) async throws -> [ContentItem] {
        let p = "/repos/\(repo.fullName)/contents" + (path.isEmpty ? "" : "/" + path)
        return try await get(p, query: ["ref": ref])
    }

    func file(_ repo: Repo, path: String, ref: String) async throws -> RemoteFile {
        let p = "/repos/\(repo.fullName)/contents/\(path)"
        let meta: FileMeta = try await get(p, query: ["ref": ref])
        if meta.size == 0 {
            return RemoteFile(sha: meta.sha, data: Data())
        }
        if let c = meta.content, meta.encoding == "base64", !c.isEmpty {
            let cleaned = c.replacingOccurrences(of: "\n", with: "")
            if let d = Data(base64Encoded: cleaned) {
                return RemoteFile(sha: meta.sha, data: d)
            }
        }
        let d = try await raw(p, query: ["ref": ref], accept: "application/vnd.github.raw+json")
        return RemoteFile(sha: meta.sha, data: d)
    }

    func save(_ repo: Repo, path: String, data: Data, sha: String?, message: String, branch: String) async throws -> String? {
        var body: [String: Any] = [
            "message": message,
            "content": data.base64EncodedString(),
            "branch": branch
        ]
        if let sha = sha { body["sha"] = sha }
        let out = try await raw("/repos/\(repo.fullName)/contents/\(path)", method: "PUT", body: body)
        let r = try? Self.decoder.decode(PutResult.self, from: out)
        return r?.content?.sha
    }

    func delete(_ repo: Repo, path: String, sha: String, message: String, branch: String) async throws {
        let body: [String: Any] = ["message": message, "sha": sha, "branch": branch]
        _ = try await raw("/repos/\(repo.fullName)/contents/\(path)", method: "DELETE", body: body)
    }

    // MARK: Tạo repo mới

    func createRepo(name: String, description: String, isPrivate: Bool, autoInit: Bool) async throws -> Repo {
        let out = try await raw("/user/repos", method: "POST", body: [
            "name": name,
            "description": description,
            "private": isPrivate,
            "auto_init": autoInit
        ])
        do {
            return try Self.decoder.decode(Repo.self, from: out)
        } catch let e {
            throw APIError(message: "Đã tạo repo nhưng không đọc được phản hồi: \(e.localizedDescription)")
        }
    }

    // MARK: Tìm repo ngoài và fork

    func searchRepos(_ q: String, page: Int = 1) async throws -> [Repo] {
        let r: SearchReposResponse = try await get("/search/repositories", query: [
            "q": q, "per_page": "30", "page": "\(page)"
        ])
        return r.items
    }

    func repo(fullName: String) async throws -> Repo {
        try await get("/repos/\(fullName)")
    }

    /// Fork repo về tài khoản của mình (GitHub xử lý bất đồng bộ)
    func fork(_ repo: Repo) async throws -> Repo {
        let out = try await raw("/repos/\(repo.fullName)/forks", method: "POST", body: [:])
        do {
            return try Self.decoder.decode(Repo.self, from: out)
        } catch let e {
            throw APIError(message: "Đã gửi lệnh fork nhưng không đọc được phản hồi: \(e.localizedDescription)")
        }
    }

    /// Bản fork mặc định tắt Actions và workflow, nên bật lại (không bắt buộc thành công)
    func enableActions(_ repo: Repo) async {
        _ = try? await raw("/repos/\(repo.fullName)/actions/permissions", method: "PUT", body: ["enabled": true])
        if let r: WorkflowsResponse = try? await get("/repos/\(repo.fullName)/actions/workflows", query: ["per_page": "100"]) {
            for w in r.workflows where w.state != "active" {
                _ = try? await raw("/repos/\(repo.fullName)/actions/workflows/\(w.id)/enable", method: "PUT")
            }
        }
    }

    // MARK: Lịch sử commit

    func commits(_ repo: Repo, branch: String, page: Int) async throws -> [GHCommit] {
        try await get("/repos/\(repo.fullName)/commits", query: [
            "sha": branch,
            "per_page": "30",
            "page": "\(page)"
        ])
    }

    func commit(_ repo: Repo, sha: String) async throws -> CommitDetail {
        try await get("/repos/\(repo.fullName)/commits/\(sha)")
    }

    // MARK: Actions

    func runs(_ repo: Repo, branch: String?, page: Int = 1) async throws -> [WorkflowRun] {
        var q = ["per_page": "30", "page": "\(page)"]
        if let branch = branch { q["branch"] = branch }
        let r: RunsResponse = try await get("/repos/\(repo.fullName)/actions/runs", query: q)
        return r.workflowRuns
    }

    func run(_ repo: Repo, _ id: Int) async throws -> WorkflowRun {
        try await get("/repos/\(repo.fullName)/actions/runs/\(id)")
    }

    func workflows(_ repo: Repo) async throws -> [Workflow] {
        let r: WorkflowsResponse = try await get("/repos/\(repo.fullName)/actions/workflows", query: ["per_page": "100"])
        return r.workflows.filter { $0.state == "active" }
    }

    func dispatch(_ repo: Repo, workflowId: Int, ref: String, inputs: [String: String] = [:]) async throws {
        var body: [String: Any] = ["ref": ref]
        if !inputs.isEmpty { body["inputs"] = inputs }
        _ = try await raw("/repos/\(repo.fullName)/actions/workflows/\(workflowId)/dispatches",
                          method: "POST", body: body)
    }

    func jobs(_ repo: Repo, runId: Int) async throws -> [Job] {
        let r: JobsResponse = try await get("/repos/\(repo.fullName)/actions/runs/\(runId)/jobs", query: ["per_page": "100"])
        return r.jobs
    }

    func job(_ repo: Repo, _ id: Int) async throws -> Job {
        try await get("/repos/\(repo.fullName)/actions/jobs/\(id)")
    }

    func log(_ repo: Repo, jobId: Int) async throws -> String {
        let d = try await raw("/repos/\(repo.fullName)/actions/jobs/\(jobId)/logs", accept: "*/*")
        return String(decoding: d, as: UTF8.self)
    }

    func rerun(_ repo: Repo, runId: Int) async throws {
        _ = try await raw("/repos/\(repo.fullName)/actions/runs/\(runId)/rerun", method: "POST")
    }

    func rerunFailed(_ repo: Repo, runId: Int) async throws {
        _ = try await raw("/repos/\(repo.fullName)/actions/runs/\(runId)/rerun-failed-jobs", method: "POST")
    }

    func cancel(_ repo: Repo, runId: Int) async throws {
        _ = try await raw("/repos/\(repo.fullName)/actions/runs/\(runId)/cancel", method: "POST")
    }

    func deleteRun(_ repo: Repo, runId: Int) async throws {
        _ = try await raw("/repos/\(repo.fullName)/actions/runs/\(runId)", method: "DELETE")
    }

    func deleteArtifact(_ repo: Repo, id: Int) async throws {
        _ = try await raw("/repos/\(repo.fullName)/actions/artifacts/\(id)", method: "DELETE")
    }

    func artifacts(_ repo: Repo, runId: Int) async throws -> [Artifact] {
        let r: ArtifactsResponse = try await get("/repos/\(repo.fullName)/actions/runs/\(runId)/artifacts")
        return r.artifacts
    }

    func downloadArtifact(_ repo: Repo, _ a: Artifact) async throws -> URL {
        let req = try makeRequest("/repos/\(repo.fullName)/actions/artifacts/\(a.id)/zip", accept: "*/*")
        let (tmp, resp) = try await URLSession.shared.download(for: req, delegate: RedirectGuard())
        if let http = resp as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            if http.statusCode == 401 { onUnauthorized?() }
            throw APIError(message: "Tải artifact lỗi (HTTP \(http.statusCode))", statusCode: http.statusCode)
        }
        let dest = FileManager.default.temporaryDirectory.appendingPathComponent("\(a.name).zip")
        try? FileManager.default.removeItem(at: dest)
        try FileManager.default.moveItem(at: tmp, to: dest)
        return dest
    }
}
