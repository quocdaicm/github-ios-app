import SwiftUI
import Security

@main
struct GitHubMobileApp: App {
    @StateObject private var session = Session()
    @StateObject private var staging = Staging()
    @AppStorage("appearance") private var appearance = "dark"

    init() {
        Theme.applyAppearance()
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(session)
                .environmentObject(staging)
                .tint(Theme.accent)
                .preferredColorScheme(appearance == "system" ? nil : .dark)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var session: Session

    var body: some View {
        if session.token == nil {
            LoginView()
        } else {
            NavigationStack { RepoListView() }
        }
    }
}

// MARK: - Lưu token

enum TokenStore {
    private static let key = "github_token"
    private static let service = "GitHubMobile"

    private static func baseQuery() -> [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
            kSecAttrService as String: service
        ]
    }

    static func save(_ value: String) {
        SecItemDelete(baseQuery() as CFDictionary)
        var add = baseQuery()
        add[kSecValueData as String] = Data(value.utf8)
        add[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        let status = SecItemAdd(add as CFDictionary, nil)
        if status == errSecSuccess {
            UserDefaults.standard.removeObject(forKey: key)
        } else {
            // App cài không ký đôi khi không dùng được Keychain -> dự phòng
            UserDefaults.standard.set(value, forKey: key)
        }
    }

    static func load() -> String? {
        var q = baseQuery()
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: CFTypeRef?
        if SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
           let data = out as? Data,
           let s = String(data: data, encoding: .utf8) {
            return s
        }
        // Token còn nằm ở chỗ lưu dự phòng: thử chuyển vào Keychain
        if let legacy = UserDefaults.standard.string(forKey: key) {
            save(legacy)
            return legacy
        }
        return nil
    }

    static func clear() {
        SecItemDelete(baseQuery() as CFDictionary)
        UserDefaults.standard.removeObject(forKey: key)
    }
}

// MARK: - Phiên đăng nhập

final class Session: ObservableObject {
    @Published var token: String?
    @Published var login: String = ""
    @Published var notice: String?

    init() {
        token = TokenStore.load()
    }

    /// Đọc token ở bất kỳ luồng nào (chỉ đổi khi đăng nhập/đăng xuất)
    var api: GitHubAPI {
        GitHubAPI(token: token ?? "", onUnauthorized: { [weak self] in
            DispatchQueue.main.async { self?.expire() }
        })
    }

    func signIn(token t: String) async throws {
        let probe = GitHubAPI(token: t)
        let me: GHUser = try await probe.get("/user")
        TokenStore.save(t)
        await MainActor.run {
            self.login = me.login
            self.token = t
            self.notice = nil
        }
    }

    func refreshUser() async {
        guard login.isEmpty, token != nil else { return }
        if let me: GHUser = try? await api.get("/user") {
            await MainActor.run { self.login = me.login }
        }
    }

    func signOut() {
        TokenStore.clear()
        token = nil
        login = ""
        notice = nil
    }

    /// GitHub trả 401: xóa token và quay về màn đăng nhập
    func expire() {
        guard token != nil else { return }
        TokenStore.clear()
        token = nil
        login = ""
        notice = "Token hết hạn hoặc đã bị thu hồi. Hãy đăng nhập lại."
    }
}

// MARK: - Tiện ích chung

func relative(_ d: Date?) -> String {
    guard let d = d else { return "" }
    let f = RelativeDateTimeFormatter()
    f.locale = Locale(identifier: "vi_VN")
    f.unitsStyle = .short
    return f.localizedString(for: d, relativeTo: Date())
}

func sizeText(_ bytes: Int) -> String {
    ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
}

func durationText(_ a: Date?, _ b: Date?) -> String {
    guard let a = a, let b = b else { return "" }
    let s = max(0, Int(b.timeIntervalSince(a)))
    if s < 60 { return "\(s)s" }
    return "\(s / 60)p \(s % 60)s"
}
