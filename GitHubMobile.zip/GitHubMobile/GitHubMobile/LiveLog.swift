import SwiftUI

// MARK: - Log chạy trực tiếp ngay trong màn hình lần chạy

private enum LiveKind { case normal, group, error, warning, command }

private struct LiveLine: Identifiable {
    let id: Int
    let text: String
    let kind: LiveKind
}

private struct LiveDot: View {
    let active: Bool

    var body: some View {
        TimelineView(.animation) { ctx in
            let t = ctx.date.timeIntervalSinceReferenceDate
            Circle()
                .fill(active ? Theme.bad : Color.gray)
                .frame(width: 8, height: 8)
                .opacity(active ? 0.55 + 0.45 * sin(t * 5) : 0.6)
                .shadow(color: active ? Theme.bad : .clear, radius: 4)
        }
    }
}

struct LiveLogPanel: View {
    let repo: Repo
    let runId: Int
    let jobs: [Job]
    var onExpand: (Job) -> Void = { _ in }

    @EnvironmentObject var session: Session
    @State private var pick: Int?
    @State private var lines: [LiveLine] = []
    @State private var paused = false
    @State private var jobDone = false
    @State private var loaded = false
    @State private var waiting = false
    @State private var error: String?
    @State private var lastSize = 0

    private static let maxLines = 70
    private static let pollNanos: UInt64 = 4_000_000_000

    /// Job đang theo dõi: người dùng chọn, hoặc job đang chạy, hoặc job chưa xong đầu tiên
    private var job: Job? {
        if let p = pick, let j = jobs.first(where: { $0.id == p }) { return j }
        return jobs.first { $0.status == "in_progress" }
            ?? jobs.first { $0.status != "completed" }
            ?? jobs.last
    }

    private var currentStep: Step? {
        job?.steps?.first { $0.status == "in_progress" }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            header
            if let st = currentStep, !showFeed {
                HStack(spacing: 6) {
                    Image(systemName: "play.fill").font(.system(size: 8)).foregroundStyle(Theme.neon)
                    Text("Bước \(st.number): \(st.name)")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    Spacer(minLength: 4)
                    if let s = st.startedAt {
                        Text(s, style: .timer)
                            .font(.caption2.monospacedDigit())
                            .foregroundStyle(Theme.neon)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.top, 4)
            }

            if showFeed, let j = job {
                feed(j)
            } else {
                logScroll
            }
        }
        .environment(\.colorScheme, .dark)
        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Theme.terminalBG))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous)
            .strokeBorder(Theme.neon.opacity(0.28), lineWidth: 1))
        .shadow(color: Theme.neon.opacity(0.12), radius: 10)
        .padding(.horizontal, 14)
        .onChange(of: job?.status) { s in
            if s == "completed" { jobDone = true }
        }
        .task(id: job?.id) {
            lines = []
            lastSize = 0
            loaded = false
            waiting = false
            error = nil
            guard let id = job?.id else { return }
            jobDone = job?.status == "completed"
            // GitHub chỉ trả log khi job đã kết thúc, nên chỉ tải khi đó
            while !Task.isCancelled {
                if jobDone {
                    await refresh(id)
                    try? await Task.sleep(nanoseconds: 1_500_000_000)
                    await refresh(id)
                    break
                }
                try? await Task.sleep(nanoseconds: 2_000_000_000)
            }
        }
    }


    /// Nội dung log thật (chỉ có sau khi job kết thúc)
    private var logScroll: some View {
        ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 1) {
                        if lines.isEmpty {
                            Text(placeholder)
                                .font(.system(size: 11, design: .monospaced))
                                .foregroundStyle(.secondary)
                        }
                        ForEach(lines) { l in
                            Text(l.text)
                                .font(.system(size: 10.5, design: .monospaced))
                                .foregroundStyle(color(for: l.kind))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .id(l.id)
                                .transition(.opacity)
                        }
                        TimelineView(.animation(minimumInterval: 0.5)) { ctx in
                            Text("▍")
                                .font(.system(size: 11, design: .monospaced))
                                .foregroundStyle(Theme.neon)
                                .opacity(Int(ctx.date.timeIntervalSinceReferenceDate * 2) % 2 == 0 ? 1 : 0.1)
                        }
                        .id("cursor")
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                }
                .onChange(of: lines.last?.id) { _ in
                    proxy.scrollTo("cursor", anchor: .bottom)
                }
            }
            .frame(height: 220)
    }

    // MARK: Tiến trình các bước (trực tiếp khi job đang chạy)

    private var showFeed: Bool {
        (job?.status ?? "completed") != "completed"
    }

    private func webURL(_ j: Job) -> URL? {
        URL(string: "https://github.com/\(repo.fullName)/actions/runs/\(runId)/job/\(j.id)")
    }

    private func feedMark(_ s: RunState) -> String {
        switch s {
        case .success: return "✓"
        case .failure: return "✗"
        case .running: return "▶"
        case .cancelled, .skipped: return "–"
        case .queued: return "·"
        case .other: return "!"
        }
    }

    private func feedRow(_ st: Step) -> some View {
        let s = RunState(status: st.status, conclusion: st.conclusion)
        return HStack(spacing: 6) {
            Text(feedMark(s)).foregroundStyle(s.color)
            Text(st.name).lineLimit(1)
            Spacer(minLength: 4)
            if s == .running, let t = st.startedAt {
                Text(t, style: .timer).monospacedDigit()
            } else {
                Text(durationText(st.startedAt, st.completedAt))
            }
        }
        .font(.system(size: 11, design: .monospaced))
        .foregroundStyle(s == .queued ? Color.secondary : (s == .running ? Theme.neon : Color.primary))
        .shadow(color: s == .running ? Theme.neon.opacity(0.6) : .clear, radius: 4)
    }

    private func feed(_ j: Job) -> some View {
        let steps = (j.steps ?? []).sorted { $0.number < $1.number }
        return ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 4) {
                    if steps.isEmpty {
                        Text("Đang chờ máy chạy nhận job...")
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundStyle(.secondary)
                    }
                    ForEach(steps, id: \.number) { st in
                        feedRow(st).id(st.number)
                    }
                    VStack(alignment: .leading, spacing: 6) {
                        Text("GitHub chỉ cho tải log sau khi job kết thúc. Danh sách bước ở trên cập nhật trực tiếp.")
                            .font(.system(size: 10))
                            .foregroundStyle(.secondary)
                        if let url = webURL(j) {
                            Link(destination: url) {
                                Label("Xem log trực tiếp trên web", systemImage: "safari")
                                    .font(.caption2.weight(.semibold))
                            }
                        }
                    }
                    .padding(.top, 8)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
            }
            .onChange(of: currentStep?.number) { n in
                if let n = n {
                    withAnimation(.easeInOut(duration: 0.3)) { proxy.scrollTo(n, anchor: .center) }
                }
            }
        }
        .frame(height: 220)
    }

    // MARK: Thanh tiêu đề

    private var header: some View {
        HStack(spacing: 8) {
            LiveDot(active: !paused && !jobDone)
            Text(paused ? "TẠM DỪNG" : (jobDone ? "ĐÃ XONG" : "TRỰC TIẾP"))
                .font(.caption2.weight(.heavy))
                .foregroundStyle(paused ? Theme.warn : (jobDone ? Color.secondary : Theme.neon))

            if jobs.count > 1 {
                Menu {
                    ForEach(jobs) { j in
                        Button {
                            pick = j.id
                        } label: {
                            Text(j.name)
                        }
                    }
                } label: {
                    HStack(spacing: 3) {
                        Text(job?.name ?? "").lineLimit(1)
                        Image(systemName: "chevron.up.chevron.down").font(.system(size: 8))
                    }
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                }
            } else {
                Text(job?.name ?? "")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }

            Spacer()

            if !showFeed {
                Button {
                    Haptics.tap()
                    paused.toggle()
                } label: {
                    Image(systemName: paused ? "play.fill" : "pause.fill")
                        .font(.system(size: 13))
                        .frame(width: 28, height: 28)
                }
                .buttonStyle(PressableStyle())
            }

            Button {
                if let j = job {
                    Haptics.tap()
                    onExpand(j)
                }
            } label: {
                Image(systemName: "arrow.up.left.and.arrow.down.right")
                    .font(.system(size: 12))
                    .frame(width: 28, height: 28)
            }
            .buttonStyle(PressableStyle())
        }
        .padding(.horizontal, 12)
        .padding(.top, 8)
    }

    private var placeholder: String {
        if let e = error { return e }
        if waiting || !loaded { return "Đang tải log..." }
        return "Log trống."
    }

    private func color(for k: LiveKind) -> Color {
        switch k {
        case .normal: return Color.white.opacity(0.8)
        case .group: return Theme.neon
        case .error: return Theme.bad
        case .warning: return Theme.warn
        case .command: return Theme.accent.opacity(0.9)
        }
    }

    // MARK: Tải và phân tích log

    private func refresh(_ id: Int) async {
        do {
            let raw = try await session.api.log(repo, jobId: id)
            let size = raw.utf8.count
            if loaded && size == lastSize { return }
            lastSize = size
            let parsed = LiveLogPanel.tail(raw, LiveLogPanel.maxLines)
            withAnimation(.easeOut(duration: 0.25)) { lines = parsed }
            loaded = true
            waiting = false
            error = nil
        } catch let e {
            if Task.isCancelled { return }
            if let a = e as? APIError, a.statusCode == 404 {
                waiting = true   // job vừa bắt đầu, GitHub chưa có log
            } else if !loaded {
                error = e.localizedDescription
            }
        }
    }

    private static func stripStamp(_ l: Substring) -> String {
        if l.hasPrefix("20"),
           let sp = l.firstIndex(of: " "),
           l.distance(from: l.startIndex, to: sp) <= 32 {
            let head = l[l.startIndex..<sp]
            if head.hasSuffix("Z") && head.contains("T") {
                return String(l[l.index(after: sp)...])
            }
        }
        return String(l)
    }

    private static func tail(_ raw: String, _ n: Int) -> [LiveLine] {
        let clean = raw
            .replacingOccurrences(of: "\u{FEFF}", with: "")
            .replacingOccurrences(of: "\r", with: "")
            .replacingOccurrences(of: "\u{1B}\\[[0-9;]*[A-Za-z]", with: "", options: .regularExpression)
        let all = clean.split(separator: "\n", omittingEmptySubsequences: true)
        let start = max(0, all.count - n - 10)
        var out: [LiveLine] = []
        for i in start..<all.count {
            var text = stripStamp(all[i])
            if text.hasPrefix("##[endgroup]") { continue }
            var kind = LiveKind.normal
            let low = text.lowercased()
            if text.hasPrefix("##[group]") {
                kind = .group
                text = "▸ " + text.dropFirst("##[group]".count)
            } else if low.contains("##[error]") || low.contains("error:") || low.contains("** build failed") {
                kind = .error
            } else if low.contains("##[warning]") || low.contains("warning:") {
                kind = .warning
            } else if text.hasPrefix("[command]") {
                kind = .command
            }
            out.append(LiveLine(id: i, text: text, kind: kind))
        }
        return Array(out.suffix(n))
    }
}
