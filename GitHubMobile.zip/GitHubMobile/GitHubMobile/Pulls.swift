import SwiftUI

// MARK: - Mô hình Pull request / Issue

struct IssueUser: Decodable, Hashable { let login: String }

struct IssueItem: Decodable, Identifiable, Hashable {
    struct PRRef: Decodable, Hashable { let url: String? }

    let number: Int
    let title: String
    let state: String
    let body: String?
    let user: IssueUser?
    let createdAt: Date?
    let comments: Int
    let pullRequest: PRRef?

    var id: Int { number }
    var isPR: Bool { pullRequest != nil }
}

struct IssueComment: Decodable, Identifiable, Hashable {
    let id: Int
    let body: String?
    let user: IssueUser?
    let createdAt: Date?
}

struct PullInfo: Decodable {
    struct Ref: Decodable { let ref: String }
    let merged: Bool?
    let mergeable: Bool?
    let head: Ref
    let base: Ref
    let additions: Int?
    let deletions: Int?
    let changedFiles: Int?
}

// MARK: - API

extension GitHubAPI {
    /// GitHub trả cả issue lẫn pull request trong cùng danh sách này
    func issues(_ repo: Repo, state: String, page: Int) async throws -> [IssueItem] {
        try await get("/repos/\(repo.fullName)/issues", query: [
            "state": state, "per_page": "30", "page": "\(page)"
        ])
    }

    func issue(_ repo: Repo, number: Int) async throws -> IssueItem {
        try await get("/repos/\(repo.fullName)/issues/\(number)")
    }

    func issueComments(_ repo: Repo, number: Int) async throws -> [IssueComment] {
        try await get("/repos/\(repo.fullName)/issues/\(number)/comments", query: ["per_page": "100"])
    }

    func pullInfo(_ repo: Repo, number: Int) async throws -> PullInfo {
        try await get("/repos/\(repo.fullName)/pulls/\(number)")
    }

    func addComment(_ repo: Repo, number: Int, text: String) async throws {
        _ = try await raw("/repos/\(repo.fullName)/issues/\(number)/comments",
                          method: "POST", body: ["body": text])
    }

    func setIssueState(_ repo: Repo, number: Int, open: Bool) async throws {
        _ = try await raw("/repos/\(repo.fullName)/issues/\(number)",
                          method: "PATCH", body: ["state": open ? "open" : "closed"])
    }

    func mergePull(_ repo: Repo, number: Int, method: String) async throws {
        _ = try await raw("/repos/\(repo.fullName)/pulls/\(number)/merge",
                          method: "PUT", body: ["merge_method": method])
    }

    func pullFiles(_ repo: Repo, number: Int) async throws -> [CommitFile] {
        try await get("/repos/\(repo.fullName)/pulls/\(number)/files", query: ["per_page": "100"])
    }

    func createIssue(_ repo: Repo, title: String) async throws {
        _ = try await raw("/repos/\(repo.fullName)/issues", method: "POST", body: ["title": title])
    }
}

// MARK: - Danh sách

struct PullsIssuesView: View {
    let repo: Repo

    @EnvironmentObject var session: Session
    @State private var kind = 0              // 0: pull request, 1: issue
    @State private var stateFilter = "open"
    @State private var all: [IssueItem] = []
    @State private var page = 1
    @State private var hasMore = false
    @State private var loading = false
    @State private var error: String?
    @State private var showNew = false
    @State private var newTitle = ""
    @State private var toast: String?

    private let pageSize = 30

    private var shown: [IssueItem] {
        all.filter { kind == 0 ? $0.isPR : !$0.isPR }
    }

    var body: some View {
        List {
            Picker("", selection: $kind) {
                Text("Pull request").tag(0)
                Text("Issue").tag(1)
            }
            .pickerStyle(.segmented)
            .listRowBackground(Color.clear)
            .listRowSeparator(.hidden)

            if let error = error {
                Text(error).font(.footnote).foregroundStyle(.secondary)
            }

            if shown.isEmpty && !loading && error == nil {
                Text(kind == 0 ? "Không có pull request nào." : "Không có issue nào.")
                    .foregroundStyle(.secondary)
                    .listRowBackground(Color.clear)
            }

            ForEach(shown) { it in
                NavigationLink {
                    IssueDetailView(repo: repo, item: it) {
                        Task { await reload() }
                    }
                } label: {
                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 6) {
                            Chip(text: it.state == "open" ? "Mở" : "Đã đóng",
                                 icon: it.isPR ? "arrow.triangle.pull" : "circle.dotted",
                                 color: it.state == "open" ? .green : .purple)
                            Text("#\(it.number)").font(.caption).foregroundStyle(.secondary)
                        }
                        Text(it.title).font(.subheadline.weight(.semibold))
                        Text("\(it.user?.login ?? "-") · \(relative(it.createdAt))"
                             + (it.comments > 0 ? " · \(it.comments) bình luận" : ""))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .cardRow()
            }

            if hasMore {
                ProgressView()
                    .frame(maxWidth: .infinity)
                    .listRowBackground(Color.clear)
                    .onAppear { Task { await loadMore() } }
            }
        }
        .listStyle(.plain)
        .themedList()
        .overlay {
            if loading && all.isEmpty { ProgressView() }
        }
        .refreshable { await reload() }
        .task(id: stateFilter) { await reload() }
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                Menu {
                    Picker("Trạng thái", selection: $stateFilter) {
                        Text("Đang mở").tag("open")
                        Text("Đã đóng").tag("closed")
                    }
                    Button {
                        newTitle = ""
                        showNew = true
                    } label: {
                        Label("Tạo issue", systemImage: "plus.circle")
                    }
                } label: {
                    Image(systemName: "line.3.horizontal.decrease.circle")
                }
            }
        }
        .alert("Tạo issue mới", isPresented: $showNew) {
            TextField("Tiêu đề", text: $newTitle)
            Button("Hủy", role: .cancel) {}
            Button("Tạo") { Task { await create() } }
        }
        .alert("Thông báo", isPresented: Binding(
            get: { toast != nil },
            set: { if !$0 { toast = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(toast ?? "")
        }
    }

    private func reload() async {
        loading = true
        defer { loading = false }
        do {
            let first = try await session.api.issues(repo, state: stateFilter, page: 1)
            all = first
            page = 1
            hasMore = first.count >= pageSize
            error = nil
        } catch let e {
            if !(e is CancellationError) { error = e.localizedDescription }
        }
    }

    private func loadMore() async {
        if loading { return }
        loading = true
        defer { loading = false }
        do {
            let next = try await session.api.issues(repo, state: stateFilter, page: page + 1)
            let known = Set(all.map { $0.number })
            all += next.filter { !known.contains($0.number) }
            page += 1
            hasMore = next.count >= pageSize
        } catch let e {
            hasMore = false
            error = e.localizedDescription
        }
    }

    private func create() async {
        let t = newTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        do {
            try await session.api.createIssue(repo, title: t)
            toast = "Đã tạo issue."
            await reload()
        } catch let e {
            toast = e.localizedDescription
        }
    }
}

// MARK: - Chi tiết

struct IssueDetailView: View {
    let repo: Repo
    var onChanged: () -> Void = {}

    @EnvironmentObject var session: Session
    @State private var item: IssueItem
    @State private var comments: [IssueComment] = []
    @State private var pull: PullInfo?
    @State private var files: [CommitFile] = []
    @State private var newComment = ""
    @State private var busy = false
    @State private var toast: String?
    @State private var pickMerge = false

    init(repo: Repo, item: IssueItem, onChanged: @escaping () -> Void = {}) {
        self.repo = repo
        self.onChanged = onChanged
        _item = State(initialValue: item)
    }

    private var isOpen: Bool { item.state == "open" }

    private var canMerge: Bool {
        item.isPR && isOpen && pull?.merged != true && pull?.mergeable != false
    }

    var body: some View {
        List {
            Section {
                Text(item.title).font(.headline)
                HStack(spacing: 6) {
                    Chip(text: pull?.merged == true ? "Đã gộp" : (isOpen ? "Mở" : "Đã đóng"),
                         icon: item.isPR ? "arrow.triangle.pull" : "circle.dotted",
                         color: pull?.merged == true ? .purple : (isOpen ? .green : .red))
                    Text("#\(item.number) · \(item.user?.login ?? "-") · \(relative(item.createdAt))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                if let p = pull {
                    Text("\(p.head.ref) → \(p.base.ref)")
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)
                    if let f = p.changedFiles, let a = p.additions, let d = p.deletions {
                        Text("\(f) file · +\(a) −\(d)").font(.caption).foregroundStyle(.secondary)
                    }
                    if p.mergeable == false && isOpen {
                        Text("Có xung đột, chưa gộp được.").font(.caption).foregroundStyle(.orange)
                    }
                }
            }

            if let b = item.body, !b.isEmpty {
                Section {
                    MarkdownView(text: b)
                }
            }

            if !files.isEmpty {
                Section("Thay đổi (\(files.count) file)") {
                    ForEach(files) { f in
                        NavigationLink {
                            DiffView(file: f)
                        } label: {
                            FileChangeRow(file: f)
                        }
                    }
                }
            }

            if !comments.isEmpty {
                Section("Bình luận") {
                    ForEach(comments) { c in
                        VStack(alignment: .leading, spacing: 6) {
                            Text("\(c.user?.login ?? "-") · \(relative(c.createdAt))")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.secondary)
                            MarkdownView(text: c.body ?? "")
                        }
                    }
                }
            }

            Section("Viết bình luận") {
                TextField("Nội dung...", text: $newComment, axis: .vertical)
                    .lineLimit(2...8)
                Button {
                    Task { await send() }
                } label: {
                    Label("Gửi", systemImage: "paperplane")
                }
                .disabled(busy || newComment.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
        .themedList()
        .navigationTitle("#\(item.number)")
        .navigationBarTitleDisplayMode(.inline)
        .overlay { if busy { ProgressView() } }
        .refreshable { await load() }
        .task { await load() }
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                Menu {
                    if canMerge {
                        Button { pickMerge = true } label: {
                            Label("Gộp pull request", systemImage: "arrow.triangle.merge")
                        }
                    }
                    if pull?.merged != true {
                        Button {
                            Task { await setState(open: !isOpen) }
                        } label: {
                            Label(isOpen ? "Đóng" : "Mở lại",
                                  systemImage: isOpen ? "xmark.circle" : "arrow.counterclockwise")
                        }
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
                .disabled(busy)
            }
        }
        .confirmationDialog("Gộp pull request #\(item.number)", isPresented: $pickMerge, titleVisibility: .visible) {
            Button("Merge commit") { Task { await merge("merge") } }
            Button("Squash") { Task { await merge("squash") } }
            Button("Rebase") { Task { await merge("rebase") } }
            Button("Hủy", role: .cancel) {}
        }
        .alert("Thông báo", isPresented: Binding(
            get: { toast != nil },
            set: { if !$0 { toast = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(toast ?? "")
        }
    }

    private func load() async {
        do {
            let fresh = try await session.api.issue(repo, number: item.number)
            item = fresh
            comments = try await session.api.issueComments(repo, number: item.number)
            if item.isPR {
                pull = try? await session.api.pullInfo(repo, number: item.number)
                files = (try? await session.api.pullFiles(repo, number: item.number)) ?? []
            }
        } catch let e {
            if !(e is CancellationError) { toast = e.localizedDescription }
        }
    }

    private func send() async {
        let t = newComment.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        busy = true
        defer { busy = false }
        do {
            try await session.api.addComment(repo, number: item.number, text: t)
            newComment = ""
            comments = try await session.api.issueComments(repo, number: item.number)
        } catch let e {
            toast = e.localizedDescription
        }
    }

    private func setState(open: Bool) async {
        busy = true
        defer { busy = false }
        do {
            try await session.api.setIssueState(repo, number: item.number, open: open)
            await load()
            onChanged()
        } catch let e {
            toast = e.localizedDescription
        }
    }

    private func merge(_ method: String) async {
        busy = true
        defer { busy = false }
        do {
            try await session.api.mergePull(repo, number: item.number, method: method)
            toast = "Đã gộp pull request."
            await load()
            onChanged()
        } catch let e {
            toast = e.localizedDescription
        }
    }
}
