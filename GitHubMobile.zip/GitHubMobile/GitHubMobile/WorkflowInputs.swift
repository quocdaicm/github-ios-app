import SwiftUI

// MARK: - Đọc inputs của workflow_dispatch từ file YAML

struct WorkflowInput: Identifiable {
    let name: String
    var description: String
    var type: String          // string, boolean, choice, number, environment
    var options: [String]
    var required: Bool
    var defaultValue: String
    var id: String { name }
}

/// Bộ đọc YAML tối giản, chỉ dành cho khối `on: workflow_dispatch: inputs:`
enum WorkflowYAML {
    private struct YLine {
        let indent: Int
        let text: String
    }

    /// nil: workflow không có workflow_dispatch. []: có nhưng không có inputs.
    static func dispatchInputs(_ yaml: String) -> [WorkflowInput]? {
        let ls = lines(yaml)
        guard let onIdx = ls.firstIndex(where: { $0.indent == 0 && keyOf($0.text) == "on" }),
              let onKV = split(ls[onIdx].text) else { return nil }

        // on: workflow_dispatch   hoặc   on: [push, workflow_dispatch]
        if !onKV.1.isEmpty {
            return onKV.1.contains("workflow_dispatch") ? [] : nil
        }

        let body = children(ls, onIdx)
        guard let first = body.first else { return nil }
        if body.contains(where: { $0.text == "- workflow_dispatch" }) { return [] }

        guard let wdIdx = body.firstIndex(where: {
            $0.indent == first.indent && keyOf($0.text) == "workflow_dispatch"
        }) else { return nil }
        if let kv = split(body[wdIdx].text), !kv.1.isEmpty { return [] }

        let wd = children(body, wdIdx)
        guard let wfirst = wd.first,
              let inIdx = wd.firstIndex(where: {
                  $0.indent == wfirst.indent && keyOf($0.text) == "inputs"
              }) else { return [] }

        let inputs = children(wd, inIdx)
        guard let ifirst = inputs.first else { return [] }

        var result: [WorkflowInput] = []
        for (idx, line) in inputs.enumerated() where line.indent == ifirst.indent {
            guard let name = keyOf(line.text), !name.isEmpty else { continue }
            result.append(parseInput(name: name, props: children(inputs, idx)))
        }
        return result
    }

    private static func parseInput(name: String, props: [YLine]) -> WorkflowInput {
        var inp = WorkflowInput(name: name, description: "", type: "string",
                                options: [], required: false, defaultValue: "")
        guard let pfirst = props.first else { return inp }
        var i = 0
        while i < props.count {
            let p = props[i]
            i += 1
            guard p.indent == pfirst.indent, let kv = split(p.text) else { continue }
            switch kv.0 {
            case "description":
                let v = unquote(kv.1)
                inp.description = ["|", ">", "|-", ">-"].contains(v) ? "" : v
            case "type":
                inp.type = unquote(kv.1)
            case "required":
                inp.required = unquote(kv.1) == "true"
            case "default":
                inp.defaultValue = unquote(kv.1)
            case "options":
                if kv.1.hasPrefix("[") {
                    let inner = kv.1.dropFirst().dropLast()
                    inp.options = inner.split(separator: ",").map { unquote(String($0)) }
                } else {
                    while i < props.count, props[i].text.hasPrefix("- ") {
                        inp.options.append(unquote(String(props[i].text.dropFirst(2))))
                        i += 1
                    }
                }
            default:
                break
            }
        }
        return inp
    }

    // MARK: Tiện ích

    private static func lines(_ yaml: String) -> [YLine] {
        var out: [YLine] = []
        let all = yaml.replacingOccurrences(of: "\r", with: "").components(separatedBy: "\n")
        for raw in all {
            let s = stripComment(raw)
            let trimmed = s.trimmingCharacters(in: .whitespaces)
            if trimmed.isEmpty { continue }
            let indent = s.prefix(while: { $0 == " " }).count
            out.append(YLine(indent: indent, text: trimmed))
        }
        return out
    }

    private static func stripComment(_ s: String) -> String {
        var inSingle = false
        var inDouble = false
        var prev: Character = " "
        var result = ""
        for ch in s {
            if ch == "'" && !inDouble {
                inSingle.toggle()
            } else if ch == "\"" && !inSingle {
                inDouble.toggle()
            } else if ch == "#" && !inSingle && !inDouble && (prev == " " || result.isEmpty) {
                break
            }
            result.append(ch)
            prev = ch
        }
        return result
    }

    private static func children(_ arr: [YLine], _ idx: Int) -> [YLine] {
        var out: [YLine] = []
        var j = idx + 1
        while j < arr.count && arr[j].indent > arr[idx].indent {
            out.append(arr[j])
            j += 1
        }
        return out
    }

    private static func split(_ t: String) -> (String, String)? {
        if t.hasPrefix("- ") { return nil }
        guard let i = t.firstIndex(of: ":") else { return nil }
        let k = unquote(String(t[t.startIndex..<i]))
        let v = String(t[t.index(after: i)...]).trimmingCharacters(in: .whitespaces)
        return (k, v)
    }

    private static func keyOf(_ t: String) -> String? {
        split(t)?.0
    }

    private static func unquote(_ s: String) -> String {
        var v = s.trimmingCharacters(in: .whitespaces)
        if v.count >= 2, let f = v.first, let l = v.last, f == l, f == "\"" || f == "'" {
            v = String(v.dropFirst().dropLast())
        }
        return v
    }
}

// MARK: - Form nhập inputs trước khi chạy

struct PendingDispatch: Identifiable {
    let id = UUID()
    let workflow: Workflow
    let inputs: [WorkflowInput]
}

struct DispatchSheet: View {
    let workflow: Workflow
    let branch: String
    let inputs: [WorkflowInput]
    let onRun: ([String: String]) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var values: [String: String] = [:]

    private var valid: Bool {
        inputs.allSatisfy { !$0.required || !(values[$0.name] ?? "").isEmpty }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Chạy trên nhánh \(branch)").foregroundStyle(.secondary)
                }
                ForEach(inputs) { inp in
                    Section {
                        field(inp)
                    } header: {
                        Text(inp.name + (inp.required ? " *" : ""))
                    } footer: {
                        if !inp.description.isEmpty { Text(inp.description) }
                    }
                }
            }
            .navigationTitle(workflow.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Hủy") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Chạy") {
                        onRun(values)
                        dismiss()
                    }
                    .disabled(!valid)
                }
            }
        }
        .onAppear {
            for inp in inputs where values[inp.name] == nil {
                values[inp.name] = initial(inp)
            }
        }
    }

    @ViewBuilder
    private func field(_ inp: WorkflowInput) -> some View {
        if inp.type == "boolean" {
            Toggle("Bật", isOn: boolBinding(inp.name))
        } else if inp.type == "choice" && !inp.options.isEmpty {
            Picker("Chọn", selection: binding(inp.name)) {
                ForEach(inp.options, id: \.self) { o in
                    Text(o).tag(o)
                }
            }
            .pickerStyle(.menu)
        } else {
            TextField(inp.name, text: binding(inp.name))
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(inp.type == "number" ? .decimalPad : .default)
        }
    }

    private func initial(_ inp: WorkflowInput) -> String {
        if !inp.defaultValue.isEmpty { return inp.defaultValue }
        if inp.type == "boolean" { return "false" }
        if inp.type == "choice" { return inp.options.first ?? "" }
        return ""
    }

    private func binding(_ name: String) -> Binding<String> {
        Binding(get: { values[name] ?? "" }, set: { values[name] = $0 })
    }

    private func boolBinding(_ name: String) -> Binding<Bool> {
        Binding(get: { (values[name] ?? "false") == "true" },
                set: { values[name] = $0 ? "true" : "false" })
    }
}
