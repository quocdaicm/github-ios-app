import SwiftUI
import UIKit


// MARK: - Chia sẻ file

struct SharedFile: Identifiable {
    let id = UUID()
    let url: URL
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

// MARK: - Xem / sửa file

struct FileEditorView: View {
    let repo: Repo
    let branch: String
    let path: String

    @EnvironmentObject var session: Session
    @EnvironmentObject var staging: Staging
    @Environment(\.dismiss) private var dismiss
    @StateObject private var editor = EditorController()

    @State private var isNew: Bool
    @State private var text = ""
    @State private var original = ""
    @State private var sha: String?
    @State private var loading = true
    @State private var error: String?
    @State private var imageData: Data?
    @State private var notText = false
    @State private var readOnly = false
    @State private var preview: Bool
    @State private var saving = false
    @State private var askCommit = false
    @State private var message = ""
    @State private var askDelete = false
    @State private var askDiscard = false
    @State private var conflict = false
    @State private var toast: String?
    @State private var commentView: String?
    @State private var translating = false
    @AppStorage("translateLang") private var langCode = "vi"
    @AppStorage("translateConsent") private var translateConsent = false
    @State private var askTranslateConsent = false
    @AppStorage("editorFontSize") private var editorFontSize = 13.0
    @AppStorage("editorTheme") private var editorTheme = "system"
    @Environment(\.colorScheme) private var sysScheme
    @State private var pdfData: Data?
    @State private var foldMode = false
    @State private var showSymbols = false
    @State private var symbols: [CodeSymbol] = []
    @State private var askLine = false
    @State private var lineText = ""

    /// true: xem repo của người khác, không cho sửa
    let viewOnly: Bool

    init(repo: Repo, branch: String, path: String, isNew: Bool, viewOnly: Bool = false) {
        self.viewOnly = viewOnly
        self.repo = repo
        self.branch = branch
        self.path = path
        _isNew = State(initialValue: isNew)
        _preview = State(initialValue: !isNew && (FileEditorView.isMarkdownName(path) || FileEditorView.isCSVName(path)))
    }

    private var name: String { (path as NSString).lastPathComponent }

    static func isMarkdownName(_ n: String) -> Bool {
        ["md", "markdown"].contains((n as NSString).pathExtension.lowercased())
    }

    static func isCSVName(_ n: String) -> Bool {
        ["csv", "tsv"].contains((n as NSString).pathExtension.lowercased())
    }

    private var isMarkdown: Bool { FileEditorView.isMarkdownName(name) }
    private var isCSV: Bool { FileEditorView.isCSVName(name) }
    private var isPreviewable: Bool { isMarkdown || isCSV }
    private var monoFont: Font { .system(size: editorFontSize, design: .monospaced) }
    private var editorScheme: ColorScheme {
        switch editorTheme {
        case "light": return .light
        case "dark": return .dark
        default: return sysScheme
        }
    }
    private var editorStyle: UIUserInterfaceStyle {
        switch editorTheme {
        case "light": return .light
        case "dark": return .dark
        default: return .unspecified
        }
    }

    private var canEdit: Bool {
        !loading && error == nil && imageData == nil && pdfData == nil && !notText && !readOnly
    }

    private var canCommit: Bool {
        canEdit && !saving && (isNew || text != original)
    }

    /// Có thay đổi chưa commit
    private var dirty: Bool {
        canEdit && text != original
    }

    private var showMenu: Bool {
        !loading && error == nil && imageData == nil && pdfData == nil && !notText
    }

    var body: some View {
        content
            .environment(\.colorScheme, editorScheme)
            .overlay { if translating { ProgressView() } }
            .navigationTitle(name)
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(dirty)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    if dirty {
                        Button {
                            askDiscard = true
                        } label: {
                            HStack(spacing: 4) {
                                Image(systemName: "chevron.left").font(.body.weight(.semibold))
                                Text("Quay lại")
                            }
                        }
                    }
                }
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    if showMenu {
                        Menu {
                            if isPreviewable {
                                Button {
                                    preview.toggle()
                                } label: {
                                    Label(preview ? "Sửa" : (isCSV ? "Xem bảng" : "Xem trước"),
                                          systemImage: preview ? "pencil" : "eye")
                                }
                            }
                            if !isMarkdown && CommentTranslate.supports(CodeLang(fileName: name).kind) {
                                Button {
                                    if commentView == nil && !translateConsent {
                                        askTranslateConsent = true
                                    } else {
                                        Task { await toggleCommentTranslation() }
                                    }
                                } label: {
                                    Label(commentView == nil
                                          ? "Dịch comment sang \(TLang.name(langCode))"
                                          : "Xem bản gốc (code)",
                                          systemImage: "character.bubble")
                                }
                                Picker("Ngôn ngữ dịch", selection: $langCode) {
                                    ForEach(TLang.all) { l in
                                        Text(l.name).tag(l.code)
                                    }
                                }
                            }
                            if canEdit && !(isPreviewable && preview) && !foldMode && commentView == nil {
                                Button {
                                    symbols = SymbolScanner.scan(text, kind: CodeLang(fileName: name).kind)
                                    showSymbols = true
                                } label: {
                                    Label("Danh sách hàm / lớp", systemImage: "list.bullet.indent")
                                }
                                Button {
                                    lineText = ""
                                    askLine = true
                                } label: {
                                    Label("Nhảy tới dòng", systemImage: "arrow.down.to.line")
                                }
                            }
                            if !(isPreviewable && preview) {
                                Button {
                                    foldMode.toggle()
                                } label: {
                                    Label(foldMode ? "Thoát xem gấp" : "Xem gấp code",
                                          systemImage: "rectangle.compress.vertical")
                                }
                            }
                            Menu {
                                Picker("Cỡ chữ", selection: $editorFontSize) {
                                    ForEach([11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 18.0, 20.0], id: \.self) { s in
                                        Text("\(Int(s)) pt").tag(s)
                                    }
                                }
                                Picker("Giao diện editor", selection: $editorTheme) {
                                    Text("Theo hệ thống").tag("system")
                                    Text("Sáng").tag("light")
                                    Text("Tối").tag("dark")
                                }
                            } label: {
                                Label("Cỡ chữ và giao diện", systemImage: "textformat.size")
                            }
                            if canEdit && !(isPreviewable && preview) && !foldMode {
                                Button {
                                    editor.showFind()
                                } label: {
                                    Label("Tìm / thay thế", systemImage: "magnifyingglass")
                                }
                            }
                            if canEdit {
                                Button {
                                    stage()
                                } label: {
                                    Label("Thêm vào gói commit", systemImage: "tray.and.arrow.down")
                                }
                                .disabled(!canCommit)
                            }
                            Button {
                                UIPasteboard.general.string = text
                            } label: {
                                Label("Sao chép nội dung", systemImage: "doc.on.doc")
                            }
                            if !isNew && !viewOnly {
                                Button(role: .destructive) {
                                    askDelete = true
                                } label: {
                                    Label("Xóa file", systemImage: "trash")
                                }
                            }
                        } label: {
                            Image(systemName: "ellipsis.circle")
                        }
                    }
                    if canEdit {
                        Button("Commit") {
                            message = (isNew ? "Thêm " : "Cập nhật ") + name
                            askCommit = true
                        }
                        .disabled(!canCommit)
                    }
                }
            }
            .alert("Commit lên \(branch)", isPresented: $askCommit) {
                TextField("Nội dung commit", text: $message)
                Button("Hủy", role: .cancel) {}
                Button("Commit") { Task { await save() } }
            }
            .alert(TranslateNotice.title, isPresented: $askTranslateConsent) {
                Button("Hủy", role: .cancel) {}
                Button("Đồng ý và dịch") {
                    translateConsent = true
                    Task { await toggleCommentTranslation() }
                }
            } message: {
                Text(TranslateNotice.message)
            }
            .alert("Xóa \(name)?", isPresented: $askDelete) {
                Button("Hủy", role: .cancel) {}
                Button("Xóa", role: .destructive) { Task { await remove() } }
            } message: {
                Text("Sẽ tạo một commit xóa file này trên nhánh \(branch).")
            }
            .alert("Bỏ thay đổi chưa commit?", isPresented: $askDiscard) {
                Button("Tiếp tục sửa", role: .cancel) {}
                Button("Bỏ thay đổi", role: .destructive) { dismiss() }
            } message: {
                Text("Những gì bạn vừa sửa trong \(name) sẽ bị mất.")
            }
            .alert("File đã bị đổi trên GitHub", isPresented: $conflict) {
                Button("Hủy", role: .cancel) {}
                Button("Tải bản mới (bỏ thay đổi của tôi)") { Task { await reloadLatest() } }
                Button("Ghi đè bằng bản của tôi", role: .destructive) { Task { await save(force: true) } }
            } message: {
                Text("Có commit khác đã sửa file này kể từ lúc bạn mở. Bạn muốn làm gì?")
            }
            .alert("Thông báo", isPresented: Binding(
                get: { toast != nil },
                set: { if !$0 { toast = nil } }
            )) {
                Button("OK") {}
            } message: {
                Text(toast ?? "")
            }
            .sheet(isPresented: $showSymbols) {
                SymbolListView(symbols: symbols) { s in
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        editor.jump(to: s.location)
                    }
                }
            }
            .alert("Nhảy tới dòng", isPresented: $askLine) {
                TextField("Số dòng", text: $lineText)
                    .keyboardType(.numberPad)
                Button("Hủy", role: .cancel) {}
                Button("Đi") {
                    if let n = Int(lineText.trimmingCharacters(in: .whitespaces)), n > 0 {
                        editor.goToLine(n)
                    }
                }
            }
            .task { await load() }
            .onChange(of: text) { _ in commentView = nil }
    }

    private func toggleCommentTranslation() async {
        if commentView != nil {
            commentView = nil
            return
        }
        translating = true
        defer { translating = false }
        do {
            let r = try await CommentTranslate.translate(text, kind: CodeLang(fileName: name).kind, to: langCode)
            if r.count == 0 {
                toast = "Không tìm thấy comment nào để dịch trong file này."
                return
            }
            commentView = r.text
            if r.truncated {
                toast = "File có rất nhiều comment, chỉ dịch \(CommentTranslate.maxComments) dòng comment đầu tiên."
            }
        } catch let e {
            toast = "Không dịch được: \(e.localizedDescription)"
        }
    }

    @ViewBuilder
    private var content: some View {
        if loading {
            ProgressView()
        } else if let error = error {
            Text(error).foregroundStyle(.secondary).padding()
        } else if let d = pdfData {
            PDFPreview(data: d)
        } else if let data = imageData, let ui = UIImage(data: data) {
            ScrollView {
                Image(uiImage: ui).resizable().scaledToFit().padding()
            }
        } else if notText {
            Text("Đây không phải file văn bản nên không mở được trên điện thoại.")
                .foregroundStyle(.secondary)
                .padding()
        } else if isMarkdown && preview {
            ScrollView {
                TranslatableMarkdown(text: text).padding()
            }
        } else if isCSV && preview {
            CSVTableView(text: text, delimiter: name.lowercased().hasSuffix(".tsv") ? "\t" : ",")
        } else if foldMode {
            FoldCodeView(text: text, lang: CodeLang(fileName: name), fontSize: CGFloat(editorFontSize))
        } else if let t = commentView {
            VStack(spacing: 0) {
                Text("Đang xem bản dịch comment (chỉ đọc). Chọn \"Xem bản gốc\" trong menu ⋯ để sửa file.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal)
                    .padding(.vertical, 6)
                ScrollView([.vertical, .horizontal]) {
                    Text(t)
                        .font(monoFont)
                        .textSelection(.enabled)
                        .fixedSize(horizontal: true, vertical: false)
                        .padding()
                }
            }
        } else if readOnly {
            ScrollView([.vertical, .horizontal]) {
                Text(text)
                    .font(monoFont)
                    .textSelection(.enabled)
                    .fixedSize(horizontal: true, vertical: false)
                    .padding()
            }
        } else {
            CodeTextView(text: $text, lang: CodeLang(fileName: name), controller: editor,
                         fontSize: CGFloat(editorFontSize), style: editorStyle)
                .background(Theme.editorBG)
        }
    }

    private var stageKey: String { Staging.key(repo, branch) }

    private func stage() {
        staging.add(.put(path: path, data: Data(text.utf8)), key: stageKey)
        original = text
        toast = "Đã thêm vào gói commit (\(staging.count(stageKey)) thay đổi)."
    }

    private func load() async {
        defer { loading = false }
        // Nếu file đã nằm trong gói commit thì mở bản đang chờ
        let staged: String? = staging.stagedPut(stageKey, path).flatMap { d in
            d.count < 400_000 ? String(data: d, encoding: .utf8) : nil
        }
        if isNew {
            if let st = staged {
                text = st
                original = st
            }
            return
        }
        do {
            let f = try await session.api.file(repo, path: path, ref: branch)
            sha = f.sha
            if FileEditorView.isPDFName(name) {
                pdfData = f.data
            } else if let s = String(data: f.data, encoding: .utf8) {
                text = staged ?? s
                original = staged ?? s
                readOnly = viewOnly || f.data.count > 400_000
            } else if isImage(name), UIImage(data: f.data) != nil {
                imageData = f.data
            } else {
                notText = true
            }
        } catch let e as APIError where e.statusCode == 404 && staged != nil {
            // File mới chỉ có trong gói commit
            isNew = true
            text = staged ?? ""
            original = staged ?? ""
        } catch let e {
            error = e.localizedDescription
        }
    }

    private func reloadLatest() async {
        isNew = false
        error = nil
        loading = true
        await load()
    }

    static func isPDFName(_ n: String) -> Bool {
        (n as NSString).pathExtension.lowercased() == "pdf"
    }

    private func isImage(_ n: String) -> Bool {
        ["png", "jpg", "jpeg", "gif", "webp", "heic"].contains((n as NSString).pathExtension.lowercased())
    }

    private func isConflict(_ e: APIError) -> Bool {
        e.statusCode == 409 || (e.statusCode == 422 && e.message.contains("sha"))
    }

    private func save(force: Bool = false) async {
        saving = true
        defer { saving = false }
        let m = message.trimmingCharacters(in: .whitespacesAndNewlines)
        do {
            var useSha = isNew ? nil : sha
            if force, let latest = try? await session.api.file(repo, path: path, ref: branch) {
                useSha = latest.sha
            }
            let newSha = try await session.api.save(
                repo,
                path: path,
                data: Data(text.utf8),
                sha: useSha,
                message: m.isEmpty ? "Cập nhật \(name)" : m,
                branch: branch
            )
            sha = newSha ?? useSha
            original = text
            isNew = false
            staging.remove("put:" + path, key: stageKey)
            toast = "Đã commit lên nhánh \(branch)."
        } catch let e as APIError where isConflict(e) {
            conflict = true
        } catch let e {
            toast = e.localizedDescription
        }
    }

    private func remove() async {
        guard let sha = sha, !sha.isEmpty else {
            toast = "Chưa có thông tin phiên bản của file, hãy mở lại file rồi xóa."
            return
        }
        do {
            try await session.api.delete(repo, path: path, sha: sha, message: "Xóa \(name)", branch: branch)
            dismiss()
        } catch let e {
            toast = e.localizedDescription
        }
    }
}
