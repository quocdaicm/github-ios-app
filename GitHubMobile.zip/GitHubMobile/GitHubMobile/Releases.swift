import SwiftUI

// MARK: - Mô hình Release

struct ReleaseAsset: Decodable, Identifiable, Hashable {
    let id: Int
    let name: String
    let size: Int
    let downloadCount: Int?
}

struct ReleaseItem: Decodable, Identifiable, Hashable {
    let id: Int
    let tagName: String
    let name: String?
    let body: String?
    let draft: Bool
    let prerelease: Bool
    let publishedAt: Date?
    let createdAt: Date?
    let assets: [ReleaseAsset]

    var title: String {
        if let n = name, !n.isEmpty { return n }
        return tagName
    }
    var date: Date? { publishedAt ?? createdAt }
}

extension GitHubAPI {
    func releases(_ repo: Repo, page: Int) async throws -> [ReleaseItem] {
        try await get("/repos/\(repo.fullName)/releases", query: ["per_page": "30", "page": "\(page)"])
    }

    func createRelease(_ repo: Repo, tag: String, title: String, notes: String,
                       prerelease: Bool, target: String) async throws {
        _ = try await raw("/repos/\(repo.fullName)/releases", method: "POST", body: [
            "tag_name": tag,
            "name": title,
            "body": notes,
            "prerelease": prerelease,
            "target_commitish": target
        ])
    }

    func deleteRelease(_ repo: Repo, id: Int) async throws {
        _ = try await raw("/repos/\(repo.fullName)/releases/\(id)", method: "DELETE")
    }
}

// MARK: - Danh sách

struct ReleasesView: View {
    let repo: Repo
    let branch: String

    @EnvironmentObject var session: Session
    @State private var items: [ReleaseItem] = []
    @State private var page = 1
    @State private var hasMore = false
    @State private var loading = false
    @State private var error: String?
    @State private var showNew = false
    @State private var tag = ""
    @State private var title = ""
    @State private var notes = ""
    @State private var pre = false
    @State private var toast: String?

    private let pageSize = 30

    var body: some View {
        List {
            if let error = error {
                Text(error).font(.footnote).foregroundStyle(.secondary)
            }
            if items.isEmpty && !loading && error == nil {
                Text("Repo này chưa có release nào.")
                    .foregroundStyle(.secondary)
                    .listRowBackground(Color.clear)
            }
            ForEach(items) { r in
                NavigationLink {
                    ReleaseDetailView(repo: repo, release: r) {
                        Task { await reload() }
                    }
                } label: {
                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 6) {
                            Chip(text: r.tagName, icon: "tag", color: Theme.accent)
                            if r.prerelease { Chip(text: "Bản thử", color: .orange) }
                            if r.draft { Chip(text: "Nháp", color: .gray) }
                        }
                        Text(r.title).font(.subheadline.weight(.semibold))
                        Text("\(relative(r.date)) · \(r.assets.count) file đính kèm")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .cardRow()
            }
            if hasMore {
                ProgressView()
                    .frame(maxWidth: .infinity)
                    .listRowBackground(Color.clear)
                    .onAppear { Task { await loadMore() } }
            }
        }
        .listStyle(.plain)
        .themedList()
        .overlay {
            if loading && items.isEmpty { ProgressView() }
        }
        .refreshable { await reload() }
        .task { await reload() }
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    tag = ""
                    title = ""
                    notes = ""
                    pre = false
                    showNew = true
                } label: {
                    Image(systemName: "plus.circle")
                }
            }
        }
        .sheet(isPresented: $showNew) {
            NavigationStack {
                Form {
                    Section("Thẻ phiên bản") {
                        TextField("Ví dụ v1.0.0", text: $tag)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        TextField("Tiêu đề (không bắt buộc)", text: $title)
                    }
                    Section("Ghi chú") {
                        TextField("Nội dung...", text: $notes, axis: .vertical)
                            .lineLimit(3...10)
                    }
                    Section {
                        Toggle("Đánh dấu là bản thử", isOn: $pre)
                        Text("Release được tạo từ nhánh \(branch). Nếu thẻ chưa có, GitHub tự tạo.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .navigationTitle("Release mới")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Hủy") { showNew = false }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Tạo") { Task { await create() } }
                            .disabled(tag.trimmingCharacters(in: .whitespaces).isEmpty)
                    }
                }
            }
        }
        .alert("Thông báo", isPresented: Binding(
            get: { toast != nil },
            set: { if !$0 { toast = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(toast ?? "")
        }
    }

    private func reload() async {
        loading = true
        defer { loading = false }
        do {
            let first = try await session.api.releases(repo, page: 1)
            items = first
            page = 1
            hasMore = first.count >= pageSize
            error = nil
        } catch let e {
            if !(e is CancellationError) { error = e.localizedDescription }
        }
    }

    private func loadMore() async {
        if loading { return }
        loading = true
        defer { loading = false }
        do {
            let next = try await session.api.releases(repo, page: page + 1)
            let known = Set(items.map { $0.id })
            items += next.filter { !known.contains($0.id) }
            page += 1
            hasMore = next.count >= pageSize
        } catch let e {
            hasMore = false
            error = e.localizedDescription
        }
    }

    private func create() async {
        let t = tag.trimmingCharacters(in: .whitespaces)
        guard !t.isEmpty else { return }
        do {
            try await session.api.createRelease(repo, tag: t, title: title, notes: notes,
                                                prerelease: pre, target: branch)
            showNew = false
            toast = "Đã tạo release \(t)."
            await reload()
        } catch let e {
            showNew = false
            toast = e.localizedDescription
        }
    }
}

// MARK: - Chi tiết

struct ReleaseDetailView: View {
    let repo: Repo
    let release: ReleaseItem
    var onChanged: () -> Void = {}

    @EnvironmentObject var session: Session
    @Environment(\.dismiss) private var dismiss
    @State private var busyId: Int?
    @State private var shared: SharedFile?
    @State private var toast: String?
    @State private var askDelete = false

    var body: some View {
        List {
            Section {
                HStack(spacing: 6) {
                    Chip(text: release.tagName, icon: "tag", color: Theme.accent)
                    if release.prerelease { Chip(text: "Bản thử", color: .orange) }
                    if release.draft { Chip(text: "Nháp", color: .gray) }
                }
                Text(release.title).font(.headline)
                Text(relative(release.date)).font(.caption).foregroundStyle(.secondary)
            }

            if let b = release.body, !b.isEmpty {
                Section {
                    TranslatableMarkdown(text: b)
                }
            }

            if !release.assets.isEmpty {
                Section("File đính kèm") {
                    ForEach(release.assets) { a in
                        Button {
                            Task { await download(a) }
                        } label: {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(a.name).font(.subheadline).lineLimit(1).truncationMode(.middle)
                                    Text(sizeText(a.size)
                                         + (a.downloadCount.map { " · \($0) lượt tải" } ?? ""))
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                if busyId == a.id {
                                    ProgressView()
                                } else {
                                    Image(systemName: "arrow.down.circle")
                                }
                            }
                        }
                        .disabled(busyId != nil)
                    }
                }
            }
        }
        .themedList()
        .navigationTitle(release.tagName)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(role: .destructive) {
                    askDelete = true
                } label: {
                    Image(systemName: "trash")
                }
            }
        }
        .sheet(item: $shared) { f in
            ShareSheet(items: [f.url])
        }
        .alert("Xóa release \(release.tagName)?", isPresented: $askDelete) {
            Button("Hủy", role: .cancel) {}
            Button("Xóa", role: .destructive) { Task { await remove() } }
        } message: {
            Text("Chỉ xóa release và file đính kèm, thẻ (tag) vẫn còn trên GitHub.")
        }
        .alert("Thông báo", isPresented: Binding(
            get: { toast != nil },
            set: { if !$0 { toast = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(toast ?? "")
        }
    }

    private func download(_ a: ReleaseAsset) async {
        busyId = a.id
        defer { busyId = nil }
        do {
            let url = try await session.api.downloadReleaseAsset(repo, a)
            shared = SharedFile(url: url)
        } catch let e {
            toast = e.localizedDescription
        }
    }

    private func remove() async {
        do {
            try await session.api.deleteRelease(repo, id: release.id)
            onChanged()
            dismiss()
        } catch let e {
            toast = e.localizedDescription
        }
    }
}
