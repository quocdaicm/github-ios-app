import SwiftUI

// MARK: - Dịch comment trong file code (chỉ phần comment, code giữ nguyên)

enum CommentTranslate {
    struct Syntax {
        var line: String?
        var blockStart: String?
        var blockEnd: String?
        var docQuotes = false
        var quotes: [Character]
        var star = false
    }

    /// Một dòng được tách thành: code + dấu mở comment + nội dung comment + phần đuôi
    struct Piece {
        var code = ""
        var prefix = ""
        var body = ""
        var suffix = ""
        var text: String { code + prefix + body + suffix }
    }

    static func syntax(for kind: CodeLang.Kind) -> Syntax? {
        switch kind {
        case .clike:
            return Syntax(line: "//", blockStart: "/*", blockEnd: "*/", docQuotes: false,
                          quotes: ["\"", "'", "`"], star: true)
        case .hash, .yaml:
            return Syntax(line: "#", blockStart: nil, blockEnd: nil, docQuotes: false,
                          quotes: ["\"", "'"], star: false)
        case .python:
            return Syntax(line: "#", blockStart: nil, blockEnd: nil, docQuotes: true,
                          quotes: ["\"", "'"], star: false)
        case .markup:
            return Syntax(line: nil, blockStart: "<!--", blockEnd: "-->", docQuotes: false,
                          quotes: [], star: false)
        default:
            return nil
        }
    }

    static func supports(_ kind: CodeLang.Kind) -> Bool { syntax(for: kind) != nil }

    // MARK: Tách comment

    private static func trimParts(_ s: String) -> (String, String, String) {
        let chars = Array(s)
        var a = 0
        while a < chars.count, chars[a].isWhitespace { a += 1 }
        var b = chars.count
        while b > a, chars[b - 1].isWhitespace { b -= 1 }
        return (String(chars[0..<a]), String(chars[a..<b]), String(chars[b...]))
    }

    private static func match(_ chars: [Character], _ i: Int, _ token: String) -> Bool {
        let t = Array(token)
        guard i + t.count <= chars.count else { return false }
        for k in 0..<t.count where chars[i + k] != t[k] { return false }
        return true
    }

    private static func find(_ chars: [Character], _ token: String, from: Int) -> Int? {
        var i = from
        while i < chars.count {
            if match(chars, i, token) { return i }
            i += 1
        }
        return nil
    }

    static func split(_ text: String, _ sx: Syntax) -> [Piece] {
        var out: [Piece] = []
        var inBlock = false
        var blockEnd = ""

        for (n, line) in text.components(separatedBy: "\n").enumerated() {
            let chars = Array(line)
            var p = Piece()

            if n == 0 && line.hasPrefix("#!") {      // dòng shebang
                p.code = line
                out.append(p)
                continue
            }

            if inBlock {
                let endIdx = find(chars, blockEnd, from: 0)
                let segEnd = endIdx ?? chars.count
                let (ws, core, tw) = trimParts(String(chars[0..<segEnd]))
                var lead = ws
                var body = core
                if sx.star, body.hasPrefix("*") {
                    lead += "*"
                    let (ws2, core2, _) = trimParts(String(body.dropFirst()))
                    lead += ws2
                    body = core2
                }
                p.prefix = lead
                p.body = body
                p.suffix = tw + (endIdx.map { String(chars[$0...]) } ?? "")
                if endIdx != nil { inBlock = false }
                out.append(p)
                continue
            }

            var i = 0
            var quote: Character? = nil
            var found = false

            func block(_ bs: String, _ be: String) {
                p.code = String(chars[0..<i])
                let after = i + bs.count
                let endIdx = find(chars, be, from: after)
                let segEnd = endIdx ?? chars.count
                let (ws, core, tw) = trimParts(String(chars[after..<segEnd]))
                p.prefix = bs + ws
                p.body = core
                p.suffix = tw + (endIdx.map { String(chars[$0...]) } ?? "")
                if endIdx == nil {
                    inBlock = true
                    blockEnd = be
                }
            }

            while i < chars.count {
                let c = chars[i]
                if let q = quote {
                    if c == "\\" { i += 2; continue }
                    if c == q { quote = nil }
                    i += 1
                    continue
                }
                if let bs = sx.blockStart, let be = sx.blockEnd, match(chars, i, bs) {
                    block(bs, be)
                    found = true
                    break
                }
                if sx.docQuotes {
                    let tq = match(chars, i, "\"\"\"") ? "\"\"\"" : (match(chars, i, ") ? " : "")
                    if !tq.isEmpty,
                       String(chars[0..<i]).trimmingCharacters(in: .whitespaces).isEmpty {
                        block(tq, tq)
                        found = true
                        break
                    }
                }
                if let lm = sx.line, match(chars, i, lm) {
                    var ok = true
                    if lm == "#" { ok = i == 0 || chars[i - 1].isWhitespace }
                    if lm == "//" { ok = i == 0 || chars[i - 1] != ":" }
                    if ok {
                        p.code = String(chars[0..<i])
                        var j = i + lm.count
                        var marker = lm
                        while j < chars.count,
                              chars[j] == lm.last! || (lm == "//" && chars[j] == "!") {
                            marker.append(chars[j])
                            j += 1
                        }
                        let (ws, core, tw) = trimParts(String(chars[j...]))
                        p.prefix = marker + ws
                        p.body = core
                        p.suffix = tw
                        found = true
                        break
                    }
                }
                if sx.quotes.contains(c) { quote = c }
                i += 1
            }
            if !found { p.code = line }
            out.append(p)
        }
        return out
    }

    /// Chỉ dịch dòng có chữ, bỏ qua dòng giống code bị comment ra (kết thúc bằng ; { })
    private static func isProse(_ s: String) -> Bool {
        let letters = s.filter { $0.isLetter }.count
        guard letters >= 3 else { return false }
        if let l = s.last, ";{}".contains(l) { return false }
        return true
    }

    static let maxComments = 300

    /// Trả về nội dung file với comment đã dịch, số comment đã dịch, và có bị cắt bớt không
    static func translate(_ text: String, kind: CodeLang.Kind, to lang: String) async throws
        -> (text: String, count: Int, truncated: Bool) {
        guard let sx = syntax(for: kind) else { return (text, 0, false) }
        let pieces = split(text, sx)

        var bodies: [String] = []
        var seen = Set<String>()
        for p in pieces where isProse(p.body) && !seen.contains(p.body) {
            seen.insert(p.body)
            bodies.append(p.body)
        }
        if bodies.isEmpty { return (text, 0, false) }

        let truncated = bodies.count > maxComments
        if truncated { bodies = Array(bodies.prefix(maxComments)) }

        let map = try await BatchTranslate.run(bodies, to: lang)
        let joined = pieces.map { p -> String in
            var q = p
            if let t = map[p.body] {
                q.body = t.replacingOccurrences(of: "
", with: " ")
            }
            return q.text
        }.joined(separator: "
")
        return (joined, map.count, truncated)
    }
}
